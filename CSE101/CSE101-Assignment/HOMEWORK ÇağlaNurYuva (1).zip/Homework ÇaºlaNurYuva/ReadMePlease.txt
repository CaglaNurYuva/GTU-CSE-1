






       Youtube video link : https://www.youtube.com/watch?v=nf3eu8lfKv4&ab_channel=%C3%87a%C4%9FlaNurYuva



This homework was done by Çağla Nur Yuva. 

My School Number : 200104004081 

