

// This program works only in Linux operating systems.In addition to this, my port's name is "ttyUSB0". If yours is different from mine, please change it before run the code below.
// Button counting part does not perfectly function. The other parts does function well. 
// In literal meaning, there is NO web page , blog , youtube video , code about serial communication and functions in C programming that I didn't research and analyze. However, I'm going to share just some of them.
// Some Sources that I utilized to accomplish the work are as follows:
// ---------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                                                                                                           
// https://www.cihatyildiz.com/posts/Linux-system-prog-part1                                                                                               
// https://www.tutorialspoint.com/cprogramming/c_functions.htm     
// https://koddefteri.net/arduino/temel-arduino-dersleri/arduino-dijital-giris-cikis-fonksiyonlari.html
// https://www.mobilhanem.com/arduino-dersleri-serial-port-ve-fonksiyonlari/
// https://salilkapur.wordpress.com/2013/03/08/communicating-with-arduino-using-c/
// https://programmer.group/5d0d4cc606361.html
// https://askubuntu.com/questions/292024/read-dev-ttyusb0-failed
// https://coderedirect.com/questions/593038/how-to-properly-set-up-serial-communication-on-linux
// https://gist.github.com/chomy/3798582
// https://www.codeproject.com/Questions/892520/how-to-write-and-read-data-from-serial-port
// https://ckaynak.com/c-programlama-dili-fonksiyonlar-1-1120
// https://beginnersbook.com/2014/01/c-functions-examples/
// https://fatihkabakci.com/article-C_DE_SLEEP_FONKSIYONU
// https://demirten.gitbooks.io/linux-sistem-programlama/content/timers/general.html
// https://www.geeksforgeeks.org/input-output-system-calls-c-create-open-close-read-write/
// http://www.cems.uwe.ac.uk/~irjohnso/courses/coursenotes/uqc146/cprogram/c_075.htm
// https://www.tutorialspoint.com/c_standard_library/c_function_atoi.htm
// https://linuxhint.com/atoi-function-c/
// https://fresh2refresh.com/c-programming/c-type-casting/c-atoi-function/
// https://www.cs.utah.edu/~germain/PPS/Topics/C_Language/c_functions.html
// https://www.arduino.cc/reference/en/language/functions/communication/serial/readstring/
// https://www.arduino.cc/reference/en/language/functions/communication/serial/write/

// -----------------------------------------------------------------------------------------------------------------------------------------------------------

 
#include <stdio.h>
#include <time.h>    //The function "sleep" used in this program is in this library.
#include <fcntl.h>
#include <string.h>  // The function "strlen" used in this program is in this library.
#include <unistd.h>  // The function "read","close","write","sleep" used in this program are in this library.
#include <stdlib.h>  // The function "atoi" used in this program is in this library.

void MENU();
void TurningOn_MyLed();
void TurningOff_MyLed();
void Flashing_MyLed();            // There are function prototypes that is going to be used throughout the C program.
void Compute_Square();           // These functions are not going to return any value to main function,which is why their return type is void.
void MyButton_Counter();
void DrawingHeart();

int main()
{
   char MySerial_Port = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY );		// Serial port is opened like this in Linux. It is completely different in Windows.
   char Choice[5];           

   printf(" ## WELCOME TO GTU ARDUINO LAB ##\n");
   printf(" ## STUDENT NAME: �A�LA NUR YUVA ##\n");
   printf(" ## PLEASE SELECT FROM THE FOLLOWING ##\n"); 	                                                         	

while (1){

   MENU();                                            // MENU function shows the menu and scanf takes the user's choice.
   scanf("%s",Choice);										  	
   printf("\n\nYou have made your choice...\n\n\n");
   sleep(0.5);	
   DrawingHeart();
   sleep(1);
		
   if(Choice[0] == '0'){								
	 return 0; }												
																																				
   else if(Choice[0] == '1'){											
	 TurningOn_MyLed(); }																
																																												
   else if(Choice[0] == '2'){															
	 TurningOff_MyLed();	}																	
										    	// There are five different functions. According to chosen number, program is going to go to the respective function.																										
   else if(Choice[0] == '3'){															
	 Flashing_MyLed(); }																		
																																												 
   else if(Choice[0] == '4'){									
	 Compute_Square(); }										  
																	 																
   else if(Choice[0] == '5'){									
	 MyButton_Counter();	}									   																	  
																 		
   else {												    
	 printf("\nYou have chosen an invalid option. Please enter a valid option between 0-5...\n\n"); }
}
	 		 																														
	close(MySerial_Port);  // The respective function or "else"  has finished doing what needs to be done. It is time to close serial port by using the function "close".
	return 0;
}





void MENU() {

	printf("  ## MENU :  ##\n");
	printf(" (1) TURN ON LED ON ARDUINO\n");
	printf(" (2) TURN OFF LED ON ARDUINO\n");
	printf(" (3) FLASH ARDUINO LED 3 TIMES\n");
	printf(" (4) SEND A NUMBER TO ARDUINO TO COMPUTE SQUARE BY ARDUINO \n");
	printf(" (5) Button press counter (bonus item)\n");
	printf(" (0) EXIT\n");
	printf(" PLEASE SELECT: \n\n");
}



void DrawingHeart() {


int ROW,COLUMN;
for(ROW=0;ROW<=2;ROW++)
{
for(COLUMN=1;COLUMN<=17;COLUMN++)
{
if((COLUMN>=3-ROW&&COLUMN<=6+ROW) || (COLUMN>=12-ROW&&COLUMN<=15+ROW))

printf("*");
else
printf(" ");
}printf("\n");
}
for(ROW=0;ROW<9;ROW++)
{
for(COLUMN=1;COLUMN<=17;COLUMN++)
{
if(COLUMN>=ROW+1&&COLUMN<=17-ROW)
printf("*");
else
printf(" ");
}printf("\n");
}

}



void TurningOn_MyLed(){

	char MySerial_Port = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY );			 // Thanks to this code line, serial port is opened.
	sleep(1);                                                                            // These waiting times throughout this code play an important role in keeping up with the speed of both C program and Arduino.
    write(MySerial_Port,"1",1);		   	                                                 // The function "write" sends '1',which is the user's choice, to Arduino.
	printf("Led has already been turned on. Look at your arduino card!\n\n");
	DrawingHeart();
	sleep(1);
	
	printf("\n\nYou have done what you wanted to do. You are about to see the menu again....\n\n");
	close(MySerial_Port);	                                                             // You are done with this function. It is time to close serial port by using the function "close".		
}



void TurningOff_MyLed() {

	char MySerial_Port = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY );		    // Thanks to this code line, serial port is opened.
	sleep(1);                                                                           
    write(MySerial_Port,"2",1);                                                         // The function "write" sends '2',which is the user's choice, to Arduino.
	printf("Led has already been turned off. Look at your arduino card!\n");
	DrawingHeart();
	sleep(1);
	
	printf("\nYou have done what you wanted to do. You are about to see the menu again....\n\n");
	close(MySerial_Port);   	                                                        // You are done with this function. It is time to close serial port by using the function "close".
}



void Flashing_MyLed(){

	char MySerial_Port = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY );	    // Thanks to this code line, serial port is opened.
	sleep(1);                                                                       
    write(MySerial_Port,"3",1);		                                                // The function "write" sends '3',which is the user's choice, to Arduino.		
	printf("Led has already been flashed three times!");
	DrawingHeart();
	sleep(1);
	
	printf("\nYou have done what you wanted to do. You are about to see the menu again...\n\n");	
	close(MySerial_Port);	  	                                                    // You are done with this function. It is time to close serial port by using the function "close".
}



void Compute_Square() {

    char MySerial_Port = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY );		// Thanks to this code line, serial port is opened.
	sleep(1);                                                                            
    write(MySerial_Port,"4",1);	 	                                                // The function "write" sends '4',which is the user's choice, to Arduino.
	                                                   
	char ReadComingData; 	                                                        // While C program is taking data from arduino, this variable is storing coming data.
    int ResultOfArduino;
	char NumberOfTheUser[10];                                                       //  I have to use arrays here due to properties of "read" and "write" functions. 
	unsigned char NumComingFromArduino[9];                                          // Actually, i think this necessity arises from correlation between address and variable,
	int length;									                      	            // Pointers are also an option to compute square.
					                                                    	 							                          
	printf("Please enter a number to find its square:  \n\n");
	scanf("%s",NumberOfTheUser);									

	length = strlen(NumberOfTheUser);							                   // The function "strlen" is capable of finding the length of a string.
    write(MySerial_Port,NumberOfTheUser,length);                                   // C program sends the number chosen by the user and its length to Arduino.
    printf("\nYour number has been sent to Arduino. Wait a little bit to see the result...\n");
	sleep(5);								                                       //C program waits for Arduino to complete its task.
			
	ReadComingData = read(MySerial_Port,NumComingFromArduino,9);                   //The function "read" is used to take data coming from Arduino. The variable "ReadComingData" stores data coming from Arduino.						
	ResultOfArduino = atoi(NumComingFromArduino);						           //The function "atoi" is used to convert "NumComingFromArduino" from string/unsigned char array to integer.
	printf("\n%s times %s is equivalent to %d . (This operation is called square.) \n\n",NumberOfTheUser,NumberOfTheUser,ResultOfArduino);
	sleep(2.5);
	DrawingHeart();	
	sleep(0.7);
	
	printf("\nYou have done what you wanted to do. You are about to see the menu again...\n\n");
	close(MySerial_Port);								                       // You are done with this function. It is time to close serial port by using the function "close".
}



void MyButton_Counter(){

	char MySerial_Port = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY );	  // Thanks to this code line, serial port is opened.
	sleep(0.5);
    write(MySerial_Port,"5",1);									                  // The function "write" sends '5',which is the user's choice, to Arduino.
	sleep(1);                                                                     // These waiting times throughout this code play an important role in keeping up with the speed of both C program and Arduino.
			                      					       	    	
	int TheNumberOfPushes=0;    // This variable stores the number of pushes, which is equivalent to zero at the beginning.
	int Answer ;					                                                         
	int ConversionResult;		// This array stores data ,which is the number of button pushes, coming from arduino.                                  
	char ReadComingData;        // While C program is taking data from arduino, this variable is storing coming data. Basically it helps the function "read" and is used for the sake of readability purpose.
	int m = 0 ;	
    unsigned char count[1];	       
        
	ReadComingData = read(MySerial_Port,count,1);		     //The function "read" is used to take data coming from Arduino. The array "count" stores data coming from Arduino.
	ConversionResult = atoi(count);	                         //The function "atoi" is used to convert "count" from string/unsigned char array to integer. The converted value is assigned to the variable "ConversionResult".
	
    printf("\nThe maximum number of counting is 9. Let's get started...\n\n");
    sleep(0.5);
    printf("\nThe button has been pushed %d times...\n\n",ConversionResult);	//Counting has not been started yet. The "read" above reads the value '0'. Hence, the function "printf" prints '0'.				    
		                                                             

	while(1) {

     ReadComingData = read(MySerial_Port,count,1);           //The function "read" is used to take data coming from Arduino. The array "count" stores data coming from Arduino.
     TheNumberOfPushes = atoi(count);                        //The function "atoi" is used to convert "count" from string/unsigned char array to integer. The converted value is assigned to the variable "TheNumberOfPushes".
       	                                                            
		if(TheNumberOfPushes != ConversionResult){		     // If there is a DIFFERENCE between the actual number of pushes, which is stored in the variable "TheNumberOfPushes" --
			 	if(TheNumberOfPushes == 0) {                 // and comes from arduino, and the number of pushes which is visible to C program, the variable "ConversionResult" is changed
                continue;                                    // so that it can keep storing the correct number of pushes, which is in the variable "TheNumberOfPushes" now.	
				}	
                                                                            
			printf("The button has been pushed %d times...\n\n",TheNumberOfPushes);	   	
			ConversionResult = TheNumberOfPushes ;            
            m = 1 ;               									
		}   
			
sleep(0.3);
						                           							                                			
	 if(m==1) {
          printf("If you want to stop counting, enter 0 , otherwise firstly push your button , secondly enter 1\n");
          scanf("%d", &Answer);

          if(Answer == 0) {
          break; }
          
          
          else if(Answer == 1) {
          m = 0 ; }
          
           	
          else {
          printf("\nInvalid option...\n");
          break; }
          
        }									
	}
	
	printf("\nYou have done what you wanted to do. You are about to see the menu again...\n");
	close(MySerial_Port);											// You are done with this function. It is time to close serial port by using the function "close".	
}

	


