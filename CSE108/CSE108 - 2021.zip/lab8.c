#include <stdio.h>
#include <math.h>

/* matrix structure */
typedef struct{
    double matrix[3][3];
    double determinant;
} matrix;

/* vector structure */
typedef struct {
    double x,y,z;
} vector;

/* polynomial structure */
typedef struct {
    double a6,a5,a4,a3,a2,a1,a0;
    double value;
    char c;
} polynomial;

typedef struct {
    double a3,a2,a1,a0;
} third_order_polynomial;

/* function declerations */ 
void print_matrix(matrix initial_matrix);
void inverse_matrix( matrix* initial_matrix,matrix* inverted_matrix);
void determinant_of_matrix(matrix* initial_matrix);
double find_orthogonal(vector vec_1, vector vec_2, vector* output_vec);
polynomial get_integral(third_order_polynomial p1, third_order_polynomial p2, int a, int b)

void main()
{
    /* create a matrix and another to store inverted version */
    struct matrix m,inverted_m;
    /* vec1 and vec2 */
    struct vector vec_1,vec_2,out_vec;
    /* flag to check if matrix inverted */
    int is_inverted = 0;
    /* integers to use in loops */
    int i,j;
    

    /* fill matrix */
    m.matrix[0][0] = 1.0;
    m.matrix[0][1] = 0.9134;
    m.matrix[0][2] = 0.2785;
    m.matrix[1][0] = 0.9058;
    m.matrix[1][1] = 0.6324;
    m.matrix[1][2] = 0.5469;
    m.matrix[2][0] = 0.1270;
    m.matrix[2][1] = 0.0975;
    m.matrix[2][2] = 0.9575;

    /* fill vectors */
    vec_1.x = 3.0;
    vec_1.y = 4.0;
    vec_1.z = 5.0;
    vec_2.x = 6.0;
    vec_2.y = 8.0;
    vec_2.z = 10.0;

    /* call print matrix */
    printf("Matrix:");
    print_matrix(m);

    /* try to invert m */
    inverse_matrix(&m,&inverted_m);

    for(i = 0;i < 3;i++)
    {
        for(j = 0;j < 3;j++)
        {
            if(inverted_m.matrix[i][j] != 0.0)
            {
                is_inverted = 1;
                break;
            }
        }
    }

    /* if it is not inverted print error else print inverted matrix */
    if(is_inverted)
    {
        printf("\nInverted Matrix:");
        print_matrix(inverted_m);
    }
    else
        printf("\nERROR Couldn't inverse matrix");
    
    /* find angle between vectors and cross product */
    printf("\n\nAngle between vectors : %.2lf",find_orthogonal(vec_1,vec_2,&out_vec));
    printf("\nOutput Vector: X:%.2lf Y:%.2lf Z:%.2lf",out_vec.x,out_vec.y,out_vec.z);


}

void print_matrix(matrix initial_matrix)
{
    /* integer to use in loop */
    int i;


    for(i = 0;i < 3;i++)
    {
        printf("\n%10.4lf%10.4lf%10.4lf",initial_matrix.matrix[i][0],initial_matrix.matrix[i][1],initial_matrix.matrix[i][2]);
    }
}


void determinant_of_matrix(matrix* initial_matrix)
{
    /* double to store determinant */
    double det;

    /* get determinant by formula */
    det = (initial_matrix->matrix[0][0] * ((initial_matrix->matrix[1][1] * initial_matrix->matrix[2][2]) - (initial_matrix->matrix[1][2] * initial_matrix->matrix[2][1]))) - (initial_matrix->matrix[0][1] * ((initial_matrix->matrix[1][0] * initial_matrix->matrix[2][2]) - (initial_matrix->matrix[2][0] * initial_matrix->matrix[1][2]))) + (initial_matrix->matrix[0][2] * ((initial_matrix->matrix[1][0] * initial_matrix->matrix[2][1]) - (initial_matrix->matrix[1][1] * initial_matrix->matrix[2][0])));

    /* set determinant */
    initial_matrix->determinant = det;
}


void inverse_matrix(matrix* initial_matrix,matrix* inverted_matrix)
{
    /* temp double to use in transpose */
    double temp;
    /* integers to use in loops */
    int i,j;
    /* get determinant of initial matrix */
    determinant_of_matrix(initial_matrix);

    /* check if inverting is possible */
    if(initial_matrix->determinant == 0.0)
        return;
    /* first inbitialize inverse matrix */
    inverted_matrix->matrix[0][0] = initial_matrix->matrix[1][1] * initial_matrix->matrix[2][2] - initial_matrix->matrix[1][2] * initial_matrix->matrix[2][1];
    inverted_matrix->matrix[0][1] = - initial_matrix->matrix[1][0] * initial_matrix->matrix[2][2] + initial_matrix->matrix[2][0] * initial_matrix->matrix[1][2];
    inverted_matrix->matrix[0][2] = initial_matrix->matrix[1][0] * initial_matrix->matrix[2][1] - initial_matrix->matrix[2][0] * initial_matrix->matrix[1][1];
    inverted_matrix->matrix[1][0] = - initial_matrix->matrix[0][1] * initial_matrix->matrix[2][2] + initial_matrix->matrix[2][1] * initial_matrix->matrix[0][2];
    inverted_matrix->matrix[1][1] = initial_matrix->matrix[0][0] * initial_matrix->matrix[2][2] - initial_matrix->matrix[2][0] * initial_matrix->matrix[0][2];
    inverted_matrix->matrix[1][2] = - initial_matrix->matrix[0][0] * initial_matrix->matrix[2][1] + initial_matrix->matrix[2][0] * initial_matrix->matrix[0][1];
    inverted_matrix->matrix[2][0] = initial_matrix->matrix[0][1] * initial_matrix->matrix[1][2] - initial_matrix->matrix[1][1] * initial_matrix->matrix[0][2];
    inverted_matrix->matrix[2][1] = - initial_matrix->matrix[0][0] * initial_matrix->matrix[1][2] + initial_matrix->matrix[1][0] * initial_matrix->matrix[0][2];
    inverted_matrix->matrix[0][0] = initial_matrix->matrix[0][0] * initial_matrix->matrix[1][1] - initial_matrix->matrix[1][0] * initial_matrix->matrix[0][1];

    /* transpose inverted matrix */
    temp = inverted_matrix->matrix[0][1];
    inverted_matrix->matrix[0][1] = inverted_matrix[1][0];
    inverted_matrix[1][0] = temp;

    temp = inverted_matrix->matrix[1][2];
    inverted_matrix->matrix[1][2] = inverted_matrix[2][1];
    inverted_matrix[2][1] = temp;

    temp = inverted_matrix->matrix[0][2];
    inverted_matrix->matrix[0][2] = inverted_matrix[2][0];
    inverted_matrix[2][0] = temp;

    for(i = 0;i < 3;i++)
    {
        for(j = 0;j < 3;j++)
        {
            if(initial_matrix->determinant > 0)
                inverted_matrix->matrix[i][j] /= initial_matrix->determiant;
            else
                inverted_matrix->matrix[i][j] /= -initial_matrix->determiant; 
        }
    }


}


double find_orthogonal(vector vec_1,vector vec_2,vector* output_vec)
{
    /* double to store angle between vectors */
    double angle;

    /* find angle */
    angle = acosf((vec_1.x*vec_2.x + vec_1.y*vec_2.y + vec_1.z*vec_2*z)/(sqrt(vec_1.x*vec_1.x + vec_1.y*vec_1.y + vec_1.z*vec_1.z)*sqrt(vec_2.x*vec_2.x + vec_2.y*vec_2.y + vec_2.z*vec_2.z)));

    /* find cross product */
    output_vec->x = vec_1.y*vec_2.z - vec_2.y*vec_1.z;
    output_vec->y = vec_1.x*vec_2.z - vec_2.x*vec_1.z;
    output_vec->z = vec_1.x*vec_2.y - vec_2.x*vec_1.y;

    /* return angle */
    return angle;
}


polynomial get_integral(third_order_polynomial p1, third_order_polynomial p2, int a, int b)
{
    /* empty polynomial to store multiplication */
    polynomial temp,real;

    /* multiply */
    temp.a6 = p1.a3*p2.a3;
    temp.a5 = p1.a2*p2.a3 + p1.a3*p2.a2;
    temp.a4 = p1.a1*p2.a3 + p2.a2*p2.a2 + p1.a3*p2.a1;
    temp.a3 = p1.a0*p2.a3 + p1.a1*p2.a2 + p1.a2*p2.a1 + p1.a3*p2.a0;
    temp.a2 = p1.a0*p2.a2 + p1.a1*p2.a1 + p2.a2*p2.a0;
    temp.a1 = p1.a0*p2.a1 + p1.a1*p2.a0;
    temp.a0 = p1.a0*p2.a0;
    
    
}

