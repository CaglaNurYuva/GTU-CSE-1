#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

struct node_list
{
    int data;
    float number;
    char* name;
    struct node_list *next;
};

/*Do not modify the following function.*/

void insert_end(struct node_list **head, int val, float num, char* name_)
{ 
    struct node_list *newnode = malloc(sizeof(struct node_list));
    newnode->data = val;
    newnode->number = num;
    newnode->name = name_;
    newnode->next = NULL;

    if(*head == NULL)
 		*head = newnode;
    else
    {
        struct node_list *lastnode = *head;

        while(lastnode->next != NULL)
			lastnode = lastnode->next;

        lastnode->next = newnode;
    }
}

/*Do not modify the following function.*/

void print_list(struct node_list *head)
{
	struct node_list *temp = head;

    while(temp != NULL)
    {
		printf("%d->", temp->data);
		printf("%lf->", temp->number);
		printf("%s", temp->name);
		printf("\t");
		temp = temp->next;
    }
    
    printf("NULL\n\n");
}

/*Do not modify the following function.*/

void print_array(struct node_list *array, int sizeof_array)
{
	int i;
	
	for(i=0;i<sizeof_array;i++)
	{
		printf("%d->", (array+i)->data);
    	printf("%lf->", (array+i)->number);
		printf("%s", (array+i)->name);
		printf("\t");
	}
		
    	printf("NULL\n\n");
}

/*You can modify following functions.*/

struct node_list* merge_list(struct node_list* head_1, struct node_list* head_2)
{
	/* node_list to store last element of 1st linked list */
	struct node_list *last = NULL;
	/* to store head_1 temporarily */
	struct node_list *temp = head_1;
	/* find last element of head_! */
	while(temp != NULL)
	{
		last = temp;
		temp = temp->next;
	}
	
	/* now point last element of head_1 to start of head_2 */
	last->next = head_2;
	return head_1;
}

struct node_list* merge_interleaved(struct node_list* head_1, struct node_list* head_2)
{

	/* temporary nodes to use to store next pointers in every lap  */
	struct node_list *next1 = NULL,*next2 = NULL;
	struct node_list *curr1 = head_1,*curr2 = head_2;
	/* save head_1 as temp */
	struct node_list *temp = head_1;

	/* we need to cut the connection from first linked list to second as we merged them before */
	while(temp)
	{
		if(temp->next == head_2)
		{
			temp->next = NULL;
			break;
		}
		temp = temp->next;
	}

	while(curr1 != NULL && curr2 != NULL)
	{
		/* store current nexts to temp nodes */
		next1 = curr1->next;
		next2 = curr2->next;
		/* point current node of second list to next of first */
		curr2->next = next1;
		curr1->next = curr2;

		curr1 = next1;
		curr2 = next2;

	}
	return head_1;
}

struct node_list* merge_array(struct node_list* a, int na, struct node_list* b, int nb)
{
	/* allocate new array */
	struct node_list *c = (struct node_list*) calloc(na+nb,sizeof(struct node_list));
	/* counters */
	int counter_a = 0,counter_b = 0;

	/* add to array c alternatively */
	for(int i = 0;i < (na+nb);i++)
	{
		if(i % 2 == 0)
		{
			if(counter_a < na)
			{
				c[i].data = a[counter_a].data;
				c[i].number = a[counter_a].number;
				c[i].name = a[counter_a].name;
				counter_a++;
			}
			else
			{
				c[i].data = b[counter_b].data;
				c[i].number = b[counter_b].number;
				c[i].name = b[counter_b].name;
				counter_b++;
			}
		}
		else
		{
			if(counter_b < nb)
			{
				c[i].data = b[counter_b].data;
				c[i].number = b[counter_b].number;
				c[i].name = b[counter_b].name;
				counter_b++;
			}
			else
			{
				c[i].data = a[counter_a].data;
				c[i].number = a[counter_a].number;
				c[i].name = a[counter_a].name;
				counter_a++;
			}
		}
	}

	free(a);
	free(b);
	return c;
}


void insert_array(struct node_list *array,int c,int data,float number,char *name)
{
	array[c].data = data;
	array[c].number = number;
	array[c].name = name;
}


int main()
{
	/*Do not modify anything between 95 and 130 lines.*/
	
	struct node_list *head_1 = NULL;
	struct node_list *head_2 = NULL;
	struct node_list *merged = NULL;
	struct node_list *interleaved = NULL;
	
	insert_end(&head_1,10,1.5,"hello1");
	insert_end(&head_1,30,3.5,"hello3");
	insert_end(&head_1,50,5.5,"hello5");
	 
	insert_end(&head_2,20,2.5,"hello2");
	insert_end(&head_2,40,4.5,"hello4");
	insert_end(&head_2,60,6.5,"hello6");
	
	printf("Print List 1: \n");
	 
	print_list(head_1);
	 
	printf("Print List 2: \n");
	 
	print_list(head_2);
	 
	merged=merge_list(head_1, head_2);
	
	printf("Print List Merged: \n");

    print_list(merged);

	interleaved=merge_interleaved(head_1, head_2);
	
	printf("Print List Interleaved: \n");
	
	print_list(interleaved);
 	
 	/*Do not modify anything between 95 and 130 lines.*/    
 	
	/*YOU CAN MODIFY BELOW THIS LINE FOR ONLY PART 3.*/
	struct node_list *array1 = (struct node_list*) calloc(2,sizeof(struct node_list));
	struct node_list *array2 = (struct node_list*) calloc(3,sizeof(struct node_list));

	insert_array(array1,0,3,4,"oz");
	insert_array(array1,1,3,4,"an");
	insert_array(array2,2,3,4,"gan");
	insert_array(array2,0,3,4,"ar");
	insert_array(array2,1,3,4,"ma");

	print_array(merge_array(array1,2,array2,3),5);
	
	
	
	
	
	
	
	
	
	return 0;
}
