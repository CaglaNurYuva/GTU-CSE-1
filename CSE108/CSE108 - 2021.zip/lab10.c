#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define STARS "\n*******************************************"
/* book struct */
typedef struct {
    char title[100],author[100],subject[100];
    int id,year;
} book;

/* function declerations */
void add_book(book *books,int total_book);
void list_books_id(book *books,int total_book);
void list_books_year(book *books,int total_book);
void find_by_title(book *books,int total_book);
void find_by_author(book *books,int total_book);
void find_by_subject(book *books,int total_book);
book* increase_size(book *books,int current_length);

void main()
{
    /* allocate books array with size 20 */
    book *books = (book*) calloc(20,sizeof(book));
    int opt,sub_opt; /* user menu options */
    int quit = 0; /* if quit program */
    int total_books = 0;
    while(!quit)
    {
        printf("\nMENU");
        printf("\n          1. Add New Book");
        printf("\n          2. List Books");
        printf("\n          3. Exit");
        printf("\n\nChoose : ");
        scanf("%d",&opt);
        switch (opt)
        {
        case 1:
            if(total_books >=20)
            {
                books = increase_size(books,total_books);
                add_book(books,total_books);
                total_books++;
            }
            else
            {
                add_book(books,total_books);
                total_books++;
            }
            break;
        case 2:
            printf(STARS);
            printf("\nSUBMENU");
            printf("\n          1. Get by Title");
            printf("\n          2. Get by Author");
            printf("\n          3. Get by Subject");
            printf("\n          4. Sorted List by Year (DESC)");
            printf("\n          5. List All Books");
            printf("\n          6. EXIT SUBMENU");
            printf("\n\nChoose : ");
            scanf("%d",&sub_opt);
            if(sub_opt == 1)
                find_by_title(books,total_books);
            else if(sub_opt == 2)
                find_by_author(books,total_books);
            else if(sub_opt == 3)
                find_by_subject(books,total_books);
            else if(sub_opt == 4)
                list_books_year(books,total_books);
            else if(sub_opt == 5)
                list_books_id(books,total_books); 
            break;
        case 3:
            quit = 1;
            break;
        default:
            break;
        }
    }
}

void add_book(book *books,int total_book)
{
    /* get book info and add to struct */
    printf(STARS);
    printf("\nPlease enter book title: ");
    scanf(" %[^\n]s",books[total_book].title);
    printf("Please enter book author: ");
    scanf(" %[^\n]s",books[total_book].author);
    printf("Please enter book subject: ");
    scanf(" %[^\n]s",books[total_book].subject);
    printf("Please enter book year: ");
    scanf(" %d",&books[total_book].year);
    books[total_book].id = total_book;

    printf("\nADDED SUCCESSFULLY");
    printf(STARS);
}

void list_books_id(book *books,int total_book)
{
    /* list all books in array by id */
    printf(STARS);
    for(int i = 0;i < total_book;i++)
    {
        printf("\n%d. Book",i+1);
        printf("\nTitle => %s",books[i].title);
        printf("\nAuthor => %s",books[i].author);
        printf("\nSubject => %s",books[i].subject);
        printf("\nYear => %d",books[i].year);
        printf(STARS);
    }
}



void list_books_year(book *books,int total_book)
{
    /* allocate another books array and store books */
    book *books_ = (book*)calloc(total_book,sizeof(book));
    int max = -1,index; /* max year and index */

    for(int i = 0;i < total_book;i++)
    {
        strcpy(books_[i].title,books[i].title);
        strcpy(books_[i].author,books[i].author);
        strcpy(books_[i].subject,books[i].subject);
        books_[i].year = books[i].year;
        books[i].id = books[i].id;
    }
    printf(STARS);
    for(int i = 0;i < total_book;i++)
    {
        /* find max year */
        for(int j = 0;j < total_book;j++)
        {
            if(books_[j].year > max)
            {
                max = books_[j].year;
                index = j;
            }
        }

        printf("\n%d. Book",i+1);
        printf("\nTitle => %s",books_[index].title);
        printf("\nAuthor => %s",books_[index].author);
        printf("\nSubject => %s",books_[index].subject);
        printf("\nYear => %d",books_[index].year);
        printf(STARS);
        
        /* set year of max to -1 to find new max */
        books_[index].year = -1;
        max = -1;
    }

    /* free memory */
    free(books_);
}

void find_by_title(book *books,int total_book)
{
    /* title to search */
    char title[100];
    int flag = 0; /* flag to if book found */

    printf(STARS);
    printf("\nEnter a book title: ");
    fflush(stdin);
    scanf("%[^\n]s",title);
    
    /* search book and print if found */
    for(int i = 0;i < total_book;i++)
    {
        if(strcmp(books[i].title,title) == 0)
        {
            printf("Book Found");
            printf("\nTitle => %s",books[i].title);
            printf("\nAuthor => %s",books[i].author);
            printf("\nSubject => %s",books[i].subject);
            printf("\nYear => %d",books[i].year);
            /* change flag */
            flag = 1;
        }
    }
    if(flag == 0)
        printf("COULD NOT FIND THE BOOK WITH THIS TITLE");
    printf(STARS);
}

void find_by_author(book *books,int total_book)
{
    /* author to search */
    char author[100];
    int flag = 0; /* flag to if book found */

    printf(STARS);
    printf("\nEnter a books Author: ");
    fflush(stdin);
    scanf("%[^\n]s",author);
    
    /* search book and print if found */
    for(int i = 0;i < total_book;i++)
    {
        if(strcmp(books[i].author,author) == 0)
        {
            printf("Book Found");
            printf("\nTitle => %s",books[i].title);
            printf("\nAuthor => %s",books[i].author);
            printf("\nSubject => %s",books[i].subject);
            printf("\nYear => %d",books[i].year);
            /* change flag */
            flag = 1;
        }
    }
    if(flag == 0)
        printf("COULD NOT FIND THE BOOK WITH THIS AUTHOR");
    printf(STARS);
}

void find_by_subject(book *books,int total_book)
{
    /* subject to search */
    char subject[100];
    int flag = 0; /* flag to if book found */

    printf(STARS);
    printf("\nEnter a books subject: ");
    fflush(stdin);
    scanf("%[^\n]s",subject);
    
    /* search book and print if found */
    for(int i = 0;i < total_book;i++)
    {
        if(strcmp(books[i].subject,subject) == 0)
        {
            printf("Book Found");
            printf("\nTitle => %s",books[i].title);
            printf("\nAuthor => %s",books[i].author);
            printf("\nSubject => %s",books[i].subject);
            printf("\nYear => %d",books[i].year);
            /* change flag */
            flag = 1;
        }
    }
    if(flag == 0)
        printf("COULD NOT FIND THE BOOK WITH THIS SUBJECT");
    printf(STARS);
}

book* increase_size(book *books,int current_length)
{
    /* allocate new memory with a size bigger than current_length */
    book *books_ = (book*) calloc(current_length+1,sizeof(book));
    
    /* copy books to new array */
    for(int i = 0;i < current_length;i++)
    {
        strcpy(books_[i].title,books[i].title);
        strcpy(books_[i].author,books[i].author);
        strcpy(books_[i].subject,books[i].subject);
        books_[i].year = books[i].year;
        books[i].id = books[i].id;
    }
    
    /* free older array */
    free(books);
    return books_;
}