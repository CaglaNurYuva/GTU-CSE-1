#include <stdio.h>
#include <string.h>

/* struct for line */
typedef struct {
    float x1,x2,x3,y1,y2,y3,slope;
} line;

/* struct for grades */
typedef struct {
    float midterm,final,homework;
} grades;

typedef struct {
    char *name_surname;
    char *surname;
    int id;
    float midterm,final,homework;
} student;

/* struct for games */
typedef struct {
    char* name;
    char platforms[200][100];
    float score;
} games;

/* function declerations */
void get_coordinates(line *l);
float slope(float x1,float x2,float y1,float y2);
float find_y3(line *l);
void get_students(student *students,int number_of_students);
void find_averages(student *students,grades *grades_,int number_of_students);
void find_student(student *students,int id_to_find,int number_of_students);
void get_games(games *games_,int number_of_games);
float average_score(games *games_,int number_of_games);
void list_games_for_platforms(games *games_,int number_of_games);

void main() {
    /* line to get coordinates and find y3 and slope */
    line l;
    /* number of students and number of games,we will get this from user by input */
    int number_of_students,number_of_games;
    /* grades struct to store average grades */
    grades averages;
    /* student id to find in array */
    int student_id;

    get_coordinates(&l);
    l.slope = slope(l.x1,l.x2,l.y1,l.y2); /* find slope of the line */
    l.y3 = find_y3(&l); /* find y3 of 3rd point on the line */

    /* print those two values */
    printf("Slope of the line = %.2f",l.slope);
    printf("\n Y3 coordinate of the line = %.2f",l.y3);

    /* get number of students */
    printf("\nPlease enter number of students : ");
    scanf("%d",&number_of_students);

    /* create array of students in length of number_of_students */
    student students[number_of_students];

    /* get informations for students */
    get_students(&students[0],number_of_students);
    find_averages(&students[0],&averages,number_of_students); /* find averages of each grade types and store them to averages */

    /* get student id to find in the students from user */
    printf("Please enter student ID to find : ");
    scanf("%d",&student_id),
    /*find student and print */
    find_student(&students[0],student_id,number_of_students);

    /* get number of games */
    printf("\nPlease enter number of games : ");
    scanf("%d",&number_of_games);

    /* create array of games in length of number_of_games */
    games games_[number_of_games];

    /* get games from user */
    get_games(&games_[0],number_of_games);

    /* print average score of games */
    printf("Average score of games : %.2f",average_score(&games_[0],number_of_games));
    /* list games for each platform */
    list_games_for_platforms(&games_[0],number_of_games);
}


/* function to get coordinates of the line */
void get_coordinates(line *l)
{
    /* get x1,x2,y1,y2 for line */
    printf("Please enter x1 of the line : ");
    scanf(" %f",&(l->x1));
    printf("\nPlease enter x2 of the line : ");
    scanf(" %f",&(l->x2));
    printf("\nPlease enter y1 of the line : ");
    scanf(" %f",&(l->y1));
    printf("\nPlease enter y2 of the line : ");
    scanf(" %f",&(l->y2));
    printf("\nPlease enter x3 of the line : ");
    scanf(" %f",&(l->x3));
}

/* function to find slope of the line */
float slope(float x1,float x2,float y1,float y2)
{
    return (y2 -y1) / (x2 - x1);
}

/*function to find y3 of the line */
float find_y3(line *l)
{
    /* first find 'b' of equation */
    float b = (l->y2) - (l->slope * l->x2);

    /* then calculate y3 according to y3 = slope*x3 + b */
    return l->x3 + b; 
}

/* function to get students from user and store to array */
void get_students(student *students,int number_of_students)
{
    /* integer to use in loops */
    int i;
    /* get student informations for all students */
    for(i = 0;i < number_of_students;i++)
    {
        printf("\nPlease enter name and surname of student #%d : ",i+1);
        fflush(stdin);
        scanf(" %[^\n]s",&students[i].name_surname);
        printf("Please enter ID of student #%d : ",i+1);
        scanf(" %d",&students[i].id);
        printf("Please enter midterm grade for student #%d : ",i+1);
        scanf(" %f",&students[i].midterm);
        printf("Please enter final grade for student #%d : ",i+1);
        scanf(" %f",&students[i].final);
        printf("Please enter homework grade for student #%d : ",i+1);
        scanf(" %f",&students[i].homework);
    }
}

/* function to find average grade for each type and store to struct */
void find_averages(student *students,grades *grades_,int number_of_students)
{
    /* floats to store total of each type */
    float t_midterm = 0.0,t_final = 0.0,t_hw = 0.0;

    /* find totals */
    for(int i = 0;i < number_of_students;i++)
    {
        t_midterm += students[i].midterm;
        t_final += students[i].final;
        t_hw += students[i].homework;
    }

    /* store average of them to struct */
    grades_->midterm = t_midterm / (float) number_of_students;
    grades_->final = t_final / (float) number_of_students;
    grades_->homework = t_hw / (float) number_of_students;
}

/* function to find desired student in an array of students and print him/her */
void find_student(student *students,int id_to_find,int number_of_students)
{
    int i;
    /* flag to check if student find */
    int flag = 0;
    for(i = 0;i < number_of_students;i++)
    {
        if(students[0].id == id_to_find)
        {
            flag = 1;
            printf("\n*** FOUND THE STUDENT ***");
            printf("\nNAME AND SURNAME : %s",students[i].name_surname);
            printf("\nID: %d",students[i].id);
            printf("\nMIDTERM: %.2f",students[i].midterm);
            printf("\nFINAL: %.2f",students[i].final);
            printf("\nHOMEWORK: %.2f",students[i].homework);
            break;
        }
    }
    /* if student not found as flag is zero print error */
    if(flag == 0)
        printf("\nERROR Student not found with that ID");
}

/* get games from user */
void get_games(games *games_,int number_of_games)
{
    int i,j;
    /* count of platforms for each game */
    int count;
    for(i = 0;i < number_of_games;i++)
    {
        printf("\nPlease enter name of game #%d",i+1);
        scanf("%s",games_[i].name);
        printf("Please enter count of platforms for %s",games_[i].name);
        scanf("%d",&count);
        for(j = 0;j < count;j++)
        {
            printf("Please enter platform #%d for %s",j+1,games_[i].name);
            scanf("%s",games_[i].platforms[j]);
        }   
        games_[i].platforms[j][0] = '\0'; /* make sure first after all platforms is NULL */
        printf("Please enter score of %s",games_[i].name);
        scanf("%f",&games_[i].score);
    }
}


/* function to return average score of games */
float average_score(games *games_,int number_of_games)
{
    /* float to store total scores */
    float t_score = 0.0;
    int i;
    for(i = 0;i < number_of_games;i++)
    {
        t_score += games_[i].score;
    }
    
    /* return average */
    return t_score / (float) number_of_games;
}


/* function to check if a string array contains a certain string */
int check_contains(char array[][100],char str[],int array_length)
{
    int i;
    /* flag to check */
    int flag = 0;
    for(i = 0;i < array_length;i++)
    {
        if(strcmp(array[i],str) == 0)
        {
            flag = 1;
            break;
        }
    }
    return flag;
}

/* function to list games for each platform */
void list_games_for_platforms(games *games_,int number_of_games)
{
    /* array to store all platforms */
    char platforms[2000][100];
    /* platform count */
    int count;
    int i,j,k;

    /* find all platforms */
    for(i = 0;i < number_of_games;i++)
    {
        for(j = 0;j < 200;j++)
        {
            if(games_[i].platforms[j][0] = '\0')
                break;
            else if(!check_contains(platforms,games_[i].platforms[j],count))
            {
                strcpy(platforms[count++],games_[i].platforms[j]);
            }
        }
    }

    /* list by each platform */
    for(i = 0; i < count; i++)
    {
        printf("\n **** GAMES FOR %s ***",platforms[i]);
        for(j = 0;j < number_of_games;j++)
        {
            for(k = 0;k < 200;k++)
            {
                if(strcmp(games_[j].platforms[k],platforms[i]) == 0)
                {
                    printf("\n%s",games_[i].name);
                    break;
                }
            }
        }
    }
}