#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* MAX for cos function */
#define MAX 200

/* ---- function declerations ---- */
int check_palindrome(int a[],int n);
int search_element(int arr[],int input_number,int index);
float cos_(int n,float x);


void main()
{
    /* array to store user input for check_palindrome */
    int palindrome_ints[50];
    /* counter for user palindrome_ints input */
    int counter = 0;
    /* array to store random integers between 0-100 for search_element */
    int random_elements[20];
    /* array to  search in random_elements */
    int elem;
    /* integers n and x to use in cos function */
    int n,x;
    /* int to use in loops */
    int i;


    /* get user inputs for palindrome check */
    while(counter < 50)
    {
        printf("Please enter number #%d for palindrome check (enter -1000 to stop): ",counter+1);
        scanf("%d",&palindrome_ints[counter]);
        if(palindrome_ints[counter] == -1000)
        {
            palindrome_ints[counter] = '\0';
            break;
        }
        counter++;
    }

    /* check if array is palindrome */ 
    if(!check_palindrome(palindrome_ints,0))
    {
        printf("\nYour array is not palindrome");
    
    }
    else
    {
        printf("\nYour array is palindrome");
    }

    /* fill random_elements */
    srand(time(NULL));
    for(i = 0;i < 20;i++)
    {
        random_elements[i] = (rand() % 99) + 1;
    }


    printf("\nEnter input to search in random integers: ");
    scanf("%d",&elem);

    /* print random array */
    printf("\n\n\nArray of random numbers:\n");
    for(i = 0;i < 19;i++)
    {
        printf("%d ",random_elements[i]);
    }

    printf("\nSarching...");
    /* search element in array */
    if(search_element(random_elements,elem,0))
        printf("\nThe number is in array");
    else
        printf("\nThe number is not in array");


    /* get n and x to use in cos */
    printf("\n\n\nPlease enter 'n' to use in cos function: ");
    scanf("%d",&n);
    printf("Please enter 'x' to use in cos function: ");
    scanf("%d",&x);

    /* find cos and print */
    printf("\nCos Value = %.2f",cos_(n,x));
}



int check_palindrome(int a[],int n)
{
    /* variable to store element count in array and i to use in loops */
    int length,i;

    /* find length of the array */
    for(i = 0,length = 0;i < 50;i++)
    {
        if(a[i] == '\0')
            break;
        else
            length++;
    }

    /* if length is 1 then it is not palindrome */
    if(length == 1)
        return 0;

    /* check by n index */
    if(a[n] == a[length - n -1])
    {
        if(n+1 < length/2)
            check_palindrome(a,n+1);
        else
            return 1;
    }
    else
        return 0;
}


int search_element(int arr[],int input_number,int index)
{
    /* if current index is input_number return 1 */
    if(arr[index] == input_number)
        return 1;
    else
    {
        /* else if this is not last index search next */
        if(index < 19)
            search_element(arr,input_number,index+1);
        /* if last return 0 */
        else
            return 0;
    }
}

float cos_(int n,float x)
{
    if(n + 1 <= MAX)
        return 1-(((x*x)/(2*n-1)*2*n)*(cos_(n+1,x)));
    else
        return 1-((x*x)/(2*n-1)*2*n);
}