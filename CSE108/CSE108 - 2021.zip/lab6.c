#include <stdio.h>
#include <string.h>

/* --- function declerations ----*/
void create_matrix(int m,int n,int (*array)[n]);
void average_finder(int m,int n,int array[m][n]);
void intervew(const char s1, const char s2, char * s3);

void main() 
{
    /* matrixes for average_finder */
    int m1[3][5],m2[4][9];
    /* char arrays to combine and another char array to store combined strings */
    char s1[1000],s2[1000],s3[2000];
    /* integers to store lengths of strings */
    int len_s1 = 0,len_s2 = 0;
    /* integer to use in loops */
    int i;
    /* integer to store current indexes of strings while concentrating */
    int current = 0;


    /* fill matrix 1 */
    create_matrix(3,5,&m1[0]);
    /* fill matrix 2 */
    create_matrix(4,9,&m2[0]);

    /* average_finder for matrix 1 */
    average_finder(3,5,m1);
    /* average_finder for matrix 2 */
    average_finder(4,9,m2);


    /*get first string from user */
    printf("\nEnter String 1 : ");
    scanf("%s",s1);
    /*get second string from user */
    printf("Enter String 2 : ");
    scanf("%s",s2);

    /* find lengths of strings check if they are different */
    len_s1 = 0;
    len_s2 = 0;
    for(i = 0;i < 1000;i++)
    {
        if(s1[i] != '\0')
            len_s1++;
        else
            break; 
    }

    for(i = 0;i < 1000;i++)
    {
        if(s2[i] != '\0')
            len_s2++;
        else
            break; 
    }

    /* if lengths of strings are same get input until user enters strings with different lengths */
    while(len_s1 == len_s2)
    {
        printf("\nPlease enter strings with different lengths!");
        printf("\nEnter String 1 : ");
        scanf("%s",s1);
        printf("Enter String 2 : ");
        scanf("%s",s2);

        len_s1 = 0;
        len_s2 = 0;
        for(i = 0;i < 1000;i++)
        {
            if(s1[i] != '\0')
                len_s1++;
            else
                break; 
        }

        for(i = 0;i < 1000;i++)
        {
            if(s2[i] != '\0')
                len_s2++;
            else
                break; 
        }
    }

    /* if s1 is longer than s2 */
    if(len_s1 > len_s2)
    {
        /* intervew every char pair from strings with same index to s3 */
        for(i = 0;i < len_s2;i++)
        {
            intervew(s1[i],s2[i],&s3[i*2]);
        }
        /* when there is no s2 because s1 is longer,copy remaining part of s1 to end of s3 */
        strncpy(s3 + (i*2),s1 + i,len_s1 - i);
        s3[(i*2) + len_s1 - i] = '\0';
    }

    /* if s2 is longer than s1 */
    else if(len_s2 > len_s1)
    {
        /* intervew every char pair from strings with same index to s3 */
        for(i = 0;i < len_s1;i++)
        {
            intervew(s1[i],s2[i],&s3[i*2]);
        }
        /* when there is no s2 because s1 is longer,copy remaining part of s1 to end of s3 */
        strncpy(s3 + (i*2),s2 + i,len_s2 - i);
        s3[(i*2) + len_s2 - i] = '\0';
    }

    /* print the result string */
    printf("\nResult String : %s",s3);

}



void create_matrix(int m,int n,int (*array)[n])
{
    /* integers to use in loops */
    int i,j;
    /* counter to use while setting values in the matrix */
    int counter = 1;

    /* fill the matrix */
    for(i = 0;i < m;i++)
    {
        for(j = 0;j < n;j++)
        {
            (*(array + i))[j] = 2*counter*counter - 3;
            counter++;
        }
    }
}

void average_finder(int m,int n,int array[m][n])
{
    /* float to store sum */
    float sum = 0;
    /* counter to use while finding average */
    float count = 0;
    /* integers to use in loops */
    int i,j;

    /* print matrix and also find values with sums of even indexes */
    printf("Matrix:\n\n");
    for(i = 0;i < m;i++)
    {
        for(j = 0;j < n;j++)
        {
            printf("%-5d",array[i][j]);
            if((i + j) % 2 == 0)
            {
                sum += array[i][j];
                count++;
            }
        }
        printf("\n");
    }

    /* print the average */
    printf("\nAverage : %.1f\n\n",sum / count);

}



void intervew(const char s1, const char s2, char * s3)
{
    /* set s1 to pointed address in s3 and s2 to address after s3 */
    *s3 = s1;
    *(s3 + 1) = s2;
}

