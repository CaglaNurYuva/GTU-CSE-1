#include <stdio.h>
#include <math.h>

/* -------------- FUNCTION DECLERATIONS -------------- */
int int_addition(int x,int y);
int int_multiplication(int x,int y);
int complex_real_addition(int x_real,int y_real);
int complex_imaginary_addition(int x_img,int y_img);
int complex_real_multiplication(int x_real,int x_img,int y_real,int y_img);
int complex_imaginary_multiplication(int x_real,int x_img,int y_real,int y_img);
void standard_calc();
float area_of_circle(float radius);
float area_of_rectangle(float x,float y);
float area_of_triangle(float x,float y,float z);
void area_perimeter_calc();
float fahrenheit_to_kelvin(float x);
float kelvin_to_fahrenheit(float x);
void temperature_calculator();

/* -------------------- MAIN FUNCTION -------------------- */
void main()
{
    int calctype;
    printf("Please enter the calculator type");
    printf("\n1. Standard Calculator");
    printf("\n2. Area&Perimeter Calculator");
    printf("\n3. Temperature Calculator");
    printf("\n------------------------------\n");
    scanf("%d",&calctype);
    /* call calculator according to user input */
    switch(calctype)
    {
    case 1:
        standard_calc();
        break;
    case 2:
        area_perimeter_calc();
        break;
    case 3:
        temperature_calculator();
        break;
    default:
        printf("Invalid Input\n");
        break;
    }
}


/* ------------ FUNCTIONS FOR STANDARD CALCULATOR --------------- */

/* function for standard integer addition */
int int_addition(int x,int y)
{
    return x + y;
}

/* function for standard integer multiplication */
int int_multiplication(int x,int y)
{
    return x * y;
}

/* function for addtion of real parts of complex numbers */
int complex_real_addition(int x_real,int y_real)
{
    return x_real + y_real;
}

/* function for addtion of imaginary parts of complex numbers */
int complex_imaginary_addition(int x_img,int y_img)
{
    return x_img + y_img;
}

/* function for multiplication of real parts of complex numbers */
int complex_real_multiplication(int x_real,int x_img,int y_real,int y_img)
{
    return x_real * y_real - x_img * y_img;
}

/* function for multiplication of imaginary parts of complex numbers */
int complex_imaginary_multiplication(int x_real,int x_img,int y_real,int y_img)
{
    return x_img * y_real + x_real * y_img;
}

/* func for standard calculator to choose and print outputs */
void standard_calc() {
    int choice,choice2;
    /* Get number type from user */
    printf("\n Enter the number type");
    printf("\n1. Integer");
    printf("\n2. Complex");
    printf("\n-----------------------\n");
    scanf("%d",&choice);
    /*if user chose integer */
    if(choice == 1)
    {
        int x,y;
        /* ask if user wants to addition or multiplication */
        printf("Enter calculation type");
        printf("\n1. Addition");
        printf("\n2. Multiplication");
        printf("\n---------------------\n");
        scanf("%d",&choice2);
        switch (choice2)
        {
        case 1:
            printf("\nEnter the first integer: ");
            scanf("%d",&x);
            printf("Enter the second integer: ");
            scanf("%d",&y);
            printf("Addition of these two numbers = %d\n",int_addition(x,y));
            break;
        case 2:
            printf("\nEnter the first integer: ");
            scanf("%d",&x);
            printf("Enter the second integer: ");
            scanf("%d",&y);
            printf("Multiplication of these two numbers = %d\n",int_multiplication(x,y));
            break;
        default:
            break;
        }
    }
    else if(choice == 2)
    {
        int x_img,x_real,y_img,y_real;
        /* ask if user wants to addition or multiplication */
        printf("Enter calculation type");
        printf("\n1. Addition");
        printf("\n2. Multiplication");
        printf("\n---------------------\n");
        scanf("%d",&choice2);
        /* according to choice get inputs and call functions */
        switch(choice2)
        {
        case 1:
            printf("\nEnter the first complex number (real part first): ");
            scanf("%d",&x_real);
            scanf("%d",&x_img);
            printf("\nEnter the second complex number (real part first): ");
            scanf("%d",&y_real);
            scanf("%d",&y_img);
            printf("Addition of these two numbers = %d + (%di)\n",complex_real_addition(x_real,y_real),complex_imaginary_addition(x_img,y_img));
            break;
        case 2:
            printf("\nEnter the first complex number (real part first): ");
            scanf("%d",&x_real);
            scanf("%d",&x_img);
            printf("\nEnter the second complex number (real part first): ");
            scanf("%d",&y_real);
            scanf("%d",&y_img);
            printf("Multiplication of these two numbers = %d + (%di)\n",complex_real_multiplication(x_real,x_img,y_real,y_img),complex_imaginary_multiplication(x_real,x_img,y_real,y_img));
            break;
        default:
            break;
        }
    }
    else
    {
        printf("Invalid Input\n");
    }
}

/*--------------------- FUNCTIONS FOR  AREA&PERIMETER CALCULATOR -------------------- */


/* function for area of circle */ 
float area_of_circle(float radius)
{
    return 3.14 * radius * radius;
}

/* function for area of rectangle */ 
float area_of_rectangle(float x,float y)
{
    return x * y;
}

/* function for area of triangle */ 
float area_of_triangle(float x,float y,float z)
{
    float s = (x + y + z)/2;
    return sqrt(s * (s - x) * (s - y) * (s - z));
}

/*  function for area&perimeter to get choices and print outputs */
void area_perimeter_calc() {
    int choice;
    /* Get shape type from user */
    printf("\n Enter the number type");
    printf("\n1. Rectangle");
    printf("\n2. Triangle");
    printf("\n3. Circle");
    printf("\n-----------------------\n");
    scanf("%d",&choice);
    /* according to choice get inputs and call functions */
    if(choice == 1)
    {
        float x,y;
        printf("Enter sides of rectangle \n");
        scanf("%f",&x);
        scanf("%f",&y);
        printf("Area of rectangle = %.2f\n",area_of_rectangle(x,y));
    }
    else if(choice == 2)
    {
        float x,y,z;
        printf("Enter sides of triangle \n");
        scanf("%f",&x);
        scanf("%f",&y);
        scanf("%f",&z);
        printf("Area of triangle = %.2f\n",area_of_triangle(x,y,z));
    }
    else if(choice == 3)
    {
        float r;
        printf("Enter the radius of circle\n");
        scanf("%f",&r);
        printf("Area of circle = %.2f\n",area_of_circle(r));
    }
    else
    {
        printf("Invalid Input\n");
    }
}

/* ---------------- FUNCTIONS FOR TEMPERATURE CALCULATOR ------------------------ */


/* fucntion for fahrenheit -> kelvin */
float fahrenheit_to_kelvin(float y)
{
    return ((5.0 / 9.0) * (y - 32)) + 273.15;
}

/* function for kelvin -> fahrenheit */
float kelvin_to_fahrenheit(float x)
{
    return (9 / 5) * (x - 273.15) + 32;
}

/* function for temperature calculator to get choices and print outputs */
void temperature_calculator()
{
    int choice;
    float x;
    /* Get calc type from user */
    printf("\n Enter the calculation type");
    printf("\n1. Fahrenheit to Kelvin");
    printf("\n2. Kelvin to Fahrenheit");
    printf("\n---------------------------\n");
    scanf("%d",&choice);
    /* according to choice call functions */
    if(choice == 1)
    {
        printf("Please enter the temperature in Fahreinheit\n");
        scanf("%f",&x);
        printf("Result = %.2f\n",fahrenheit_to_kelvin(x));
    }
    else if(choice == 2)
    {
        printf("Please enter the temperature in Kelvin\n");
        scanf("%f",&x);
        printf("Result = %.2f\n",kelvin_to_fahrenheit(x));
    }
    else
    {
        printf("Invalid Input\n");
    }
}