#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define FILENAME "country.txt"

/* country struct */
typedef struct {
    char *country;
    char *capital;
    int population;
    bool driving_side;
} country;


/* linked list */
struct country_node {
    char *country;
    char *capital;
    int population;
    bool driving_side;
    struct country_node *next;
};

country *enter_new_country(country **countries,int curr_count);
void write_to_file(country *countries,int count);
struct country_node *read_from_file();
country *increase_size(country *countries,int curr_size);
void print_list(struct country_node *list);

void main()
{
    /* country struct array pointer */
    country *countries = NULL;
    /* linked list pointer */
    struct country_node *list;
    /* current country count and size */
    int count = 0;
    /* int to control end program and get user select */
    int quit = 0,choice;

    while(!quit)
    {
        printf("\n1: Enter new record");
        printf("\n2: Write to file");
        printf("\n3: Read from file");
        printf("\n4: Print the linked list");
        printf("\n5: Exit");
        printf("\n Choice: ");
        scanf("%d",&choice);

        switch (choice)
        {
        case 1:
            countries = enter_new_country(&countries,count);
            count++;
            break;
        case 2:
            write_to_file(countries,count);
            break;
        case 3:
            list = read_from_file();
            break;
        case 4:
            print_list(list);
            break;
        case 5:
            quit = 1;
            break;
        default:
            break;
        }
    }
}

/* function to increase size of array */
country *increase_size(country *countries,int curr_size)
{
    return (country*) realloc(countries,curr_size + 1);
}

/* function to enter new country */
country *enter_new_country(country **countries,int curr_count)
{
    /* variables to use while getting info from user */
    char *country_name = (char*) calloc(1000,1);
    char *capital = (char*) calloc(1000,1);
    int population;
    int driving_side;

    /* increase size first */
    *countries = increase_size(*countries,curr_count);

    /* get infos from user */
    printf("\n\nCountry Name: "); scanf("%s",country_name);
    printf("Capital: "); scanf("%s",capital);
    printf("Population: "); scanf("%d",&population);
    printf("Do people in %s drive on the right side? (Yes:1 No:0): ",country_name); scanf("%d",&driving_side);

    /* copy to last element of struct array */
    countries[curr_count]->country = (char*) calloc(strlen(country_name),1);
    countries[curr_count]->capital = (char*) calloc(strlen(capital),1);
    strcpy(countries[curr_count]->country,country_name);
    strcpy(countries[curr_count]->capital,capital);
    countries[curr_count]->population = population;
    countries[curr_count]->driving_side = driving_side;

    /* free temp strings */
    free(country_name);
    free(capital);
    
    return *countries;
}

/* function to write struct array to file */
void write_to_file(country *countries,int count)
{
    /* open file in write mode */
    FILE *fptr = fopen(FILENAME,"w");

    /* write each element to file */
    for(int i = 0;i < count;i++)
    {
        fprintf(fptr,"%s %s %d",(countries + i)->country,(countries + i)->capital,(countries + i)->population);
        if((countries + i)->driving_side)
            fprintf(fptr," Right\n");
        else
            fprintf(fptr," Left\n");
    }

    /* close the file */
    fclose(fptr);
}



struct country_node *read_from_file()
{
    /* allocate memory for head first */
    struct country_node *head = NULL;
    /* char array to store line */
    char line[2000];
    /* char pointer to use while strtok */
    char *token;

    /* open file */
    FILE *fptr = fopen(FILENAME,"r");

    /* get lines */
    while(fgets(&line[0],2000,fptr))
    {
        /* remove trailing \n */
        line[strcspn(&line[0],"\n")] = '\0';

        /* check if it is  first entry */
        if(head)
        {
            struct country_node *node = (struct country_node*) calloc(1,sizeof(struct country_node));
            node->next = NULL;
            /* get infos by strtoks */
            token = strtok(line," ");
            node->country = (char*) calloc(strlen(token),1);
            strcpy(node->country,token);
            token = strtok(NULL," ");
            node->capital = (char*) calloc(strlen(token),1);
            strcpy(node->capital,token);
            token = strtok(NULL," ");
            node->population = atoi(token);
            token = strtok(NULL," ");
            if(strcmp("Right",token) == 0)
                node->driving_side = true;
            else
                node->driving_side = false;
            
            head->next = node;
            head = node;
        }
        else
        {
            head = (struct country_node*) calloc(1,sizeof(struct country_node));
            head->next = NULL;
            /* get infos by strtoks */
            token = strtok(line," ");
            head->country = (char*) calloc(strlen(token),1);
            strcpy(head->country,token);
            token = strtok(NULL," ");
            head->capital = (char*) calloc(strlen(token),1);
            strcpy(head->capital,token);
            token = strtok(NULL," ");
            head->population = atoi(token);
            token = strtok(NULL," ");
            if(strcmp("Right",token) == 0)
                head->driving_side = true;
            else
                head->driving_side = false;
        }
    }

    fclose(fptr);

    return head;
}


void print_list(struct country_node *list)
{
    printf("\nList:");
    /* print list until node is null */
    while(list)
    {
        printf("\nCountry:  %-15s Capital:   %-10s Population: %-10d",list->country,list->capital,list->population);
        if(list->driving_side)
            printf(" Driving Side: Right");
        else
            printf(" Driving Side: Left");
        
        list = list->next;
    }
}
