/* 

The variable names that used in this file have no relation with the ones in the pdf file. 

<?> in the functions means something other than void, you should find the correct type for these functions.

*/

#include <stdio.h>

void trigonometry(int a, int b, int c)
{
    return;
}

void trigonometry_calculation(int a, int b, int c)
{
    double tan,sin,cos; 
    /* Convert integer variables to double while dividing */
    sin = (double)a/(double)c; 
    cos = (double)b/(double)c;
    tan = (double)a/(double)b;
    printf("sinx = %.2f\n",sin);
    printf("cosx = %.2f\n",cos);
    printf("tanx = %.2f\n",tan);
}

long int age_calculation(int x)
{
    /* Convert years to seconds and return */
    long int seconds = x*60*60*24*365;
    return seconds;
}


void age(int x)
{
    /* Call calculation function and print */
    long int age_in_seconds = age_calculation(x);
    printf("\nYou are %ld seconds old",age_in_seconds);
}



int main()
{
    int a,b,c,x;
    printf("To calculate sinx,cosx and tanx please enter a,b and c\n");
    printf("a: ");
    scanf("%d",&a);
    printf("b: ");
    scanf("%d",&b);
    printf("c: ");
    scanf("%d",&c);
    trigonometry_calculation(a,b,c);
    printf("To calculate your age in seconds please enter your age\n");
    printf("Your age: ");
    scanf("%d",&x);
    age(x);
    return 0;
}