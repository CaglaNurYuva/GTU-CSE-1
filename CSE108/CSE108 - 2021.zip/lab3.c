#include <stdio.h>


/* --- function declerations --- */
int find_max_distance(int num_inputs);
void find_odd_average();


/* main function */
void main()
{
    int max_distance = find_max_distance(5);
    printf("Max dis between two consecutive numbers: %d",max_distance);
    find_odd_average();
}


int find_max_distance(int num_inputs)
{
    /* integer to store lastest input and input before lastest */
    int last = 0,before_last = 0;
    /* counter to check how many numbers we got from input */
    int counter;
    /* variable to store max difference */
    int max = 0;

    /* use loop as many as num_inputs */
    for(counter = 0;counter < num_inputs;counter++)
    {
        /* first put lastest input to before_last */
        before_last = last;
        /* scan input in every lap */
        printf("%d : ",counter+1);
        scanf("%d",&last);

        /*check if difference between last and before last is higher than max */
        if(abs(last - before_last) > max)
            max = abs(last - before_last);
    }

    /* return difference between max and min */
    return max;
}



void find_odd_average()
{
    /*variables to store total of odd positive numbers and count of them */
    double total = 0,count = 0;
    /* total lap counter to print how many numbers got from user */
    int counter = 0;
    /* integer to store input */
    int input = 0;
    /* double to store average of odd numbers */
    double average;

    printf("\n\nPlease enter positive numbers (and -1 to stop entering)\n");
    
    /*start getting inputs continue until input is -1 */
    while(input != -1)
    {
        /* get input in every lap */
        printf("%d: ",counter+1);
        scanf("%d",&input);

        /*check if it is positive and odd number */
        if(input > 0 && input % 2 != 0)
        {
            /* if it is add to total and increase count of odd positive numbers so far */
            total += input;
            count ++;
        }

        /* increase counter in every lap */
        counter ++;
    }

    /* find average by dividing total to count of odd positive numbers */
    average = total / count;

    /* print average */
    printf("\nAverage of odd numbers: %.2lf",average);


}
