#include <stdio.h>


/* -- function declerations -- */
void russian_multiplication(unsigned int*  multiplicand,unsigned int*multiplier);
void  multiply_polynomials(double*  a3,  double*  a2,  double*  a1,  double*  a0,  double*  b3, double* b2, double* b1, double b0);


/* main function */
void main() {
    /* variable declerations to call functions */
    int multiplicand,multiplier;
    double a3,a2,a1,a0,b3,b2,b1,b0;

    /* get user input for first function */
    printf("Multiplicand = ");
    scanf("%d",&multiplicand);
    printf("Multiplier = ");
    scanf("%d",&multiplier);

    /* call russian_multiplication */
    printf("%d * %d = ",multiplicand,multiplier);
    russian_multiplication(&multiplicand,&multiplier);
    /* print the results of multiplication according to algorithm */
    printf("%d",multiplicand);
    printf("\nMultiplier = %d",multiplier);


    /* get coefficients from user to multiply polynoms */
    printf("\nCoefficients of first polynomial = ");
    scanf("%lf %lf %lf %lf",&a3,&a2,&a1,&a0);
    printf("Coefficients of second polynomial = ");
    scanf("%lf %lf %lf %lf",&b3,&b2,&b1,&b0);

    /*multiply polynomials by our function */
    multiply_polynomials(&a3,&a2,&a1,&a0,&b3,&b2,&b1,b0);
    /* print results */
    printf("%.2lfx^6 %+.2lfx^5 %+.2lfx^4 %+.2lfx^3 %+.2lfx^2 %+.2lfx %+.2lf",a3,a2,a1,a0,b3,b2,b1);
}

void russian_multiplication(unsigned int*  multiplicand,unsigned int*multiplier)
{
    /* variable declerations */

    /* total variable to store multiplicand with odd multipliers */
    int total = 0;

    /* check algorithm for initial multiplier and multiplicand */
    if(*multiplier % 2 != 0)
        total += *multiplicand;

    /* continue to this until multiplier is 1 by dividng multiplier to 2 and multiplying multiplicand by 2 in every lap */
    do
    {
        *multiplier /= 2;
        *multiplicand *= 2;
        
        if(*multiplier % 2 != 0)
            total += *multiplicand;
    } while(*multiplier != 1);


    /* send total to main function with multiplicand */
    *multiplicand = total;
}

void  multiply_polynomials  (double*  a3,  double*  a2,  double*  a1,  double*  a0,  double*  b3, double* b2, double* b1, double b0)
{
    /* decleraing variables for result polynomial */
    double c6 = 0,c5 = 0,c4 = 0,c3 = 0,c2 = 0,c1 = 0,c0 = 0;

    /* first check for total of six degree multiplies */
    c6 +=  *a3 * *b3;

    /*fifth degree */
    c5 += *a2 * *b3;
    c5 += *a3 * *b2;

    /* forth degree */
    c4 += *a3 * *b1;
    c4 += *a2 * *b2;
    c4 += *a1 * *b3;

    /* third degree */
    c3 += *a3 * b0;
    c3 += *a2 * *b1;
    c3 += *a1 * *b2;
    c3 += *a0 * *b3;

    /* second degree */
    c2 += *a2 * b0;
    c2 += *a1 * *b1;
    c2 += *a0 * *b2;

    /* first degree */
    c1 += *a1 * b0;
    c1 += *a0 * *b1;

    /*zero degree */
    c0 += *a0 * b0;


    /* 
    now send them to main through pointers 
    c6 => a3
    c5 => a2
    c4 => a1
    c3 => a0
    c2 => b3
    c1 => b2
    c0 => b1
    */
    *a3 = c6;
    *a2 = c5;
    *a1 = c4;
    *a0 = c3;
    *b3 = c2;
    *b2 = c1;
    *b1 = c0;
}