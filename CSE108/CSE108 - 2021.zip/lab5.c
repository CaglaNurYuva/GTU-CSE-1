#include <stdio.h>
#include <stdlib.h>

/* function declerations */
void expression0(int x, int *result);
void expression1 (int x, int *result);
void expression2 (int x, int *result);
void addition(void (*func)(int, int *), int *sum, int n);
void calculation(int  *sumArray, int n);
void createArray(int (*array)[10]);


void main() {
    /* variable declerations */

    /* user input 'n' for sum of expressions */
    int n;
    /* array for sums of calculation */
    int sums[3];
    /* 2D array for createArray function */
    int array[10][10];
    /* integers for loops */
    int i,j;
    /* flag int to check if user entered invalid input */
    int flag = 0;

    /* get 'n' from user for part1 */
    printf("Please enter 'n' for calculation of expressions: ");
    scanf("%d",&n);

    /* calculate expressions */
    calculation(&sums[0],n);

    /* print results of expressions */
    printf("\nSum of expression0: %d",sums[0]);
    printf("\nSum of expression1: %d",sums[1]);
    printf("\nSum of expression2: %d\n\n",sums[2]);

    /* create matrix */
    createArray(&array[0]);
    
    /*print the matrix */
    printf("Matrix : \n\n");
    for(i = 0;i < 10;i++)
    {
        for(j = 0;j < 10;j++)
        {
            printf("%d ",array[i][j]);
        }
        printf("\n");
    }

    while(flag != 1)
    {
        /* get row and column in each lap */
        printf("\n\nWhich element of the matrix do you want to reach?\n");
        printf("i: ");
        scanf("%d",&i);
        printf("j: ");
        scanf("%d",&j);

        /* check if input is valid */
        if(i < 10 && i > -1 && j < 10 && j > -1)
            /* if it is valid print the value */
            printf("%d. row %d. column of matrix is %d",i,j,array[i][j]);
        else
        {
            /* if it is invalid change flag and exit the loop */
            flag = 1;
            printf("Invalid input. Terminating...");
        }
    }
}


void expression0(int x, int *result)
{
    /* set result to pointed integer for expression0 */
    *result = (x*x) + 5;
}

void expression1(int x, int *result)
{
     /* set result to pointed integer for expression1 */
    *result = (2*x) + 1;
}

void expression2(int x, int *result)
{
     /* set result to pointed integer for expression2 */
    *result = x*x;
}

void addition(void (*func)(int, int *), int *sum, int n)
{  
    /* variable int to store results from expression voids */
    int result;
    /* int to use in loops */
    int i;

    /* get result for the expression in each integer between 0 and n and add to pointed sum integer */
    for(i=0;i<=n;i++)
    {
        (*func)(i,&result);
        *sum += result;
    }

}

void calculation(int  *sumArray, int n)
{
    /*int to store sums */
    int sum = 0;

    /*calculate the sum for expression0*/
    addition(*expression0,&sum,n);
    /* assign it to first index of sumArray and set sum to zero */
    *sumArray = sum;
    sum = 0;

    /*calculate the sum for expression0*/
    addition(*expression1,&sum,n);
    /* assign it to second index of sumArray by increasing pointed address by 1 and set sum to zero */
    *(sumArray+1) = sum;
    sum = 0;

    /*calculate the sum for expression0*/
    addition(*expression2,&sum,n);
    /* assign it to second index of sumArray by increasing pointed address by 2  */
    *(sumArray+2) = sum;
}


void createArray(int (*array)[10])
{
    /* ints for loops */
    int i,j;

    /* fill array with nested loop with random numbers between 10 and 100 */
    for(i = 0 ;i < 10;i++)
    {
        for(j = 0;j < 10;j++)
        {
            (*(array+i))[j] = rand() % 90 + 10;
        }
    }
}
