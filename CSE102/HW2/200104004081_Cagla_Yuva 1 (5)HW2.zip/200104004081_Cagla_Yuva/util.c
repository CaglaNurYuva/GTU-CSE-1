#include <stdio.h>
#include <math.h>
#include "util.h"

/* Example decision tree - see the HW2 description */
int dt0(int t, double p, double h, char s, int w) {
    int r = 0;
    if (t>35 && w!=3) r = 1;
    else if (t<=35 && s==0) r = 1;
    return r;
}

/* Provide your implementations for all the requested functions here */

/* The trees that are used in the first problem. */
char dt1a(double PL, double PW, double SL, double SW) {
    char r;
    if(PL<2.45) r = 'a';
    else if(!(PL<2.45) && !(PW<1.75)) r = 'b';
    else if(!(PL<2.45) && PW<1.75 && !(PL<4.95)) r = 'b';
    else if(!(PL<2.45) && PW<1.75 && PL<4.95 && !(PW<1.65)) r = 'b';
    else if(!(PL<2.45) && PW<1.75 && PL<4.95 && PW<1.65) r = 'c';
    return r;
} /* End of dt1a */


char dt1b(double PL, double PW, double SL, double SW) {
    char r;
    if(PL<2.55) r = 'a';
    else if(!(PL<2.55) && !(PW<1.69)) r = 'b';
    else if(!(PL<2.55) && PW<1.69 && !(PL<4.85)) r = 'b';
    else if(!(PL<2.55) && PW<1.69 && PL<4.85) r = 'c';
    return r;
} /* End of dt1b */


/* The trees that are used in the second problem. */
double dt2a(double x1, double x2, double x3, int x4, int x5) {
    double r;
    if(x1<31.5 && x2>-2.5) r = 5.0;
    else if(x1<31.5 && !(x2>-2.5) && ((x2-0.1<=x1) && (x1<=x2+0.1))) r = 2.1;
    else if(x1<31.5 && !(x2>-2.5) && !((x2-0.1<=x1) && (x1<=x2+0.1))) r = -1.1;
    else if(!(x1<31.5) && (-1<=x3 && x3<=2)) r = +1.4;
    else if(!(x1<31.5) && !(-1<=x3 && x3<=2) && (x4 && x5)) r = -2.23;
    else if(!(x1<31.5) && !(-1<=x3 && x3<=2) && !(x4 && x5)) r = +11.0;
    return r;
} /* End of dt2a */


double dt2b(double x1, double x2, double x3, int x4, int x5) {
    double r;
    if((12<x1 && x1<22) && x3>(5.0/3.0)) r = -2.0;
    else if((12<x1 && x1<22) && !(x3>5.0/3.0) && ((x1-0.1<=x3) && (x3<=x1+0.1))) r = 1.01;
    else if((12<x1 && x1<22) && !(x3>5.0/3.0) && !((x1-0.1<=x3) && (x3<=x1+0.1))) r = -8;
    else if(!(12<x1 && x1<22) && (x4 && x5)) r = -1;
    else if(!(12<x1 && x1<22) && !(x4 && x5) && (-1<=x2 && x2<=2)) r = (-1.0/7.0);
    else if(!(12<x1 && x1<22) && !(x4 && x5) && !(-1<=x2 && x2<=2)) r = (sqrt(2)/3.0); 
    return r;
} /* End of dt2b */


/* The trees that are used in the third problem. */
char dt3a(double weight, double age, int is_ShortHair, int eye_color, int fur_color) {
    char r;

    if(fur_color <= 4 && fur_color <= 2 && is_ShortHair == 1 && eye_color >= 2) r = 'a';
    else if(fur_color <= 4 && fur_color <= 2 && is_ShortHair == 1 && !(eye_color >= 2)) r = 'b'; 
    else if(fur_color <= 4 && fur_color <= 2 && !(is_ShortHair == 1) && eye_color<=1 && weight<4.5) r = 'c'; 
    else if(fur_color <= 4 && fur_color <= 2 && !(is_ShortHair == 1) && eye_color<=1 && !(weight<4.5)) r = 'd';
    else if(fur_color <= 4 && fur_color <= 2 && !(is_ShortHair == 1) && !(eye_color<=1) && age<=11) r = 'e';
    else if(fur_color <= 4 && fur_color <= 2 && !(is_ShortHair == 1) && !(eye_color<=1) && !(age<=11)) r = 'f'; 
    else if(fur_color <= 4 && !(fur_color <= 2) && (fur_color == 4) && (is_ShortHair == 1)) r = 'g';
    else if(fur_color <= 4 && !(fur_color <= 2) && (fur_color == 4) && !(is_ShortHair == 1)) r = 'h';
    else if(fur_color <= 4 && !(fur_color <= 2) && !(fur_color == 4) && (age>13.5)) r = 'i';
    else if(fur_color <= 4 && !(fur_color <= 2) && !(fur_color == 4) && !(age>13.5)) r = 'j';
    else if(!(fur_color<=4) && (is_ShortHair == 1) && fur_color == 5 && eye_color == 3) r = 'k'; 
    else if(!(fur_color <= 4) && (is_ShortHair == 1) && fur_color == 5 && !(eye_color == 3))  r = 'l'; 
    else if(!(fur_color <= 4) && (is_ShortHair == 1) && !(fur_color == 5) && fur_color == 8)  r = 'm';
    else if(!(fur_color <= 4) && (is_ShortHair == 1) && !(fur_color == 5) && !(fur_color == 8))  r = 'n'; 
    else if(!(fur_color <= 4) && !(is_ShortHair == 1) && fur_color>7 && weight > 7.5)  r = 'o';
    else if(!(fur_color <= 4) && !(is_ShortHair == 1) && fur_color>7 && !(weight > 7.5))  r = 'p';
    else if(!(fur_color <= 4) && !(is_ShortHair == 1) && !(fur_color>7) && fur_color>=6)  r = 'r';
    else if(!(fur_color <= 4) && !(is_ShortHair == 1) && !(fur_color>7) && !(fur_color>=6) && age>14)  r = 's'; 
    else if(!(fur_color <= 4) && !(is_ShortHair == 1) && !(fur_color>7) && !(fur_color>=6) && !(age>14))  r = 't';
    return r;
} /* End of dt3a */


char dt3b(double weight, double age, int is_ShortHair, int eye_color, int fur_color) {
    char r;

    if(eye_color<=2 && is_ShortHair==1 && fur_color==8) r = 'm';
    else if(eye_color<=2 && is_ShortHair==1 && !(fur_color==8) && eye_color==1) r = 'b';
    else if(eye_color<=2 && is_ShortHair==1 && !(fur_color==8) && !(eye_color==1) && fur_color<4 && fur_color==3) r = 'j';
    else if(eye_color<=2 && is_ShortHair==1 && !(fur_color==8) && !(eye_color==1) && fur_color<4 && !(fur_color==3)) r = 'a';
    else if(eye_color<=2 && is_ShortHair==1 && !(fur_color==8) && !(eye_color==1) && !(fur_color<4) && fur_color==5) r = 'l';
    else if(eye_color<=2 && is_ShortHair==1 && !(fur_color==8) && !(eye_color==1) && !(fur_color<4) && !(fur_color==5) && fur_color==4) r = 'g';
    else if(eye_color<=2 && is_ShortHair==1 && !(fur_color==8) && !(eye_color==1) && !(fur_color<4) && !(fur_color==5) && !(fur_color==4)) r = 'u';
    else if(eye_color<=2 && !(is_ShortHair==1) && (fur_color==5 || fur_color==3)) r = 't';
    else if(eye_color<=2 && !(is_ShortHair==1) && !(fur_color==5 || fur_color==3) && fur_color==8 && eye_color==1) r = 'v'; 
    else if(eye_color<=2 && !(is_ShortHair==1) && !(fur_color==5 || fur_color==3) && fur_color==8 && !(eye_color==1))  r = 'p';
    else if(eye_color<=2 && !(is_ShortHair==1) && !(fur_color==5 || fur_color==3) && !(fur_color==8) && fur_color<=4) r = 'd';
    else if(eye_color<=2 && !(is_ShortHair==1) && !(fur_color==5 || fur_color==3) && !(fur_color==8) && !(fur_color<=4)) r = 'r';
    else if(!(eye_color<=2) && weight>=6.8 && (fur_color>5 && fur_color<8) && weight>9) r = 'y';
    else if(!(eye_color<=2) && weight>=6.8 && (fur_color>5 && fur_color<8) && !(weight>9) && is_ShortHair==1) r = 'z'; 
    else if(!(eye_color<=2) && weight>=6.8 && (fur_color>5 && fur_color<8) && !(weight>9) && !(is_ShortHair==1)) r = 'w'; 
    else if(!(eye_color<=2) && weight>=6.8 && !(fur_color>5 && fur_color<8) && age>=11) r = 'o';
    else if(!(eye_color<=2) && weight>=6.8 && !(fur_color>5 && fur_color<8) && !(age>=11)) r = 'i';
    else if(!(eye_color<=2) && !(weight>=6.8) && fur_color>=6 && fur_color==8) r = '+';
    else if(!(eye_color<=2) && !(weight>=6.8) && fur_color>=6 && !(fur_color==8)) r = 'n';
    else if(!(eye_color<=2) && !(weight>=6.8) && !(fur_color>=6) && (fur_color==5 || fur_color==3) && eye_color==3 && is_ShortHair==1) r = 'k';
    else if(!(eye_color<=2) && !(weight>=6.8) && !(fur_color>=6) && (fur_color==5 || fur_color==3) && eye_color==3 && !(is_ShortHair==1)) r = 's';
    else if(!(eye_color<=2) && !(weight>=6.8) && !(fur_color>=6) && (fur_color==5 || fur_color==3) && !(eye_color==3)) r = '-';
    else if(!(eye_color<=2) && !(weight>=6.8) && !(fur_color>=6) && !(fur_color==5 || fur_color==3) && fur_color<4 && fur_color==1) r = 'f';
    else if(!(eye_color<=2) && !(weight>=6.8) && !(fur_color>=6) && !(fur_color==5 || fur_color==3) && fur_color<4 && !(fur_color==1)) r = 'e';
    else if(!(eye_color<=2) && !(weight>=6.8) && !(fur_color>=6) && !(fur_color==5 || fur_color==3) && !(fur_color<4)) r = 'h';
    return r;
} /* End of dt3b */


void print_result(char a, int problem_selection) {

    /* First problem's results are going to be printed. */
    if(problem_selection==1) {
        printf("Result of P1: ");
            switch(a) {
                case 'a':
                    printf("Setosa\n");
                    break;
                case 'b':
                    printf("Virginica\n");
                    break;
                case 'c':
                    printf("Versicolor\n");
                    break;      
            }
    }

    /* Third problem's results are going to be printed. */
    else if(problem_selection==3) {
        printf("Result of P3: ");
            switch(a) {
                case 'a':
                    printf("Russian white cat\n");
                    break;
                case 'b':
                    printf("Siamese cat\n");
                    break;
                case 'c':
                    printf("Turkish Angora cat\n");
                    break;
                case 'd':
                    printf("Burmese cat\n");
                    break;
                case 'e':
                    printf("Himalayan cat\n");
                    break;
                case 'f':
                    printf("Chinchilla cat\n");
                    break;  
                case 'g':
                    printf("Abyssinian cat\n");
                    break; 
                case 'h':
                    printf("Persian cat\n");
                    break; 
                case 'i':
                    printf("Norwegian Forest cat\n");
                    break; 
                case 'j':
                    printf("American Shorthair\n");
                    break; 
                case 'k':
                    printf("Russian Blue cat\n");
                    break; 
                case 'l':
                    printf("British Shorthair cat\n");
                    break; 
                case 'm':
                    printf("Bombay cat\n");
                    break; 
                case 'n':
                    printf("Pixie Bob cat\n");
                    break; 
                case 'o':
                    printf("Maine Coon cat\n");
                    break; 
                case 'p':
                    printf("Chantilly cat\n");
                    break; 
                case 'r':
                    printf("Siberian cat\n");
                    break; 
                case 's':
                    printf("Nebelung cat\n");
                    break;
                case 't':
                    printf("Scottish Fold cat\n");
                    break;        
                case 'u':
                    printf("Ocicat cat\n");
                    break;
                case 'v':
                    printf("Ojos Azules cat\n");
                    break;
                case 'y':
                    printf("Savannah cat\n");
                    break;
                case 'z':
                    printf("California Spangled cat\n");
                    break;
                case 'w':
                    printf("Mankx cat\n");
                    break;   
                case '+':
                    printf("Tuxedo cat\n");
                    break;
                case '-':
                    printf("Scottish Straight cat\n");
                    break;                
        }
    }
} /* End of print_result */

