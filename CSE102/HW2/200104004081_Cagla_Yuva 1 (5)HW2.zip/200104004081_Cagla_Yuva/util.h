#ifndef _UTIL_H_
#define _UTIL_H_

#define CLOSE_ENOUGH 0.001

/* Example decision tree - see the HW2 description */
int dt0(int t, double p, double h, char s, int w);

/* Write the prototype of the functions implementing the decision trees for the third problem */

/* First problem's functions */
char dt1a(double PL, double PW, double SL, double SW);
char dt1b(double PL, double PW, double SL, double SW);

/* Second problem's functions */
double dt2a(double x1, double x2, double x3, int x4, int x5);
double dt2b(double x1, double x2, double x3, int x4, int x5);

/* Third problem's functions */
char dt3a(double weight, double age, int is_ShortHair, int eye_color, int fur_color);
char dt3b(double weight, double age, int is_ShortHair, int eye_color, int fur_color);
void print_result(char a, int problem_selection);

#endif /* _UTIL_H_ */