#include <stdio.h>
#include <stdlib.h>
#include "util.h"


int main() {

    /* First problem and second problem's variables */
    int problem_selection = 1, x4, x5;
    double PL, PW, SL, SW, x1, x2, x3, result_dt2a, result_dt2b, greater_result, smaller_result; 
    char result_dt1a, result_dt1b, result_dt3a, result_dt3b; 

    /* Third problem's variables */
    double weight, age;
    int is_ShortHair, eye_color, fur_color;


    /* Ask for the problem selection (1,2,3) */
    do {
        printf("\nEnter -1 to quit the program\n");
        printf("Attention! your problem selection has to be an integer value! Otherwise the program won't work as you wish.\n");
        printf("Enter which problem you want to select (1-2-3): ");
        scanf("%d",&problem_selection);

        /* Quitting condition */
        if(problem_selection == -1) {
            printf("Quitting...");
            return (0);
        }

        /* First problem */
        if(problem_selection == 1) {

            /* Getting inputs from the user */
            printf("\nEnter PL (it will be a double value): ");
            scanf("%lf", &PL);
            printf("Enter PW (it will be a double value): ");
            scanf("%lf", &PW);
            printf("Enter SL (it will be a double value): ");
            scanf("%lf", &SL);
            printf("Enter SW (it will be a double value): ");
            scanf("%lf", &SW);

            /* Getting results from the respective function */
            result_dt1a = dt1a(PL, PW, SL, SW);
            result_dt1b = dt1b(PL, PW, SL, SW);

            /* Printing results in accordance with some requirements */
            printf("\n");
            if(result_dt1a == result_dt1b) {
                print_result(result_dt1a, problem_selection);
            }    

            else if(result_dt1a != result_dt1b) {
                print_result(result_dt1a, problem_selection);
                print_result(result_dt1b, problem_selection);
            } 
        }

        /* Second problem */
        else if(problem_selection == 2) {

            /* Getting inputs from the user */
            printf("\nEnter x1 (it will be a double value): ");
            scanf("%lf", &x1);
            printf("Enter x2 (it will be a double value): ");
            scanf("%lf", &x2);
            printf("Enter x3 (it will be a double value): ");
            scanf("%lf", &x3);

            /* Getting binary values */
            do{
                printf("Enter x4 (it will be 1 or 0): ");
                scanf("%d",&x4);
                if(x4 != 1 && x4 != 0) {
                    printf("Unvalid value\n");
                }

            }while(x4 != 1 && x4 != 0);

            do{
                printf("Enter x5 (it will be 1 or 0): ");
                scanf("%d", &x5);
                if(x5 != 1 && x5 != 0) {
                    printf("Unvalid value\n");
                }

            }while(x5 != 1 && x5 != 0);
          

            /* Getting results from the respective function */
            result_dt2a = dt2a(x1, x2, x3, x4, x5);
            result_dt2b = dt2b(x1, x2, x3, x4, x5);

            /* Printing results in accordance with some requirements */
            if(result_dt2a == result_dt2b) {
                printf("\nResult of P2: %c%.2lf\n", (result_dt2a == 1.4 || result_dt2a == 11.0)? '+' : ' ', result_dt2a); 
            }    

            else if(result_dt2a != result_dt2b) {

                if(result_dt2a - result_dt2b < 0) {
                    greater_result = result_dt2b;
                    smaller_result = result_dt2a;
                }

                else if(result_dt2a - result_dt2b > 0) {
                    greater_result = result_dt2a;
                    smaller_result = result_dt2b;
                }

            
                /* If results close enough, print their average, otherwise, print both of them */
                if(greater_result - smaller_result <= CLOSE_ENOUGH) {
                    printf("\nResult of P2: %.2lf\n",((result_dt2a + result_dt2b)/2.0)) ;
                }
        
                else if(!(greater_result - smaller_result <= CLOSE_ENOUGH)) {
                    printf("\nResult of P2: %c%.2lf\n", (result_dt2a == 1.4 || result_dt2a == 11.0)? '+' : ' ', result_dt2a) ;
                    printf("Result of P2:  %.2lf\n", result_dt2b) ;
                }
            }
    
        }


        /* Third problem */
        else if(problem_selection == 3) {

            /* Getting inputs from the user */
            printf("\nEnter your cat's weight (it is a double value): ");
            scanf("%lf", &weight);
            printf("Enter your cat's age (it is a double value): ");
            scanf("%lf", &age);
 

            /* Making sure that there is no erroneous input */
            do{
                printf("Does your cat have short fur? (yes = 1, no = 0): ");
                scanf("%d", &is_ShortHair);

                if(is_ShortHair != 0 && is_ShortHair != 1) {
                    printf("Unvalid value\n");
                }

            }while(is_ShortHair!= 0 && is_ShortHair != 1);

            printf("\n----------------- Eye Color List -----------------\n");
            printf("1 - blue\n");
            printf("2 - yellow\n");
            printf("3 - green\n");
            printf("4 - hazel\n");
            printf("5 - orange\n");
            printf("6 - nut brown\n");
            printf("7 - copper\n");
            printf("What color are your cat's eyes?\n");


            /* Making sure that there is no erroneous input */
            do{
                printf("Enter a number that is indicated above(1-7): ");
                scanf("%d", &eye_color);

                if(!(eye_color>=1 && eye_color<=7)) {
                    printf("Unvalid selection\n");
                }

            }while(!(eye_color>=1 && eye_color<=7));
    

            printf("\n----------------- Fur Color List -----------------\n");
            printf("1 - white\n");
            printf("2 - cream\n");
            printf("3 - light grey\n");
            printf("4 - yellow\n");
            printf("5 - dark grey\n");
            printf("6 - light brown\n");
            printf("7 - dark brown\n");
            printf("8 - black\n");
            printf("What color mainly are your cat's fur?\n");

            do{
                printf("Enter a number that is indicated above(1-8): ");
                scanf("%d", &fur_color);

                if(!(fur_color>=1 && fur_color<=8)) {
                    printf("Unvalid selection\n");
                }

            }while(!(fur_color>=1 && fur_color<=8));

            /* Getting results from the respective function */
            result_dt3a = dt3a(weight, age, is_ShortHair, eye_color, fur_color);
            result_dt3b = dt3b(weight, age, is_ShortHair, eye_color, fur_color);

            /* Printing results in accordance with some requirements */
            printf("\n");
            if(result_dt3a == result_dt3b) {
                print_result(result_dt3a, problem_selection);
            }

            else if(result_dt3a != result_dt3b) {
                print_result(result_dt3a, problem_selection);
                print_result(result_dt3b, problem_selection);
            }

        }

        /* Making sure that problem selection has a valid value */
        if(problem_selection != 1 && problem_selection != 2 && problem_selection != 3 && problem_selection != -1) {
            printf("Unvalid selection\n\n");
        }

    }while(problem_selection != -1);
    

    return (0); /* This return is not going to be used. */
} /* End of main */

