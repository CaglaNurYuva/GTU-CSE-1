#define MAX 100
#include <stdio.h>
#include "utils.h"

int main() {
    
    int Num_First, Num_Second, Divisor, first_result, next = 0, other_result = 1, Error_Code;
    int Validation_Check = 0, password, Done, Login_Control, Available_Amount, password_temp, digits = 0;
    char identity_number[MAX] ;
    float cash_amount ;

    /*------------------------------------------------------------ Part 1 ------------------------------------------------------------*/

    /* Reading the lowest and greatest limits of the gap and divisor from the user */
    printf("Enter the first integer: ");
    scanf("%d",&Num_First);
    printf("Enter the second integer: ");
    scanf("%d",&Num_Second);
    printf("Enter the divisor: ");
    scanf("%d",&Divisor);
    

    /* Making "Divisor" a number except 0 */
    while(Divisor == 0) {

        printf("%d is not allowed to be a divisor\n", Divisor);
        printf("Enter the divisor: ");
        scanf("%d",&Divisor);
    }


    /* Making "Num_First" a positive number */
    while(Num_First < 0) {

        printf("%d is not allowed since it is negative\n", Num_First);
        printf("Enter the first integer: ");
        scanf("%d",&Num_First);
    }


    /* Making "Num_Second" a positive number */
    while(Num_Second < 0) {

        printf("%d is not allowed since it is negative\n", Num_Second);
        printf("Enter the second integer: ");
        scanf("%d",&Num_Second);
    }


    /* Finding first number that can be divided by "Divisor" without any remainder and is in the gap between Num_First and Num_Second. */
    first_result = find_divisible(Num_First, Num_Second, Divisor);


    /* If "first_result" is not (-1), which means error, print "first_integer" on the screen. */ 
    if(first_result != -1) {

        printf("The first integer between %d and %d is divided by %d is %d\n",Num_First, Num_Second, Divisor, first_result);
        
        printf("Enter the number how many next: ");
        scanf("%d",&next);
            
        /* Calculate "other_result" according to the number taken from the user.*/    
        other_result = find_nth_divisible(next,first_result,Divisor);  

        /* Checking whether "other_result" is in the gap between Num_First and Num_Second or not. */
        if((other_result < Num_Second) && (other_result > Num_First)) {
            printf("The %d. integer between %d and %d divided by %d is %d\n",next + 1, Num_First, Num_Second, Divisor, other_result); 
        }

        else {
            Error_Code = Give_Error() ;

            if(Error_Code == -999) {
                printf("There is not any integer between %d and %d can be divided by %d\n",Num_First, Num_Second, Divisor); 
            }

        }         
    }

    /* Error code is -1, which means there is no "first_result" that can be divided by "z" in the gap between Num_First and Num_Second. */
    else if(first_result == -1) {
        printf("There is not any integer between %d and %d can be divided by %d\n",Num_First, Num_Second, Divisor); 
    }

    printf("\n");

    /*------------------------------------------------------------ Part 2 ------------------------------------------------------------*/

    while(Validation_Check == 0) {

        /* Cleaning buffer */
        getchar();  

        printf("Enter your identity number: ");
        scanf("%[^\n]s",identity_number);
        
        /* Checking whether ID number's algorithm is correct or not. */
        Validation_Check = validate_identity_number(identity_number);

        if(Validation_Check == 0) {
            printf("Unvalid ID no\n");
        }

        while(Validation_Check == 1) {

            do {

                /* Taking password from the user. */
                printf("Enter your password: ");
                scanf("%d",&password);

                password_temp = password ;
                digits = 0;  /* This variable keeps how many digits there are in password. */


                /* Calculating the number of digits in password. */
                while(password_temp != 0) {
                    password_temp = password_temp / 10 ;
                    digits++ ;
                }


                /* Checking the number of digits in password */
                if(digits != 4 || password < 0) {
                    printf("Unvalid password\n");
                }

            } while(digits != 4 || password < 0);  /* Asking the password again if it is unvalid. */


            /* Writing ID Number and password in the file. */
            Done = create_customer(identity_number, password);

            if(Done == 0) {
                printf("File could not be created.\n");
                return (1);
            }

            else if(Done == 1) {
                Validation_Check = 1 ;  /* Getting out of outer while loop. */
                break;  /* Getting out of inner while loop. */
            }
        }
    }
    
    /*------------------------------------------------------------ Part 3 ------------------------------------------------------------*/

    /* Cleaning buffer */
    getchar(); 

    /* Taking inputs from the user. */
    printf("\nEnter your identity number: ");
    scanf("%[^\n]s",identity_number);
    printf("Enter your password: ");
    scanf("%d",&password);
    
    /* Checking whether inputs are the same as what is in the file named as "customeraccount.txt". */
    Login_Control = check_login(identity_number, password);

    if(Login_Control == 0) {
        printf("\nInvalid identity number or password");
    }

    else if(Login_Control == 1) {
        printf("Login Successful");

        printf("\nEnter your withdraw amount: ");
        scanf("%f",&cash_amount);

        Available_Amount = withdrawable_amount(cash_amount);
        printf("Withdrawable amount is: %d",Available_Amount);
    }

    return(0);
    
} /* End of main */
