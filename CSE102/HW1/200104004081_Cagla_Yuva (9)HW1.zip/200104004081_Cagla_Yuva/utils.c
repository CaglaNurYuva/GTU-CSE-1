#include <stdio.h>
#include "utils.h"

int find_divisible(int x, int y, int z) {

    /* the lowest limit(x) isn't included the gap between (x - y) */
    x = x + 1 ;  

    while(x < y) {

        if(x % z == 0) {
            return (x) ;  /* If "x" is in the gap between (x - y) and be divided by "z" without any remainder, return "x". */ 
        }

        x++ ;
    }

    return (-1) ;  /* If there is no number that can be divided by "z" without any remainder, return -1. */

} /* End of find_divisible */


int find_nth_divisible(int n, int f_I, int z) {

    int i = 0 ;
    f_I = f_I + 1 ;  /* Start checking just after the first number. */

    /* Finding the n. number that can be divided by "z" without any remainder and is greater than f_I. */
    while(i < n) {

        if(f_I % z == 0) {
            i++ ;
        }

        if(i == n ) { 
            return (f_I);
        }

        ++f_I ;
    }

    return (-1);

} /* End of find_nth_divisible */


int validate_identity_number(char identity_number[]) {

    int length, Sum_Of_Odd_Digits = 0, Sum_Of_Even_Digits = 0 , index = 0, Sum_Of_Ten_Digits = 0;

    /* Calculating necessary values related to ID Number algorithm. */
    for(length = 0; identity_number[length] != '\0'; length++) {    

        if(!(identity_number[length] >= '0') && !(identity_number[length] <= '9')) {
            return (0);
        }

        if(length <= 9) {
            Sum_Of_Ten_Digits += (identity_number[length] - '0') ;
        }

        if((length+1) % 2 == 0 && length<=8) {
            Sum_Of_Even_Digits += (identity_number[length] - '0');
        }

        if((length+1) % 2 == 1 && length<=8) {
            Sum_Of_Odd_Digits += (identity_number[length] - '0');
        }

    }

    /* Checking ID Number's length */
    if(length != 11) {
        return (0);
    }

    /* Checking ID Number to find out whether it has correct algorithm or not. */
    while(identity_number[index] != '\0') {

        if(identity_number[0] == '0') {
            return (0);
        }

        if((((Sum_Of_Odd_Digits*7) - Sum_Of_Even_Digits) % 10) != (identity_number[9] - '0')) {
            return (0);
        }

        if((Sum_Of_Ten_Digits % 10) != (identity_number[10] - '0')) {
            return (0);
        }

        index++ ;
    }

    return (1);

} /* End of validate_identity_number */


int create_customer(char identity_number[], int password) {

    FILE *p ;
    p = fopen("customeraccount.txt","w");  /* Opening the file. */

    if(p == NULL) {
        printf("Error has occurred while opening file");
        return (0);
    }

    /* Writing ID Number and password in the file whose name is "customeraccount.txt" */
    fprintf(p, "%s,%d",identity_number,password);

    fclose(p);  /* Close the file. */
    return (1);

} /* End of create_customer */


int check_login(char identity_number[], int password) {

    FILE *p ;
    char ID_in_File[13], c ;
    int password_in_File, i = 0, flag = 1, length = 0;

    p = fopen("customeraccount.txt","r");  /* Opening the file. */

    if(p == NULL) {
        printf("Error has occurred while opening file");
        return (-1);
    }

    /* Reading ID Number from the file */
    fgets(ID_in_File, 12, p);  


    /* Moving cursor from the char ',' */
    c = fgetc(p);   

    /* Reading password from the file */
    fscanf(p, "%d",&password_in_File);  


    /* Calculating the length of ID number that the user has just entered while trying to login. */
    while(identity_number[length] != '\0') {
        length++ ;
    }

    if(length != 11) {
        return (0);  /* The user has been written definitely wrong ID while trying to login. */
    }

    /* Comparing what the user entered as ID Number and password with what has been read from the file as ID Number and password. */
    if(password == password_in_File) {

        for(i=0; identity_number[i] != '\0'; i++) {

            if(identity_number[i] != ID_in_File[i]) {

            	flag = 0;  /* As long as flag is 0, login won't be successful because there is a difference between two ID numbers. */
                break;
            }
        }

        /* For loop has come to the end using "break", which means there is a difference between two ID numbers. */
        if(i < 11) {
            flag = 0;
        }

    }

    else {

        fclose(p);  /* Close the file. */
        return (0);
    }

    fclose(p);  /* Close the file. */
    
    if(flag == 1) {
        return (1);
    }

    else if(flag == 0) {
        return (0);
    }

} /* End of check_login */


int withdrawable_amount(float cash_amount) {

    int Banknote_50s = 0, Banknote_20s = 0, Banknote_10s = 0, withdrawable_amount = 0;

    /* Calculating withdrawable amount. */
    while(cash_amount >= 50) {
        cash_amount = cash_amount - 50 ;
        Banknote_50s++ ;
    }

    while(cash_amount >= 20) {
        cash_amount = cash_amount - 20 ;
        Banknote_20s++ ;
    }

    while(cash_amount >= 10) {
        cash_amount = cash_amount - 10 ;
        Banknote_10s++ ;
    }

    withdrawable_amount = Banknote_50s*50 + Banknote_20s*20 + Banknote_10s*10 ;
    return (withdrawable_amount) ;    
} /* End of withdrawable_amount */


int Give_Error() {
    return (-999) ;  /* Give -999 as an error code. */
} /* End of Give_Error */

