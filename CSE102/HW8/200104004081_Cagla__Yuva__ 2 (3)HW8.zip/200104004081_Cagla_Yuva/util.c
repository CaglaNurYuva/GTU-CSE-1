#include <stdio.h>
#include <stdlib.h>
#include "util.h"


/* Recursively checking whether the sequence ends up in a loop or not */
void check_loop_iterative(void (*f)(int xs, int currentlen, int seqlen, int *seq), int xs, int seqlen, int *loop,int *looplen) {
    int ls, le, result, *sequence, found=0, i=0;

    /* Allocating memory for sequence */
    sequence = (int*) malloc(seqlen*sizeof(int));

    /* Generating sequence */
    f(xs,0,seqlen,sequence);

    /* Checking whether it is the first call of check_loop_iterative function or not using the initial value of *looplen, which was assigned in main function */
    if((*looplen) == 0){

        (*looplen) = (seqlen/2);  /* Assigning the maximum possible length of loop to *looplen */

        /* Printing sequence */
        printf("\nSequence: {");
        while(i<seqlen) {
            printf("%d, ",sequence[i]);
            i++;
        }
        printf("\b\b}\n\n");
    }
    
    /* Checking whether *looplen is between 2 and seqlen/2 or not */
    if((*looplen)>=2){

        /* Checking whether a given sequence of numbers has a loop in it or not */
        result = has_loop(sequence,seqlen,*looplen,&ls,&le);  
        
        /* Indicating there is a loop in a given sequence */
        if(result == 1){
            fill_loop_elements(looplen,loop,&ls,sequence,seqlen);  /* Filling loop elements in loop array because there is a loop in a given sequence */
            printf("\n\nLoop detected with a length of %d.\n",*looplen);  /* Printing size of loop */
            printf("The indexes of the loop's first occurance: %d (first digit), %d (last digit)",ls, le); /* Printing the indexes of loop's first occurence */
            found=1;  /* Indicating loop has been found */
        }
    }

    /* Freeing memory having been allocated for sequence array */
    free(sequence);
    
    /* If there is no loop found and *looplen is in appropriate gap, keep searching for a loop. */
    if((*looplen)>=3 && found==0) {
        --(*looplen);  /* Lessening the length of *looplen */ 
        check_loop_iterative(generate_sequence,xs,seqlen,loop,looplen);  /* Recursively calling check_loop_iterative function until finding a loop with appropriate length */
    }

    /* If there is no loop found and *looplen is not in appropriate gap anymore, assign 0 to *looplen indicating there is no loop found */
    else if((*looplen)<=2 && found==0) *looplen = 0;
   
}  /* End of check_loop_iterative function */


/* Checking whether a given sequence of numbers has a loop in it or not */
int has_loop(int *arr, int n, int looplen, int *ls, int *le) { 

    int index1;             /* Indicating the first group of numbers' indexes */ 
    int index2;             /* Indicating the second group of numbers' indexes */ 
    int count=0;            /* Keeping the number of the same numbers while comparing first and second group of numbers */
    int number_of_loops=0;  /* Keeping the number of loops in a given sequence */
    int flag_x=0;           /* Indicating whether there are at least 2 loops or not */


    /* Algorithm explanation: Take 2 first index of 2 group of numbers chosen from the very end of sequence that are seperated from each other 
    with the length of looplen and check whether these first indexes are equal to each other or not. If these first indexes are equal, keep 
    checking their second indexes... so on and so forth, until having reached desired loop length. However, if any indexes are not equal to each other, 
    stop looking for a loop with that length. */


    index1 = n-1;               /* Indicating the first group of numbers' first index */ 
    index2 = index1 - looplen;  /* Indicating the second group of numbers' first index */

    printf("Checking if there is a loop of length %d...\n",looplen);

    /* Checking the condition that loop length must be equal to or greater than 2 */
    if(index2 <= 0) return (0); /* Indicating there is no loop found */
    
    /* Since second group of numbers' indexes are smaller than indexes of first group of numbers, keep checking until second group's indexes reach 0. */
    while(index2>0){
        
        /* If two group of numbers' indexes are not equal to each other and you don't have at least 2 loops, there is no loop. */
        if(arr[index1] != arr[index2] && flag_x==0){
            return (0);   /* Indicating there is no loop */
        }

        /* If two group of numbers' indexes are not equal to each other and you have at least 2 loops , stop checking these two groups for that looplen. */
        if(arr[index1] != arr[index2] && flag_x==1){
            break;
        }

        /* If two group of numbers' indexes are equal to each other, increment the number of the same numbers, which is kept in count variable. */
        if(arr[index1] == arr[index2]){
            count++;
        }

        /* If the number of the same numbers are equal to looplen, there are one or two loops. Therefore, the number of loops is incremented by one or two. */
        if(count == looplen){
            if(number_of_loops==0) {
                number_of_loops += 2;
                flag_x=1;  /* Indicating that there are at least 2 loops */ 
            }
            else number_of_loops++;

            count = 0; /* Assigning 0 to the number of the same numbers */ 
        }

        /* Decrementing two group of numbers' indexes by one. */
        index1--;
        index2--;
    }

    /* Assigning the first occurence of the loop to *ls and *le */ 
    *ls = (n - (number_of_loops*looplen)); 
    *le = (n - (number_of_loops*looplen)) + looplen - 1;

    return (1); /* Indicating loop has been found */
   
}  /* End of has_loop function */


/* If a loop has been found, fill loop array with the elements of the loop. */
void fill_loop_elements(int *looplen, int *loop, int *ls, int *sequence, int seqlen) {
    int index=0, value, num;

    /* Put the first element of loop in loop array */
    value = (*ls);
    num=sequence[value];
    loop[index] = num;

    /* Incrementing index of loop array by one */
    index++;

    /* Filling loop array with the rest of elements of loop */
    while(index<(*looplen)){

        /* If number is odd, new number is equal to 3*number + 1 */
        if(num%2 == 1) num = 3*num + 1;
            
        /* If number is even, new number is equal to number/2 */
        else if(num%2 == 0) num = num/2;
            
        loop[index] = num;  /* Filling loop array */
        index++;            /* Incrementing index of loop array by one */
    }
    
} /* End of fill_loop_elements function */


/* Finding first digit of a number */
int find_first_digit(int number) {
    int first_digit;

    if(number == 0) return (0);  /* If number is zero, first digit is zero. */
    while(number != 0) {
        first_digit = number%10;
        number /= 10;
    }
    
    return first_digit;

} /* End of find_first_digit function */


/* Recursively calculating histogram of first digits of the sequence */
void hist_of_firstdigits(void (*f)(int xs, int currentlen, int seqlen, int *seq), int xs, int seqlen, int *h, int digit){
    int *sequence, first_digit, index=0, count=0;

    /* Allocating memory for sequence loop */
    sequence = (int*) malloc(seqlen*sizeof(int));
    
    if(digit<=9){
        
        /* Generating sequence */
        f(xs,0,seqlen,sequence);
        
        index=0;        /* Keeping index of sequence array */
        count=0;        /* Keeping the number of digits founded in sequence */
        h[digit-1] = 0; /* Assigning 0 to relevant index of histogram array */


        /* Looking for a certain digit */
        while(index<seqlen){
            first_digit = find_first_digit(sequence[index]); /* Finding first digit of a number */

            if(first_digit == digit) {
                count++; /* Incrementing the number of found digits */
            }
            index++; /* Incrementing index of sequence array */
        }

       /* Freeing memory having allocated for sequence array */ 
       free(sequence);

       /* Assigning the number of digits to histogram array */
       h[digit-1] = count;
       
       /* Recursively calling hist_of_firstdigits function to check the next digit */
       if(digit<10)  hist_of_firstdigits(generate_sequence, xs, seqlen, h, ++digit);

    }

} /* End of hist_of_firstdigits function */


/* Recursively generating and returning the sequence */
void generate_sequence (int xs, int currentlen, int seqlen, int *seq) {
    
    /* Until seqlen has been reached, generate elements of sequence */
    if(currentlen<seqlen) {
    	
    	/* Assigning the first element of sequence to first index of sequence */
    	if(currentlen == 0) {
        	seq[currentlen] = xs;
    	}
    	
        else {
        	
        	if(xs%2 == 1) xs = 3*xs + 1;    /* If number is odd, new number is equal to 3*number + 1 */
        	else if(xs%2 == 0) xs = xs/2;   /* If number is even, new number is equal to number/2 */

        	seq[currentlen] = xs;  /* Assigning new number to sequence array */
		}
		
        /* Recursively calling generate_sequence function to get next element of sequence */
        generate_sequence(xs,++currentlen,seqlen,seq);
    }

}  /* End of generate_sequence function */


