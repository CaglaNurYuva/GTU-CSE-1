#ifndef _UTIL_H_
#define _UTIL_H_

/* Recursively generating and returning the sequence */
void generate_sequence (int xs, int currentlen, int seqlen, int *seq); 

/* Recursively checking whether the sequence ends up in a loop or not */
void check_loop_iterative(void (*f)(int xs, int currentlen, int seqlen, int *seq), int xs, int seqlen, int *loop,int *looplen);

/* Checking whether a given sequence of numbers has a loop in it or not */
int has_loop(int *arr, int n, int looplen, int *ls, int *le);

/* If a loop has been detected, fill loop array with the elements of the loop. */
void fill_loop_elements(int *looplen, int *loop, int *ls, int *sequence, int seqlen);

/* Recursively calculating histogram of first digits of the sequence */
void hist_of_firstdigits(void (*f)(int xs, int currentlen, int seqlen, int *seq), int xs, int seqlen, int *h, int digit);

/* Finding first digit of a number */
int find_first_digit(int number);

#endif /* _UTIL_H_ */