#include <stdio.h>
#include <stdlib.h>
#include "util.h"

/* main function */
int main() {
    int sequence_length, first_element;
    int *loop, *h, digit=1, index=0, i=0;
    int looplen=0;  /* Initializing to 0 to be able to check the first call of check_loop_iteration function */

    /* Getting sequence length from user as input */
    printf("\nPlease enter the sequence length: ");
    scanf("%d", &sequence_length);

    /* Getting first element of sequence from user as input */
    printf("Please enter the first element: ");
    scanf("%d", &first_element);

    /* Allocating memory for loop array */
    loop = (int*) malloc((sequence_length/2)*sizeof(int));

    /* Checking whether the sequence ends up in a loop or not */
    check_loop_iterative(generate_sequence,first_element,sequence_length,loop,&looplen);
    
    /* If there is a loop, print that loop. */
    if(looplen != 0) {
        printf("\nLoop: {");
        
    	while(index<looplen) {
        	printf("%d, ",loop[index]);
        	index++;
    	}
    	
    	printf("\b\b}\n\n");
        
    }

    /* If there is no loop, print that information. */
    else if(looplen == 0) {
        printf("No loop found.\n\n");
    }
    
    /* Freeing having allocated memory for loop */
    free(loop);

    /* Allocating memory for histogram array */
    h = (int*) malloc(9*sizeof(int));

    /* Calculating histogram of first digits of the sequence */
    hist_of_firstdigits(generate_sequence,first_element,sequence_length,h,digit);

    /* Printing histogram array */
    printf("Histogram of the sequence: {");
    while(i<9){
        printf("%d, ",h[i]);
        i++;
    }
    printf("\b\b}\n\n");

    /* Freeing having allocated memory for histogram array */
    free(h);
    
    return (0);

} /* End of main function */

