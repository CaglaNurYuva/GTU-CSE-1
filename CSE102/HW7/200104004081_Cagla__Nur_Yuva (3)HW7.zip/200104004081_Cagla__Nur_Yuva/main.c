#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* Creating puzzle */
int create_puzzle(char puzzle[15][15], char total_indexes[10][10],char all_first_indexes[7][8],char all_words[7][8], int all_directions[9]);

/* Starting to play word puzzle game */
void play_game(char puzzle[15][15], char all_first_indexes[7][8], char all_words[7][8], int all_directions[9]);

/* Covering word with 'X' characters when found */
void cover_word(char puzzle[15][15], int all_directions[9], char all_words[7][8], char all_first_indexes[7][8], char read_answer[15]);

/* Creating all indexes of a word by using first index of a word */
void create_all_indexes(char total_indexes[10][10], char first_index[8], char word[6], int direction);

/* Deleting '\n' character that occurred just before '\0' character from answer array */
void delete_enter(char read_answer2[]); 

/* Filling array with '\0' characters to reset the answer that has been get from user while playing game */
void reset_answer(char answer[15]); 

/* Checking word's first index for overlapping another word's first index and whether word's all indexes within the 0-14 gap or not*/
int checking(char puzzle[15][15], char total_indexes[10][10], char word[6], char first_index[8]);


int decide_direction();                                             /* Randomly choosing a direction  */
void find_first_index(char first_index[8]);                         /* Randomly choosing first index of a word */
int decide_word(char word[8], int other_dices[7], int which_word);  /* Randomly choosing a word */
void fill_puzzle(char puzzle[15][15], char word[6],char total_indexes[10][10], int direction);  /* Writing one word in puzzle */
void fill_blanks(char puzzle[15][15]);                              /* Filling blanks in puzzle with random characters */
char generate_random_char();                                        /* Generating random characters */
void print_puzzle(char puzzle[15][15]);                             /* Printing puzzle */
void print_coordinates_and_words(char all_first_indexes[7][8], char all_words[7][8]);           /* Printing words and coordinates of words */


/* main function */
int main() {  

    /* Necessary array declarations */
    char puzzle[15][15];             /* This array keeps the whole puzzle */
    char total_indexes[10][10] ;     /* This array keeps all indexes of one word */
    char all_first_indexes[7][8];    /* This array keeps first indexes of all words */
    char all_words[7][8];            /* This array keeps all words */
    int all_directions[9];           /* This array keeps all directions of all words */
    int file_error;                  /* Checking file error */   


    /* Using computer's internal clock to control the choice of the seed. */
    srand(time(NULL));

    /* Creating puzzle */
    file_error = create_puzzle(puzzle, total_indexes, all_first_indexes, all_words, all_directions);

    /* Checking file error */
    if(file_error == 1){
        printf("The file could not be opened...\n");
        printf("Quitting...\n");
        return (1);
    }

    else if(file_error == 0) {

        /* Printing words and coordinates of words */
        print_coordinates_and_words(all_first_indexes,all_words);

        /* Starting to play word puzzle game */
        play_game(puzzle, all_first_indexes, all_words, all_directions);
    }
    
    return (0);

}  /* End of main */


/* Covering word with 'X' characters when found */
void cover_word(char puzzle[15][15], int all_directions[9],char all_words[7][8],char all_first_indexes[7][8], char read_answer[15]) {

    int length, direction, index_x, index_y, count=0, where_is_word;
    char c;

    /* Finding which word the user has just found */
    while(count <= 6){
        if(strcmp(all_words[count], read_answer) == 0) {
            where_is_word = count;
            break;
        }

        /* Keeping index of array named all_words */
        count++;
    } 

    
    length = strlen(read_answer);                 /* Finding length of the word that the user has just found */
    direction = all_directions[where_is_word];    /* Finding direction of the word that the user has just found */
    sscanf(all_first_indexes[where_is_word],"%d%c%d",&index_x,&c,&index_y); /* Finding first index of the word that the user has just found */
    

    /* Covering the word that user has just found with 'X' characters according to the word's direction and length */
    if(direction == 1){
        while(length-1>=0){
            puzzle[index_x][index_y] = 'X';
            index_y++;
            length--;
        }
    }

    else if(direction == 2){
        while(length-1>=0){
            puzzle[index_x][index_y] = 'X';
            index_y--;
            length--;
        }
    }

    else if(direction == 3) {
        while(length-1>=0){
            puzzle[index_x][index_y] = 'X';
            index_x++;
            length--;
        }
    }

    else if(direction == 4){
        while(length-1>=0){
            puzzle[index_x][index_y] = 'X';
            index_x--;
            length--;
        }
    }

    else if(direction == 5){
        while(length-1>=0){
            puzzle[index_x][index_y] = 'X';
            index_x++;
            index_y--;
            length--;
        }
    }

    else if(direction == 7){
        while(length-1>=0){
            puzzle[index_x][index_y] = 'X';
            index_x--;
            index_y++;
            length--;
        }
    }

    else if(direction == 6){
        while(length-1>=0){
            puzzle[index_x][index_y] = 'X';
            index_x++;
            index_y++;
            length--;
        }
    }

    else if(direction == 8){
        while(length-1>=0){
            puzzle[index_x][index_y] = 'X';
            index_x--;
            index_y--;
            length--;
        }
    }

}  /* End of cover_word function */


/* Starting to play word puzzle game */
void play_game(char puzzle[15][15], char all_first_indexes[7][8], char all_words[7][8], int all_directions[9]) {

    int mistakes=0, correct=0, total_points=0;
    int x1=0, y1=0, x2, y2, k1=0, k2=0, index=0, ind=0, flag;
    char c, read_answer1[15], read_answer2[15], record[7][25];

    print_puzzle(puzzle);  /* Printing puzzle */

    /* Starting to play game */
    while(1) {
        
        reset_answer(read_answer1);            /* Filling read_answer1 array with '\0' characters */
        reset_answer(read_answer2);            /* Filling read_answer2 array with '\0' characters */   
        printf("Enter coordinates and word:");

        fgets(read_answer2,15,stdin);          /* Getting input from user */
        delete_enter(read_answer2);            /* Deleting '\n' character that occurred just before '\0' character from read_answer2 array */


        /* If the user has just entered ":q", the game ends. */
        if(strcmp(read_answer2, ":q") == 0){
            printf("Total points: %d\n",total_points);
            break;
        }

        /* If the user didn't enter ":q", read what user entered. */
        else sscanf(read_answer2,"%d %d %s",&x1, &y1, read_answer1);
            
        k1 = 0;
        /* Finding if the user has found a word, which one has been found. */
        while(k1<=6){
            k2 = strcmp(all_words[k1], read_answer1);
            if(k2 == 0) break;
            k1++;  /* Keeping index of the array named all_words */
        }


        /* If the user can't find a word, the answer is wrong. */
        if(k1 == 7) {
            mistakes++;

            /* The condition for ending the game */
            if(mistakes == 3) {
                printf("\nThe game is up\n");
                printf("Total points: %d\n",total_points);
            }

            else printf("Wrong choice! You have only %d lefts.\n\n",3-mistakes);
            
        }

        /* If the word has been found, keep checking the found word */
        else {

            /* Finding first index of the word that has just been found */
            sscanf(all_first_indexes[k1],"%d%c%d",&x2,&c,&y2);

            ind = 0;
            flag=1;

            /* Investigating whether the word has been found just once or not */
            while(ind<=index-1){
                sscanf(record[ind],"%d%c%d",&k1,&c,&k2);

                if(k1 == x2 && k2 == y2) {
                    flag = 0;  /* Indicating that the word has not been found just once */
                    break;
                }

                else ind++;
            }


            /* If the word has been found and its coordinates are correct and the word has been found just once, the user gets 2 points */
            if(x1 == x2 && y1 == y2 && flag == 1) {
                
                /* Write the found word to the array named record to keep record of the words */
                sprintf(record[index],"%d,%d",x1,y1);
                index++; 
                total_points+= 2;  /* Giving 2 points to user */
                correct++;


                /* The condition for ending the game */
                if(correct == 7) {
                    cover_word(puzzle, all_directions, all_words, all_first_indexes, read_answer1);  /* Covering word with 'X' characters */
                    printf("\n");
                    print_puzzle(puzzle);    /* Printing puzzle */
                    printf("Total points: %d\n",total_points);
                    break;
                }

                cover_word(puzzle, all_directions, all_words, all_first_indexes, read_answer1);      /* Covering word with 'X' characters */
                printf("\n");
                print_puzzle(puzzle);       /* Printing puzzle */
                printf("Founded! You got 2 points. Your total points: %d\n", total_points);
                
            }

            else {
                mistakes++;

                /* The condition for ending the game */
                if(mistakes == 3) {
                    printf("\nThe game is up\n");
                    printf("Total points: %d\n",total_points);
                }

                else printf("Wrong choice! You have only %d lefts.\n\n",3-mistakes);
                
            }
        
        }
    }

}  /* End of play_game function */


/* Filling array with '\0' characters to reset the answer that has been get from user while playing game */
void reset_answer(char answer[15]) {
    int x=14;

    while(x>=0){
        answer[x] = '\0';
        x--;
    }

}  /* End of reset_answer function */


/* Creating puzzle */
int create_puzzle(char puzzle[15][15], char total_indexes[10][10], char all_first_indexes[7][8], char all_words[7][8], int all_directions[9]) {

    int count=0, direction, error=0;
    int i, j, file_error, other_dices[7];
    char c;

    /* Filling array carrying puzzle with '*' characters */
    for(i=0; i<15; i++) {
        for(j=0; j<15; j++) {
            puzzle[i][j] = '*';
        }
    }
    
    /* Preventing choosing the same words by keep recording line numbers of chosen words */
    while(count<=6) other_dices[count++] = 0;

    count=0;
    while(count<7){
        
        /* Randomly choosing a first index */
        find_first_index(all_first_indexes[count]);

        /* Randomly choosing a word */
        file_error = decide_word(all_words[count], other_dices,count);

        /* Checking file error */
        if(file_error == 1) return (1);

        /* Randomly choosing a direction */
        direction = decide_direction();
        all_directions[count] = direction;  /* Keep recording directions of words */

        /* Creating all indexes of a word using random first index and direction */
        create_all_indexes(total_indexes, all_first_indexes[count], all_words[count], direction);

        /* Checking all indexes of a word for whether they are valid or not */
        error = checking(puzzle, total_indexes, all_words[count], all_first_indexes[count]);


        /* If there is no error, fill puzzle with a random word that has already been chosen */
        if(error == 0) fill_puzzle(puzzle, all_words[count], total_indexes, direction);

        /* As long as there is an error, keep getting a new random first index */
        while(error == 1){
            find_first_index(all_first_indexes[count]);  /* Again randomly choosing a first index */
            create_all_indexes(total_indexes, all_first_indexes[count], all_words[count], direction); /* Again creating all indexes of a word using random first index */

            /* Again checking all indexes of a word for whether they are valid or not */
            error = checking(puzzle, total_indexes, all_words[count], all_first_indexes[count]);

            /* If there is no error, fill puzzle with a random word that has already been chosen */
            if(error == 0) fill_puzzle(puzzle, all_words[count], total_indexes, direction);
        }

        count++;
    }

    
    /* Filling other places that is not used by other words with random characters */
    fill_blanks(puzzle);

    /* Indicating that there is no error occurred */
    return (0);

}  /* End of create_puzzle function */


/* Printing puzzle */
void print_puzzle(char puzzle[15][15]){
    int i, j;
    for(i=0; i<15; i++) {
        for(j=0; j<15; j++) {
            printf("%c ", puzzle[i][j]);
        }
        printf("\n");
    }

}  /* End of print_puzzle function */


/* Creating all indexes of a word by using first index of a word */
void create_all_indexes(char total_indexes[10][10], char first_index[8], char word[6], int direction) {

    int length, x, y, count, i=0, j=0;
    char c;

    count=0;
    length = strlen(word);                  /* Finding length of the word */
    sscanf(first_index,"%d%c%d",&x,&c,&y);  /* Reading first_index array */
    

    /* Creating all indexes of the word according to direction and length of the word */
    if(direction == 1 ||direction == 3 || direction == 5 || direction == 6) {
        while(count<length){

            if(direction == 1){
                sprintf(total_indexes[count],"%d%c%d",x,',',y+i);
            }

            else if(direction == 3) {
                sprintf(total_indexes[count],"%d%c%d",x+i,',',y);
            }

            else if(direction == 5) {
                sprintf(total_indexes[count],"%d%c%d",x+i,',',y-j);
            }

            else if(direction == 6){
                sprintf(total_indexes[count],"%d%c%d",x+i,',',y+j);
            }

            i++;
            j++;    
            count++;
        }
    }
    

    else if(direction == 2 ||direction == 4 || direction == 7 || direction == 8) {

        if(direction == 2){
            i=0;
            while(i<length){
                sprintf(total_indexes[count],"%d%c%d",x,',',y-i);
                i++;
                count++;
            }
                
        }

        else if(direction == 4) {
            i=0;
            while(i<length){
                sprintf(total_indexes[count],"%d%c%d",x-i,',',y);
                i++;
                count++;
            }
              
        }

        else if(direction == 7) {
            i=0;
            j=0;
            while(i<length){
                sprintf(total_indexes[count],"%d%c%d",x-i,',',y+j);
                i++;
                j++;
                count++;
            }
                
        }

        else if(direction == 8){
            i=0;
            while(i<length){
                sprintf(total_indexes[count],"%d%c%d",x-i,',',y-i);
                i++;
                count++;
            }
        }
          
    }

} /* End of create_all_indexes function */


/* Generating random characters */
char generate_random_char() {
    char c;
    int r;

    r = 1+rand()%26;
    r = r + 96;
    c = (char) r ;

    return c;

} /* End of generate_random_char function */


/* Filling blanks in puzzle with random characters */
void fill_blanks(char puzzle[15][15]) {
    int i,j;
    char c;

    for(i=0; i<15; i++) {
        for(j=0; j<15; j++) {
            if(puzzle[i][j] == '*') {
                c = generate_random_char(); /* Generating a random character */
                puzzle[i][j] = c;
            }
        }
    }

}  /* End of fill_blanks function */


/* Writing one word in puzzle */
void fill_puzzle(char puzzle[15][15], char word[6], char total_indexes[10][10], int direction) {

    int index_t=0, length=0, x, y, index_w;
    char c;

    length = strlen(word);   /* Finding length of the word */
    index_w = 0;

    while(length>0) { 
        sscanf(total_indexes[index_t],"%d%c%d",&x,&c,&y);
        c = word[index_w];   /* Reading one character from the word */
        puzzle[x][y] = c;    /* Writing a character of word in puzzle */
            
        length--;
        index_w++;
        index_t++;
    }
    
}  /* End of fill_puzzle function */


/* Checking word's first index for overlapping another word's first index and whether word's all indexes within the 0-14 gap or not */
int checking(char puzzle[15][15], char total_indexes[10][10], char word[6], char first_index[8]) {

    int i, length=0, index=0;
    int x, y;
    char c;

    length = strlen(word);  /* Finding length of the word */
    for(i=0; i<length; i++) {

        /* Reading indexes of a word from the array named total_indexes */
        sscanf(total_indexes[i],"%d%c%d",&x,&c,&y);

        /* If any coordinates are not between 0-14 gap, give error. */
        if((x<0) || (y<0) || (x>14) || (y>14))   return (1); 

    }
    

    while(length>0) {

        /* Reading indexes of a word from the array named total_indexes */
        sscanf(total_indexes[index],"%d%c%d",&x,&c,&y);

        /* If there is an index that has already been occupied by an another word's letter, give error. */
        if(puzzle[x][y] != '*')  return (1); 

        length--;
        index++;
    }

    return (0);

}  /* End of checking function */


/* Randomly deciding a word */
int decide_word(char word[8], int other_dices[7], int which_word) {

    FILE* ptr;
    int r, index=0, yedek_r, flag;
    char ch;

    /* Choosing a random number between 1-50 that represents the line number of words in file while preventing to choose the same line numbers */
    do{
        
        index=0;
        flag = 1;
        r = 1+rand()%50;               /* Choose a random number that represents line number of a word between 1-50 */
        other_dices[which_word] = r;   /* Keeping record of line numbers to prevent same words */

        /* Checking whether the chosen number was chosen before or not */
        while(index<=which_word-1){

            if(r == other_dices[index]) {
                flag=0;
            }
            index++;
        }

    }while(flag == 0);  /* Unless a valid line number is found, keep getting random line numbers */
    
    yedek_r = r;

    /* Opening file */
    ptr = fopen("wordlist.txt","r"); 

    /* Checking opening file error */
    if(ptr == NULL) return (1);

    /* Accessing the chosen word by using the line number of the chosen word */
    while(r>0){

        /* Going through lines that are before the chosen line */
        if(yedek_r != 50){
            index=0;

            /* Filling word array with '\0' characters */
            while(index<=7){
                word[index] = '\0';
                index++;
            }

            /* Reading a word */
            fscanf(ptr,"%s",word);

            r--;
        }


        else if(yedek_r == 50){
            index=0;

            /* Filling word array with '\0' characters */
            while(index<=7){
                word[index] = '\0';
                index++;
            }


            /* Reading a word */
            if(r == 1){
                fscanf(ptr,"%s",word);
                r--;
            }
            
            else {
                /* Reading a word */
                fscanf(ptr,"%s",word);
       
                r--;
            }
            
        }
    }
    
    fclose(ptr);  /* Closing file */
    return (0);

}  /* End of decide_word function */


/* Randomly deciding first index of a word */
void find_first_index(char first_index[8]) {
    int r1, r2;
    int x=0;

    r1 = rand()%15;    /* Choose a random number between 1-15 that represents x coordinate of first index */
    r2 = rand()%15;    /* Choose another random number between 1-15 that represents y coordinate of first index  */
    sprintf(first_index,"%d,%d",r1,r2);  /* Writing x and y coordinates in first_index array */
    
}  /* End of find_first_index function */


/* Randomly deciding a direction  */
int decide_direction() {

    /* Direction examples 1-8 */
    /* 1. abc   2. cba */
    
    /* 3. a */   /* 4. c */    /* 5. --a */    /* 6. a-- */    /* 7. --c */    /* 8. c-- */
    /* 3. b */   /* 4. b */    /* 5. -b- */    /* 6. -b- */    /* 7. -b- */    /* 8. -b- */
    /* 3. c */   /* 4. a */    /* 5. c-- */    /* 6. --c */    /* 7. a-- */    /* 8. --a */ 

    int direction;
    direction = 1+rand()%8;
    return direction;        

}  /* End of decide_direction function */


/* Deleting '\n' character that might occur just before '\0' character from answer array */
void delete_enter(char read_answer2[]) {
    int length, i;
    length = strlen(read_answer2);  /* Find length of read_answer2 */

    /* Deleting '\n' character that might occur just before '\0' character */
    read_answer2[length-1] = '\0';  

}  /* End of delete_enter function */


/* Printing words and coordinates of words */
void print_coordinates_and_words(char all_first_indexes[7][8], char all_words[7][8]){
    int i=0;

    while(i<7){
        printf("\nCoordinate: %-10s Word:%6s\n",all_first_indexes[i],all_words[i]);
        i++;
    }
    printf("\n");

}  /* End of print_coordinates_and_words function */
