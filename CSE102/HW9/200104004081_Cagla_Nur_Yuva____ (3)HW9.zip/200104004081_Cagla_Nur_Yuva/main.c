#include <stdio.h>
#include <string.h>

/* Necessary union declarations */
union Person 
{
    char name[50];
    char address[50];
    int phone;
};

union Loan 
{
    float loan_information[3];
};


/* Necessary struct declaration */
struct BankAccount
{
    union Person Customer;
    union Loan Loans[3];
};

/* Indicating whether customer.txt and loan.txt are going to be used as database or not */
int program_mode;

/* Necessary function declarations */
int addCustomer(struct BankAccount account[50], int which_account);  /* Adding a new customer to the bank system by keep recording customer information in customer.txt file */
int newLoan(struct BankAccount account[50], int how_many_loan[50], int which_account);  /* Adding a new loan to a customer */
float calculateLoan(float amount, int period, float interestRate);          /* Recursively calculating loan */
void listCustomers(struct BankAccount account[50], int which_account);      /* Listing customers */
int getReport(int reading_mode, int how_many_loan[50], int which_account);  /* Reading and printing customer or loan report file */
int decide_which_account(int how_many_loan[50]);  /* Deciding the smallest convenient ID to use in the beginning of program */

/* main function */
int main() {

    /* Necessary variable declarations */
    int choice=0, other_choice=0, which_account=1, how_many_loan[50];
    int flag, i, control;
    char c;
    struct BankAccount account[50];

    /* Initializing how_many_loan array to zero */
    for(i=0; i<50; i++) {
        how_many_loan[i] = 0;
    }
    
    /* Asking user whether they want to use their previous information, which is in customer.txt and loan.txt file, like database or not */
    printf("\nYou are about to see main menu. Before that, choose one of them:\n");
    printf("    1. I don't have any customer and loan information kept in customer.txt and loan.txt file.\n");
    printf("    2. I have some information about customers and their loans kept in customer.txt and loan.txt file.\n");

    /* Making sure that input is valid */
    do{
        flag = 1;
        printf("Enter you choice (1 or 2): ");
        scanf("%d", &program_mode);

        /* Cleaning buffer */  
        while ((c = getchar()) != '\n' && c != EOF) { 
            flag = 0;
        }

        /* Checking unvalid input */
        if(program_mode != 1 && program_mode != 2) flag = 0;

        /* Printing warning message for unvalid input */
        if(flag == 0) printf("\nUnvalid input!\n");

    }while(flag == 0);  /* Repeating condition */
  
    /* If user doesn't have previous customer.txt and loan.txt, accounts start with 1 in customer.txt file */
    if(program_mode == 1) which_account = 1;
    
    /* If user has previous customer.txt and loan.txt, ask user whether she wants to use information, which is kept previous customer.txt and loan.txt file, or not */
    else if(program_mode == 2) {
        printf("\nChoose one of them:\n");
        printf("    1. I want to use my previous customer and loan records kept in customer.txt and loan.txt file in this program.\n");
        printf("    2. I don't want to use my previous customer and loan records kept in customer.txt and loan.txt file in this program.\n");
       
       /* Making sure that input is valid */
        do{
            flag = 1;
            printf("Enter you choice (1 or 2): ");
            scanf("%d", &program_mode);

            /* Cleaning buffer */
            while ((c = getchar()) != '\n' && c != EOF) { 
                flag = 0;
            }

            /* Checking unvalid input */
            if(program_mode != 1 && program_mode != 2) flag = 0;

            /* Printing warning message for unvalid input */
            if(flag == 0) printf("\nUnvalid input!\n");

        }while(flag == 0);  /* Repeating condition */
       

        /* If user wants to use her previous information kept in customer.txt and loan.txt file, use their previous records. */
        if(program_mode == 1) {
            which_account = decide_which_account(how_many_loan);  /* Deciding the smallest convenient ID */

            /* Checking file error */
            if(which_account == -1) {
                printf("\nExiting due to file error...\n");
                return (0);
            }

            /* Warning message indicating that you won't be able to access your previous local information, even if you can access and use previous files' information. */
            printf("\nNow you have access to your previous information kept in customer.txt and loan.txt files.\n");
            printf("However, you won't be able to access your previous local information...\n");
        }

        /* If user has customer.txt and loan.txt file and doesn't want to use and access them, remove those previous files. */
        else if(program_mode == 2) {
            which_account = 1;  /* accounts start with 1 in customer.txt file */

            /* Removing files */
            remove("customer.txt");
            remove("loan.txt");
        }
    }
    printf("\n");


    /* main menu */
    do {

        printf("\n======================================\n");
        printf("Welcome to the Bank Management System\n");
        printf("\n======================================\n");

        printf("    1. List All Customers\n");
        printf("    2. Add New Customer\n");
        printf("    3. New Loan Application\n");
        printf("    4. Report Menu\n");
        printf("    5. Exit System\n");
        
        printf("\n");

        /* Making sure that input is valid */
        do{
            flag = 1;
            printf("Enter your choice: ");
            scanf("%d", &choice);

            /* Cleaning buffer */
            while ((c = getchar()) != '\n' && c != EOF) { 
                flag = 0;
            }

            /* Checking unvalid input */
            if(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5) flag = 0;

            /* Printing warning message for unvalid input */
            if(flag == 0) printf("\nUnvalid input!\n");

        }while(flag == 0);  /* Repeating condition */
           
            
        /* Calling appropriate function in accordance with user's choice */
        if(choice == 1) {
            listCustomers(account,which_account);  /* Listing local names and IDs */
        }


        else if(choice == 2) {

            /* Checking whether the number of accounts has been reached to 50 or not */
            if(which_account >= 51) {
                printf("\nYou have %d customers in total. You can't add any customer anymore...\n\n",which_account-1);
            }

            else {
                control = addCustomer(account,which_account);  /* Adding a new customer */

                /* Checking file error */
                if(control == 1) {
                    printf("\nExiting due to file error...\n");
                    return (0);
                }

                which_account++;  /* Increment the smallest convenient ID by one */
            }
        }


        else if(choice == 3) {
            control = newLoan(account, how_many_loan,which_account);  /* Adding a new loan */

            /* Checking file error */
            if(control == 1) {
                printf("\nExiting due to file error...\n");
                return (0);
            }
        }

        else if(choice == 4) {
            do{
                
                /* sub menu */
                printf("    1. Customer Detail\n");
                printf("    2. Loan Detail\n");
                printf("    3. Exit\n");

                printf("\n");

                /* Making sure that input is valid */
                do{
                    flag = 1;
                    printf("Enter your choice: ");
                    scanf("%d", &other_choice);
                    
                    /* Cleaning buffer */
                    while ((c = getchar()) != '\n' && c != EOF) { 
                        flag = 0;
                    }

                    /* Checking unvalid input */
                    if(other_choice != 1 && other_choice != 2 && other_choice != 3) flag = 0;

                    /* Printing warning message for unvalid input */
                    if(flag == 0) printf("\nUnvalid input!\n");

                }while(flag == 0);  /* Repeating condition */

                /* Calling appropriate function in accordance with user's choice */
                if(other_choice != 3) {
                    control = getReport(other_choice,how_many_loan,which_account);  /* Getting customer or loan report */

                    /* Checking file error */
                    if(control == 1) {
                        printf("\nExiting due to file error...\n");
                        return (0);
                    }
                }

                /* Quitting condition */
                else if(other_choice == 3){
                    break;
                }

            }while(other_choice != 3);  /* Repeating condition */
        }

        /* Quitting condition */
        else if(choice == 5) {
            printf("\nExiting...\n");
            break;
        }


    }while(choice != 5);  /* Repeating condition */

    return (0);

}  /* end of main function */


/* Reading and printing customer or loan report file */
int getReport(int reading_mode, int how_many_loan[50], int which_account) {

    /* Necessary variable declarations */
    FILE *ptr;
    char c;
    int get_id, which_loan, read_id=0, count=0,index=0, count_read=0, x=0, flag=0, read_which_loan, read_period, yedek_period;
    float read_loans[3],sum=0,read_amount, read_interest_rate;

    /* Printing customer report */
    if(reading_mode == 1) {

        /* Opening customer.txt file */
        ptr = fopen("customer.txt","r"); 

        /* Checking and handling file error */
        if(ptr == NULL) {
            printf("\ncustomer.txt file couldn't be opened...\n");
       
            ptr = fopen("customer.txt","w");
            fclose(ptr);
            ptr = fopen("customer.txt","r"); 

            if(ptr == NULL) {
                printf("\ncustomer.txt file couldn't be opened...\n");
                return (1);
            }

            else if(ptr != NULL) printf("customer.txt file is opened...\n");
        }
        printf("\n");


        /* Checking whether customer.txt file is empty or not */
        c = getc(ptr);
        if(c == EOF) {
            printf("\nThere is no record in customer.txt file...\n\n");
        }

        /* Reading all customers from customer.txt file and printing them to the screen */
        else {
            putchar(c);
            do{
                c = getc(ptr);
                if(c == EOF) break;
                else putchar(c);

            }while(c != EOF);

        }
        
        /* Closing customer.txt file */
        fclose(ptr);   
    }


    /* Printing loan report */
    else if(reading_mode == 2) {
        
        /* Making sure that input is valid */
        do{
            flag = 1;
            printf("Enter the user ID: ");
            scanf("%d", &get_id);

            /* Cleaning buffer */
            while ((c = getchar()) != '\n' && c != EOF) { 
                flag = 0;
            }

            /* Checking invalid input */
            if(get_id<=0) flag=0;

            /* Checking whether there are any customer record or not in customer.txt file */    
            if(which_account == 1 && flag == 1) {
                printf("\nThere is no customer and loan record in customer.txt file and loan.txt file...\n\n");
                return (2);
            }

            /* Checking whether there is a desired customer record or not in customer.txt file */
            if(get_id>=which_account && flag == 1) {
                printf("\nThere is no ID = %d customer in customer.txt file...\n\n", get_id);
                flag=0;
                continue;
            }

            /* Printing warning message for unvalid input */  
            if(flag == 0) printf("Unvalid input!\n");

        }while(flag == 0);  /* Repeating condition */


        /* Making sure that input is valid */
        do{
            flag = 1;
            printf("Enter which loan you want to see: ");
            scanf("%d", &which_loan);

            /* Cleaning buffer */
            while ((c = getchar()) != '\n' && c != EOF) { 
                flag = 0;
            }

            /* Checking invalid input */
            if(which_loan<=0) flag=0;

            /* Checking whether there are any loan record in loan.txt file or not */
            if(how_many_loan[get_id-1] == 0 && flag == 1) {
                printf("\nThere is no loan record for ID = %d in loan.txt file...\n",get_id);
                return (2);
            }

            /* Checking whether there is a desired loan record or not in loan.txt file */
            if(which_loan > how_many_loan[get_id-1] && flag == 1) {
                printf("\nThere is no %d.loan recorded in loan.txt file for ID = %d...\n\n",which_loan,get_id);
                flag=0;
                continue;
            }

            /* Printing warning message for unvalid input */
            if(flag == 0) printf("Unvalid input!\n");
            

        }while(flag == 0);  /* Repeating condition */
       

        /* Opening loan.txt file */
        ptr = fopen("loan.txt","r"); 

        /* Checking and handling file error */
        if(ptr == NULL) {
            printf("\nloan.txt file couldn't be opened...\n");
               
            ptr = fopen("loan.txt","w");
            fclose(ptr);
            ptr = fopen("loan.txt","r"); 

            if(ptr == NULL){
                printf("\nloan.txt file couldn't be opened...\n");
                return (1);
            } 
            else if(ptr != NULL) printf("loan.txt file is opened...\n");
        }

        c = 'a';
        flag=0;

        /* Reading desired loan information from loan.txt file */
        while(count < how_many_loan[get_id-1]) {
             
            count_read=0;
            while((c = getc(ptr)) != '\n') {
    
                if(c == '=') {
                    count_read++;  
                    c = getc(ptr);
                }

                /* Reading ID from loan.txt file */
                if(count_read == 1) {
                    fscanf(ptr,"%d",&read_id);        
                }
                
                /* Reading period from loan.txt file */
                if(count_read == 2){
                    fscanf(ptr,"%d",&read_period);
                    yedek_period = read_period;
                }

                /* Reading loan from loan.txt file */
                if(count_read == 3){
                    fscanf(ptr,"%f",&read_loans[index]);
                }

                /* Reading which_loan from loan.txt file */
                if(count_read == 4){
                    fscanf(ptr,"%d",&read_which_loan);
                }

                /* Reading amount from loan.txt file */
                if(count_read == 5){
                    fscanf(ptr,"%f",&read_amount);
                }

                /* Reading interest rate from loan.txt file */
                if(count_read == 6){
                    fscanf(ptr,"%f",&read_interest_rate);
                }
            }

            /* Indicating that desired ID has been found in loan.txt file */
            if(read_id == get_id) {
                count++;
                index++;
            }

            /* Indicating that desired loan information has been found in loan.txt file */
            if(count == which_loan && flag == 0){
                flag = 1;
                x = 0;
                printf("\nID =  %d // Period = %d // Loan = %.4f // Which Loan =  %d // Amount = %.4f // Interest Rate = %.7f\n",read_id,read_period,read_loans[which_loan-1],read_which_loan,read_amount,read_interest_rate);

                /* Printing month installments */
                while(read_period+2>x) {
                    c = getc(ptr);
                   
                    if(c == '\n') x++;
                    putchar(c);
                }
                
                read_period = yedek_period;
            }

            /* When you are done with loan.txt file, print all Loans */
            if(count == how_many_loan[get_id-1]) {
                printf("Loans = [");

                for(index=0; index<how_many_loan[get_id-1]; index++){
                    printf("%.2f + ",read_loans[index]);
                    sum += read_loans[index];
                }
                printf("\b\b\b] => %.2f\n\n",sum);

                /* Quitting condition */
                break;
            }

            /* Going through undesired loan information in loan.txt file */
            if(count < which_loan) {
                x = 0;
                while(read_period+2>x) {
                    c = getc(ptr);
                   
                    if(c == '\n') x++;
                   
                }
                read_period = yedek_period;
            }

        }
        
        /* Closing loan.txt file */
        fclose(ptr);
    }
     
    return (0);

}  /* end of getReport function */


/* Adding a new loan to a customer */
int newLoan(struct BankAccount account[50], int how_many_loan[50], int which_account) {

    /* Necessary variable declarations */
    FILE *ptr;
    float Loan, loan_amount, loan_interest_rate, loan_period;
    int which_user, b,i,flag;
    char c;
    
    /* Making sure that input is valid */
    do{
        flag = 1;
        printf("\nPlease enter ID number of the user for whom you want to make new loan application: ");
        scanf("%d", &which_user);

        /* Cleaning buffer */  
        while ((c = getchar()) != '\n' && c != EOF) { 
            flag = 0;
        }

        /* Checking unvalid input */
        if(which_user<=0) flag=0;

        /* Checking whether there are any recorded customer in customer.txt file or not */
        if(which_account == 1 && flag == 1) {
            printf("\nThere is no recorded customer in customer.txt file...\n");
            return (2);
        }

        /* Checking whether there is desired customer in customer.txt file or not */
        if(which_user>=which_account && flag == 1){
            flag = 0;
            printf("\nThere is no customer whose ID = %d in customer.txt file...\n",which_user);
            continue;
        }

        /* Printing warning message for unvalid input */
        if(flag == 0) printf("Unvalid input!\n");
            
    }while(flag == 0);  /* Repeating condition */
    

    /* Checking whether loan limit, which is 3, has been reached or not */
    if(how_many_loan[which_user-1] == 3) {
        printf("\nYou have %d loans in total for the customer ID = %d. You can't add more loans for ID = %d...\n\n",how_many_loan[which_user-1],which_user,which_user);
        return(-1);
    }

    /* Incrementing the number of loans by one given to the person whose ID is indicated above */
    ++how_many_loan[which_user-1];
    b = how_many_loan[which_user-1];


    /* Making sure that input is valid */
    do{
        flag = 1;
        printf("\nPlease enter amount: ");
        scanf("%f", &account[which_user-1].Loans[b-1].loan_information[0]);

        /* Cleaning buffer */  
        while ((c = getchar()) != '\n' && c != EOF) { 
            flag = 0;
        }

        /* Checking unvalid input */
        if(account[which_user-1].Loans[b-1].loan_information[0] <= 0) flag=0;

        /* Printing warning message for unvalid input */
        if(flag == 0) printf("Unvalid input!\n");
            

    }while(flag == 0);  /* Repeating condition */
    
    loan_amount = account[which_user-1].Loans[b-1].loan_information[0];  /* amount is assigned to another variable to increase code readibility */

    /* Making sure that input is valid */
    do{
        flag = 1;
        printf("\nPlease enter interest rate: ");
        scanf("%f", &account[which_user-1].Loans[b-1].loan_information[1]);

        /* Cleaning buffer */  
        while ((c = getchar()) != '\n' && c != EOF) { 
            flag = 0;
        }

        /* Checking invalid input */
        if(account[which_user-1].Loans[b-1].loan_information[1] <= 0) flag=0;

        /* Printing warning message for invalid input */
        if(flag == 0) printf("Invalid input!\n");
            
    }while(flag == 0);  /* Repeating condition */
    
    loan_interest_rate = account[which_user-1].Loans[b-1].loan_information[1];  /* interest rate is assigned to another variable to increase code readibility */


    /* Making sure that input is valid */
    do{
        flag = 1;
        printf("\nPlease enter period: ");
        scanf("%f", &account[which_user-1].Loans[b-1].loan_information[2]);

        /* Cleaning buffer */  
        while ((c = getchar()) != '\n' && c != EOF) { 
            flag = 0;
        }

        /* Checking invalid input */
        if(account[which_user-1].Loans[b-1].loan_information[2] <= 0) flag=0;

        /* Printing warning message for invalid input */
        if(flag == 0) printf("Invalid input!\n");
            

    }while(flag == 0);  /* Repeating condition */
    
    loan_period = account[which_user-1].Loans[b-1].loan_information[2];  /* period is assigned to another variable to increase code readibility */

    /* Calculating Loan */
    Loan = calculateLoan(loan_amount,(int)loan_period,loan_interest_rate);

    /* Opening loan.txt file */
    ptr = fopen("loan.txt","a");

    /* Checking and handling file error */
    if(ptr == NULL) {
        printf("\nloan.txt file couldn't be opened...\n");
        ptr = fopen("loan.txt","a");
        if(ptr == NULL) {
            printf("\nloan.txt file couldn't be opened...\n");
            return (1);
        }
    }


    /* Writing loan information to loan.txt file */
    fprintf(ptr,"ID = %2d // Period = %d // Loan = %.4f // Which Loan = %2d // Amount = %.4f // Interest Rate = %.7f\n",which_user,(int)loan_period,Loan, how_many_loan[which_user-1], loan_amount, loan_interest_rate);
    fprintf(ptr,"Total Credit Value = %.4f\n",Loan);

    for(i=0; i<(int)loan_period; i++){
        fprintf(ptr,"%d. Month Installment = %.4f\n",i+1,Loan/((int)loan_period));
    }
    fprintf(ptr,"\n"); 

    
    fclose(ptr);   /* Closing loan.txt file */
    return (0);
    
}  /* end of newLoan function */


/* Adding a new customer to the bank system by keep recording customer information in customer.txt file */
int addCustomer(struct BankAccount account[50], int which_account) {

    /* Necessary variable declarations */
    FILE *ptr;
    char c, yedek_name[50];
    int id,flag;

    /* Opening customer.txt file */
    ptr = fopen("customer.txt","a");

    /* Checking and handling file error */
    if(ptr == NULL) {
        printf("\ncustomer.txt file couldn't be opened...\n");
        ptr = fopen("customer.txt","a");
        if(ptr == NULL) {
            printf("\ncustomer.txt file couldn't be opened...\n");
            return (1);
        }
    }
    

    /* Writing customer ID to customer.txt file */
    fprintf(ptr,"Customer ID = %d\n",which_account);

    /* Getting customer's name from user */
    printf("\nPlease enter Name: ");
    scanf("%[^\n]%*c", account[which_account-1].Customer.name);

    /* Duplicating name */
    strcpy(yedek_name,account[which_account-1].Customer.name);

    /* Writing customer's name to customer.txt file */
    fprintf(ptr,"Customer Name = %s\n",account[which_account-1].Customer.name);   


    /* Making sure that input is valid */
    do{
        flag = 1;
        printf("\nPlease enter phone number: ");
        scanf("%d",&account[which_account-1].Customer.phone);

        /* Cleaning buffer */  
        while ((c = getchar()) != '\n' && c != EOF) { 
            flag = 0;
        }

        /* Checking invalid input */
        if(account[which_account-1].Customer.phone <= 0 || account[which_account-1].Customer.phone > 2147483647) flag=0;

        /* Printing warning message for invalid input */
        if(flag == 0) printf("Invalid input!\n");
            

    }while(flag == 0);  /* Repeating condition */

    fprintf(ptr,"Customer Phone = %d\n",account[which_account-1].Customer.phone);   /* Writing customer's phone number to customer.txt file */

    /* Getting customer's address from user */
    printf("\nPlease enter address: ");
    scanf("%[^\n]%*c", account[which_account-1].Customer.address);

    /* Writing customer's address to customer.txt file */
    fprintf(ptr,"Customer Address = %s\n\n",account[which_account-1].Customer.address); 

    /* It is to keep name in union to be able to print name using struct and union */
    strcpy(account[which_account-1].Customer.name,yedek_name);
    
    /* Closing customer.txt file */
    fclose(ptr);
    return (0);

}  /* end of addCustomer function */


/* Recursively calculating loan */
float calculateLoan(float amount, int period, float interestRate) { 
    if(period == 0) {
        return amount;
    }

    else {
        return (1+interestRate)*calculateLoan(amount,--period,interestRate);
    }
    
}


/* Listing customers */
void listCustomers(struct BankAccount account[50], int which_account) {
    int i;

    printf("\n");
    if(which_account == 1) {
        printf("\nThere is no customer that can be shown...\n\n");
    }

    else {
        /* Printing customers and their ID's to the screen */
        for(i=1; i<which_account; i++) {
            printf("Customer ID = %d\n",i);
            printf("Customer Name = %s\n\n",account[i-1].Customer.name);
        }
    }
    
}


/* Deciding the smallest convenient ID to use in the beginning of program */
int decide_which_account(int how_many_loan[50]) {

    /* Necessary variable declarations */
    FILE *ptr;
    char c = 'a';
    int the_num_of_current_id=0, x=0, read_id;

    /* Opening customer.txt file */
    ptr = fopen("customer.txt","r"); 

    /* Checking and handling file error */
    if(ptr == NULL) {
        printf("\ncustomer.txt file couldn't be opened...\n");
    
        ptr = fopen("customer.txt","w");
        fclose(ptr);
        ptr = fopen("customer.txt","r"); 

        if(ptr == NULL) {
            printf("\ncustomer.txt file couldn't be opened...\n");
            return (-1);
        }
        else if(ptr != NULL) printf("customer.txt file is opened...\n");

    }
    
    /* Calculating how many customer there are in customer.txt file using '=' characters */
    while(c != EOF) {
        c = getc(ptr);
        if(c == '=') x++;
    }
    fclose(ptr);  /* Closing customer.txt file */

    c='a';

    /* Opening loan.txt file */
    ptr = fopen("loan.txt","r");

    /* Checking and handling file error */
    if(ptr == NULL){
        printf("\nloan.txt file couldn't be opened...\n");
     
        ptr = fopen("loan.txt","w");
        fclose(ptr);
        ptr = fopen("loan.txt","r");

        if(ptr == NULL) {
           printf("\nloan.txt file couldn't be opened...\n"); 
           return (-1);
        }
        else if(ptr != NULL) printf("loan.txt file is opened...\n");

    }

    /* Calculating how many loan there are in loan.txt file */
    while(c != EOF) {
        c = getc(ptr);
        if(c == 'D') {
            c = getc(ptr);
            c = getc(ptr);
            c = getc(ptr);
            fscanf(ptr,"%d",&read_id);
            ++how_many_loan[read_id-1];
        }
    }

    /* Closing loan.txt file */
    fclose(ptr);

    /* Returning the smallest convenient ID */
    return ((x/4)+1);

}  /* end of decide_which_account function */




