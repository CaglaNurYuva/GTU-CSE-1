#include <stdio.h>
#include <stdlib.h>
#define STACK_BLOCK_SIZE 10

/* Struct declaration */
typedef struct {
    int *array;
    int currentsize;
    int maxsize;
}stack;


/* Necessary function declarations */
void arrange_moving_pattern_for_disk_one(char moving_pattern[2], int tower_size);  /* Arranging moving pattern for 1.disc's first move by looking whether tower size is an odd number or even number */
int push(stack *s, int d); /* Adding desired element to a stack and increasing stack array's size by 1 */
int pop(stack *s);         /* Getting a stack's top element and shrinking stack array's size by 1 */
int peek(stack *s);        /* Looking a stack's top element without getting it */
stack* init_return();      /* Initializing stack and returning its pointer */
int init(stack *s);        /* Checking whether stack is successfuly initialized or not */
void My_Tower_Of_Hanoi_Solution(stack *first_stick, stack *second_stick, stack *third_stick, char *moving_pattern, int tower_size);  /* Solving tower of hanoi puzzle */


/* main function */
int main() {

    /* Necessary variable declarations */
    int tower_size;               /* This variable keeps the size of tower */
    int check_initialize_error=0; /* This variable checks whether an error occurred or not while initializing struct */
    char moving_pattern[2];       /* This array keeps the first move pattern for 1.disc */
    int flag;                     /* Checking whether input taken from user is valid or not */
    stack *first_stick=NULL, *second_stick=NULL, *third_stick=NULL; /* These pointers are going to be used as stacks to solve tower of hanoi puzzle */
    char c;                       /* This variable is used when buffer is being cleaned */


    /* Initializing first stack */
    first_stick = init_return();

    /* Checking whether an error occurred or not while initializing first stack */
    check_initialize_error = init(first_stick);
    if(check_initialize_error == 0) {  /* if initialization is unsuccesful, quit program. */
        return (0);
    }

    /* Initializing second stack */
    second_stick = init_return();

    /* Checking whether an error occurred or not while initializing second stack */
    check_initialize_error = init(second_stick);
    if(check_initialize_error == 0) {  /* if initialization is unsuccesful, quit program. */
        return (0);
    }

    /* Initializing third stack */
    third_stick = init_return();

    /* Checking whether an error occurred or not while initializing third stack */
    check_initialize_error = init(third_stick);
    if(check_initialize_error == 0) {  /* if initialization is unsuccesful, quit program. */
        return (0);
    }

  
    /* Checking whether input taken from user is valid or not */
    do{
        flag = 1;

        /* Getting tower size from user as input */
        printf("Enter Tower size: ");
        scanf("%d",&tower_size);

        /* Cleaning buffer */
        while ((c = getchar()) != '\n' && c != EOF) { 
            flag = 0;
        }

        /* Unvalid input condition */
        if(tower_size < 0) flag = 0;

        /* Printing warning message for unvalid input */
        if(flag == 0) printf("\nUnvalid input!\n");

    }while(flag == 0);  /* Repeating condition */

    
    /* If tower size is 0, there is no disc therefore tower of hanoi puzzle cannot be solved. */
    if(tower_size == 0) {
        printf("\nThere is no disc\n");
        return (0);
    }

    
    /* Arranging 1. disc's first moving patern */
    arrange_moving_pattern_for_disk_one(moving_pattern, tower_size);
  
    /* Solving tower of hanoi puzzle */
    My_Tower_Of_Hanoi_Solution(first_stick, second_stick, third_stick, moving_pattern, tower_size);
    
    /* Freeing having allocated memory for sticks */
    free(first_stick);
    free(second_stick);
    free(third_stick);
    
    return(0);

}  /* end of main function */


/* Arranging moving pattern for 1.disc's first move by looking whether tower size is an odd number or even number */
void arrange_moving_pattern_for_disk_one(char moving_pattern[2], int tower_size) {

    /* If tower size is odd, arrange 1.disc's first moving pattern */
    if((tower_size%2) == 1){
        moving_pattern[0] = '1';
        moving_pattern[1] = '3';
    }

    /* If tower size is even, arrange 1.disc's first moving pattern */
    else if((tower_size%2) == 0){
        moving_pattern[0] = '1';
        moving_pattern[1] = '2';
    }
}


/* Solving tower of hanoi puzzle */
void My_Tower_Of_Hanoi_Solution(stack *first_stick, stack *second_stick, stack *third_stick, char *moving_pattern, int tower_size) {
    int disc;             /* Indicating disc number */
    int finish_puzzle=0;  /* Indicating whether tower of hanoi puzzle has been solved or not */
    int top_eleman1, top_eleman2, top_eleman3; /* These variables are used to store top elements of first stick, second stick and third stick */
    int flag_1, flag_2, flag_3;                /* These variables are used to indicate which stick carries 1.disc */
    int i;


    /* Algorithm explanation: If step number is odd, definitely 1.disc is going to be moved. If step number is even, definitely 
     * other than 1.disc is going to be moved. 1.disc's first move is decided by checking tower size. If tower size is odd, 1.disc
     * goes from '1' to '3'. If tower size is even, 1.disc goes from '1' to '2'. Other moves of 1.disc should be thought like that: 
     * 1.disc cannot go to the stick which 1.disc is in currently. There are 2 possible stick left that 1.disc can go. 
     * However, 1.disc never goes to the stick which 1.disc were in it before coming to its current stick. For the sake of ease, 
     * it can be thought that 1.disc loves going to different sticks therefore it doesn't want to go to a stick that it has already
     * been lately. When it comes to other discs moves, they cannot go to the stick which they are already in currently. There are 
     * 2 possible stick left that these discs can go. However, there is only one valid move since bigger discs cannot be put on top
     * of smaller discs and there might be empty sticks. */

     
    /* Putting all discs to first stick in descending order */
    for(i=tower_size; i>=1; i--){
        push(first_stick,i);
    }


    /* Keep moving discs until tower of hanoi puzzle has been solved */
    for(i=1; finish_puzzle != 1; i++){
        
        /* If step number is odd, definitely 1.disc is going to be moved */
        if(i%2 == 1){

            /* First move to do at the very beginning of the puzzle */
            if(i == 1){
                disc = pop(first_stick);  /* Getting 1.disc from first stick */
               
               /* moving_pattern array's 0.index keeps from where 1.disc should be taken, its 1.index keeps where 1.disc should be put.
                * These places were decided by checking whether tower size is odd or even. */ 
                if(moving_pattern[1] == '2'){  
                    push(second_stick,disc);  /* Putting 1.disc in second stick */
                    printf("Disk %d moved from '%c' to '%c' \n",disc,'1','2');
                }

                else if(moving_pattern[1] == '3'){
                    push(third_stick,disc);  /* Putting 1.disc in third stick */
                    printf("Disk %d moved from '%c' to '%c' \n",disc,'1','3');

                    /* If all discs are in third stick, and top element of third stick is 1.disc, game is over. */
                    if(disc == 1 && ((third_stick->currentsize+1) == tower_size)) finish_puzzle = 1; 
                }

            }

            /* If it is not first move to do at the very beginning of the puzzle */
            else if(i != 1) {

                /* Looking at top elements of three stacks */
                top_eleman1 = peek(first_stick);
                top_eleman2 = peek(second_stick);
                top_eleman3 = peek(third_stick);
                flag_1 = flag_2 = flag_3 = 0;   /* They indicate 1.disc's location. */

                /* Locating 1.disc */
                if(top_eleman1 == 1) flag_1 = 1;
                else if(top_eleman2 == 1)flag_2 = 1;
                else if(top_eleman3 == 1)flag_3 = 1;

                /* If 1.disc is in first stick */
                if(flag_1 == 1) {
                    disc = pop(first_stick);       /* Getting 1.disc from first stick */

                    /* If 1.disc were in second stick before coming to its current location, 1.disc won't be put in second stick */
                    if(moving_pattern[0] == '2'){  
                        push(third_stick,disc);    /* Putting 1.disc in third stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'1','3');

                        /* Keeping record of old and new locations of 1.disc */
                        moving_pattern[0] = '1';
                        moving_pattern[1] = '3';

                        /* If all discs are in third stick, and top element of third stick is 1.disc, game is over. */
                        if(disc == 1 && ((third_stick->currentsize+1) == tower_size)) finish_puzzle = 1;
                    }

                    /* If 1.disc were in third stick before coming to its current location, 1.disc won't be put in third stick */
                    else if(moving_pattern[0] == '3'){  
                        push(second_stick,disc);        /* Putting 1.disc in second stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'1','2');

                        /* Keeping record of old and new locations of 1.disc */
                        moving_pattern[0] = '1';
                        moving_pattern[1] = '2';
                    }
                }

                /* If 1.disc is in second stick */
                else if(flag_2 == 1){
                    disc = pop(second_stick);   /* Getting 1.disc from second stick */

                    /* If 1.disc were in first stick before coming to its current location, 1.disc won't be put in first stick */
                    if(moving_pattern[0] == '1'){
                        push(third_stick,disc); /* Putting 1.disc in third stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'2','3');

                        /* Keeping record of old and new locations of 1.disc */
                        moving_pattern[0] = '2';
                        moving_pattern[1] = '3';

                        /* If all discs are in third stick, and top element of third stick is 1.disc, game is over. */
                        if(disc == 1 && ((third_stick->currentsize+1) == tower_size)) finish_puzzle = 1;
                    }

                    /* If 1.disc were in third stick before coming to its current location, 1.disc won't be put in third stick */
                    else if(moving_pattern[0] == '3'){
                        push(first_stick,disc); /* Putting 1.disc in first stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'2','1');

                        /* Keeping record of old and new locations of 1.disc */
                        moving_pattern[0] = '2';
                        moving_pattern[1] = '1';
                    }
                } 

                /* If 1.disc is in third stick */
                else if(flag_3 == 1) {
                    disc = pop(third_stick);  /* Getting 1.disc from third stick */

                    /* If 1.disc were in first stick before coming to its current location, 1.disc won't be put in first stick */
                    if(moving_pattern[0] == '1'){
                        push(second_stick,disc);  /* Putting 1.disc in second stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'3','2');

                        /* Keeping record of old and new locations of 1.disc */
                        moving_pattern[0] = '3';
                        moving_pattern[1] = '2';
                    }

                    /* If 1.disc were in second stick before coming to its current location, 1.disc won't be put in second stick */
                    else if(moving_pattern[0] == '2'){
                        push(first_stick,disc);  /* Putting 1.disc in first stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'3','1');

                        /* Keeping record of old and new locations of 1.disc */
                        moving_pattern[0] = '3';
                        moving_pattern[1] = '1';
                    }
                } 
            }
        }


        /* If step number is even, definitely one of the discs other than 1.disc is going to be moved */
        if(i%2 == 0){

            /* Looking at top elements of three stacks */
            top_eleman1 = peek(first_stick);
            top_eleman2 = peek(second_stick);
            top_eleman3 = peek(third_stick);
            flag_1 = flag_2 = flag_3 = 0;  /* They indicate 1.disc's location. */

            /* Locating 1.disc */
            if(top_eleman1 == 1) flag_1 = 1;
            else if(top_eleman2 == 1)flag_2 = 1;
            else if(top_eleman3 == 1)flag_3 = 1;

            /* If 1.disc is in first stick, there is nothing to do with first stick and 1.disc */
            if(flag_1 == 1){
                
                /* If second stick and third stick are not empty */
                if(top_eleman2 != -1 && top_eleman3 != -1){

                    /* Checking valid move by looking which disc is smaller than other disc */
                    if(top_eleman2>top_eleman3){
                        disc = pop(third_stick);  /* Getting the disc that is in third stick */
                        push(second_stick,disc);  /* Putting the disc in second stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'3','2');
                    }

                    else if(top_eleman3>top_eleman2){
                        disc = pop(second_stick);  /* Getting the disc that is in second stick */
                        push(third_stick,disc);     /* Putting the disc in third stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'2','3');

                        /* If all discs are in third stick, and top element of third stick is 1.disc, game is over. */
                        if(disc == 1 && ((third_stick->currentsize+1) == tower_size)) finish_puzzle = 1;
                    }
                }

                /* If second stick is empty */
                else if(top_eleman2 == -1){
                    disc = pop(third_stick);  /* Getting the disc that is in third stick */
                    push(second_stick,disc);  /* Putting the disc in second stick */
                    printf("Disk %d moved from '%c' to '%c' \n",disc,'3','2');
                }

                /* If third stick is empty */
                else if(top_eleman3 == -1){
                    disc = pop(second_stick);  /* Getting the disc that is in second stick */
                    push(third_stick,disc);    /* Putting the disc in third stick */
                    printf("Disk %d moved from '%c' to '%c' \n",disc,'2','3');

                    /* If all discs are in third stick, and top element of third stick is 1.disc, game is over. */
                    if(disc == 1 && ((third_stick->currentsize+1) == tower_size)) finish_puzzle = 1;
                }
               
            }

            /* If 1.disc is in second stick, there is nothing to do with second stick and 1.disc */
            else if(flag_2 == 1){
                
                /* If first stick and third stick are not empty */
                if(top_eleman1 != -1 && top_eleman3 != -1){

                    /* Checking valid move by looking which disc is smaller than other disc */
                    if(top_eleman1>top_eleman3){
                        disc = pop(third_stick);  /* Getting the disc that is in third stick */
                        push(first_stick,disc);   /* Putting the disc in first stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'3','1');
                    }

                    else if(top_eleman3>top_eleman1){
                        disc = pop(first_stick);  /* Getting the disc that is in first stick */
                        push(third_stick,disc);   /* Putting the disc in third stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'1','3');

                        /* If all discs are in third stick, and top element of third stick is 1.disc, game is over. */
                        if(disc == 1 && ((third_stick->currentsize+1) == tower_size)) finish_puzzle = 1;
                    }
                }

                /* If first stick is empty */
                else if(top_eleman1 == -1){
                    disc = pop(third_stick);  /* Getting the disc that is in third stick */
                    push(first_stick,disc);   /* Putting the disc in first stick */
                    printf("Disk %d moved from '%c' to '%c' \n",disc,'3','1');
                }

                /* If third stick is empty */
                else if(top_eleman3 == -1){ 
                    disc = pop(first_stick);  /* Getting the disc that is in first stick */
                    push(third_stick,disc);   /* Putting the disc in third stick */
                    printf("Disk %d moved from '%c' to '%c' \n",disc,'1','3');

                    /* If all discs are in third stick, and top element of third stick is 1.disc, game is over. */
                    if(disc == 1 && ((third_stick->currentsize+1) == tower_size)) finish_puzzle = 1;
                }
                
            }

            /* If 1.disc is in third stick, there is nothing to do with third stick and 1.disc */
            else if(flag_3 == 1){

                /* If first stick and second stick are not empty */
                if(top_eleman1 != -1 && top_eleman2 != -1){

                    /* Checking valid move by looking which disc is smaller than other disc */
                    if(top_eleman1>top_eleman2){
                        disc = pop(second_stick);  /* Getting the disc that is in second stick */
                        push(first_stick,disc);    /* Putting the disc in first stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'2','1');
                    }

                    else if(top_eleman2>top_eleman1){
                        disc = pop(first_stick);  /* Getting the disc that is in first stick */
                        push(second_stick,disc);  /* Putting the disc in second stick */
                        printf("Disk %d moved from '%c' to '%c' \n",disc,'1','2');
                    }
                }

                /* If first stick is empty */
                else if(top_eleman1 == -1){
                    disc = pop(second_stick);  /* Getting the disc that is in second stick */
                    push(first_stick,disc);    /* Putting the disc in first stick */
                    printf("Disk %d moved from '%c' to '%c' \n",disc,'2','1');
                }

                /* If second stick is empty */
                else if(top_eleman2 == -1){
                    disc = pop(first_stick);  /* Getting the disc that is in first stick */
                    push(second_stick,disc);  /* Putting the disc in second stick */
                    printf("Disk %d moved from '%c' to '%c' \n",disc,'1','2');
                }
            }
        }
    }

}  /* end of My_Tower_Of_Hanoi_Solution function */


/* Looking a stack's top element without getting it */
int peek(stack *s) {

    /* Indicating stack is empty */
    if(s->currentsize == -1) return (-1);
    
    /* Returning top element of a stack */
    else return (s->array[(s->currentsize)]);
    
}  /* end of peek function */


/* Getting a stack's top element and shrinking stack array's size by 1 */
int pop(stack *s) {
    int *temp;  /* Temporary array to store stack array's elements temporarily */
    int i, get_eleman;
    int old_maxsize = (s->maxsize);

    /* Indicating stack is empty */
    if(s->currentsize == -1) return(-1);

    else {
        temp = (int*)malloc(sizeof(int)*(s->currentsize+1)); /* Dynamically allocate memory for temporary array */
        get_eleman = s->array[s->currentsize]; /* Getting top value of a stack */
        --(s->currentsize); /* Shrinking current size, which is similar to index of stack array, of stack array by one */

        /* Temporarily storing stack array's elements in a temporary array */
        for(i=0; i<=s->currentsize; i++){
            temp[i] = s->array[i];
        }

        free(s->array);  /* Freeing stack array */
        s->array = (int*)malloc(sizeof(int)*(s->maxsize-1));   /* Shrinking stack array's size by 1 */
        --(s->maxsize);  /* Shrinking maxsize of stack array by 1 */

        /* Restoring stack array's previous elements */
        for(i=0; i<=s->currentsize; i++){
            s->array[i] = temp[i];
        }

        /* Freeing temporary array */
        free(temp);

    }

    /* Returning having been taken element of stack array */
    return (get_eleman);

}  /* end of pop function */


/* Adding desired element to a stack and increasing stack array's size by 1 */
int push(stack *s, int d) {
    int *temp;  /* Temporary array to store stack array's elements temporarily */
    int i, old_maxsize = (s->maxsize);

    /* If stack array is full, increase its size by 1 */
    if((s->currentsize + 1) == s->maxsize){
        temp = (int*)malloc(sizeof(int)*(s->currentsize+1));  /* Dynamically allocate memory for temporary array */

        /* Temporarily storing stack array's elements in a temporary array */
        for(i=0; i<=s->currentsize; i++){
            temp[i] = s->array[i];
        }
 
        free(s->array);  /* Freeing stack array */
        s->array = (int*)malloc(sizeof(int)*(s->maxsize+1)); /* Increasing stack array's size by 1 */
        ++(s->maxsize);  /* Increasing maxsize of stack array by 1 */

        /* Restoring stack array's previous elements */
        for(i=0; i<=s->currentsize; i++){
            s->array[i] = temp[i];
        }

        /* Adding desired element to stack array */
        s->array[++(s->currentsize)] = d;

        /* Freeing temporary array */
        free(temp);
    
    }

    else {
        /* Adding desired element to stack array */
        s->array[++(s->currentsize)] = d;
    }

    /* Returning having been added element */
    return (d);

}  /* end of push function */


/* Initializing stack, stack array, its currentsize and its maxsize */
stack* init_return() {
    stack *stick;

    stick = (stack*)malloc(sizeof(stack));   /* Dynamically allocating stack */
    stick->array = (int*)malloc(sizeof(int)*STACK_BLOCK_SIZE);  /* Dynamically allocating stack array */
    
    stick->currentsize = -1;  /* Initializing currentsize of stick -1 */
    stick->maxsize = STACK_BLOCK_SIZE;  /* Initializing maxsize of stick STACK_BLOCK_SIZE */

    /* Returning pointer of stack */
    return stick;

}  /* end of init_return function */


/* Checking whether stack is successfuly initialized or not */
int init(stack *s) {

    /* Returning 0 if initialization is unsuccessful */
    if((s == NULL) || (s->currentsize != -1) || (s->maxsize != STACK_BLOCK_SIZE) || (s->array == NULL)) return (0);

    /* Returning 1 if initialization is successful */
    else return (1);

}  /* end of init function */

