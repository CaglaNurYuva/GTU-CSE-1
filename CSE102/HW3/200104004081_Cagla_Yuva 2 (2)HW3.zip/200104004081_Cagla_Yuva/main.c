#include <stdio.h>
#include <math.h>

/* Functions used by part1 */
void operation_one();                  /* Summoning some functions related to operation 1 */
int sum (int n1, int n2, int flag);    /* Doing addition */
int multi (int n1, int n2, int flag);  /* Doing multiplication */
void write_file(int number);           /* Writing numbers to results.txt file */

/* Functions used by part2 */
int operation_two(int num);            /* Summoning some functions related to operation 2 */
int Take_N();                          /* Getting N as an input from the user */
int isprime(int a);                    /* Checking whether a number is prime or not */

/* Functions used by part3 */
void operation_three();                /* Summoning some functions related to operation 3 */
void print_file();                     /* Printing file content on terminal */

/* Functions used by part4 */
void operation_four();                 /* Summoning some functions related to operation 4 */
void sort_file();                      /* Summoning and managing some functions related to sorting */
void write_to_temporary_file(int min1, int how_many1, int min2, int how_many2, int min3, int how_many3, int temp);  /* Writing numbers to temporary.txt file */
int keep_how_many(int a, int flag);            /* Keeping the number of numbers that are in results.txt */
int sorting_help(int again, int temp, int a);  /* Finding min1, min2 and min3 in each step */
int find_how_many(int num, int temp);         /* Finding how many times a number repeats in results.txt */
int find_the_min(int low_limit, int temp);    /* Finding the smallest number using and changing low_limit */
void copy_temporary_to_result(int temp);      /* Copying temporary.txt's content to results.txt */
void give_file_error();                       /* Giving warning about error that has been occurred regarding file operations and ending the program by returning NULL */
void creating_temporary_file();               /* Creating temporary.txt to prevent file error */
void creating_results_file();                 /* Creating results.txt to prevent file error */  

/* Please make sure that you clean both files' contents named results.txt and temporary.txt before running the program */


int main() {
    int selection, num_check, i, result, N;
    printf("\nPlease make sure that you clean both files' contents named results.txt and temporary.txt before running the program\n");

    /* Asking the user their selection */
    while(1) {
        do{
            /* MENU */
            printf("\nEnter -1 to quit or the program ends automatically after selecting and doing 4\n");
            printf("Select operation\n");
            printf("1. Calculate sum/multiplication between two numbers\n");
            printf("2. Calculate prime numbers\n");
            printf("3. Show number sequence in file\n");
            printf("4. Sort number sequence in file\n");
            printf("----------------------\n");
            scanf("%d", &selection);

            /* Quitting condition */
            if(selection == -1) {
                printf("Quitting...");
                return (0);
            }

            /* Asking selection again condition */
            else if(selection != 1 && selection != 2 && selection != 3 && selection != 4) {
                printf("Unvalid value choose (1-2-3-4)\n");
            }    

        }while(selection != 1 && selection != 2 && selection != 3 && selection != 4);


        /* Doing operation 1 */
        if(selection == 1) operation_one();


        /* Doing operation 2 */
        else if(selection == 2) {
            num_check = 2;   /* Smallest value to be checked */
            N = Take_N();    /* Getting N as an input from user */
            result = operation_two(num_check);  /* Getting result from the function */


            /* Checking every integer from 2 to that number if they are prime or not */
            for(num_check=2; 1<num_check && num_check<N ;) {
                
                /* Returning flag indicating that the number is prime */
                if(result == 0) {
                    printf("%d is a prime number.\n", num_check);
                }

                 /* Returning the last divider of the number indicating that the number is not prime */
                else {
                    printf("%d is not a prime number, it is dividible by %d.\n", num_check, result);
                }

                /* Checking the next number */
                num_check++;

                /* Getting result from the function */
                result = operation_two(num_check);
            }
        }


        /* Doing operation 3 */
        else if(selection == 3) operation_three();


        /* Doing operation 4 */
        else if(selection == 4) {
            operation_four();
            if(remove("temporary.txt") != 0) {
            	printf("\nError has occurred while deleting file...");
			}
            return (0);  /* Whenever operation 4 is run, the program ends. */
        }

    }
    return (0);
}


void operation_one() {
   int is_sum_or_multi, is_even_or_odd, N1, N2;
   int result_of_sum, result_of_multi, temp;
   int how_many=0, z;


   /* Getting inputs from the user while making sure that inputs are valid. */ 
   do{ 
        printf("Please enter '0' for sum, '1' for multiplication.\n");
        scanf("%d", &is_sum_or_multi);

        if(is_sum_or_multi != 0 && is_sum_or_multi != 1) {
            printf("Invalid value!\n");   
        }

   }while(is_sum_or_multi != 0 && is_sum_or_multi != 1);

    do{ 
        printf("Please enter '0' to work on even numbers, '1' to work on odd numbers.\n");
        scanf("%d", &is_even_or_odd);

        if(is_even_or_odd != 0 && is_even_or_odd != 1) {
            printf("Invalid value!\n");   
        }

   }while(is_even_or_odd != 0 && is_even_or_odd != 1);


   /* Getting inputs from the user while making sure that inputs are not negative and different from each other */ 
   do{
        printf("Please enter two different number:\n");
        do{
            printf("Number 1: ");
            scanf("%d", &N1);
            if(N1 < 0)  printf("Don't enter negative value!\n");

        }while(N1 < 0);


        do{
            printf("Number 2: ");
            scanf("%d", &N2);
            if(N2 < 0)  printf("Don't enter negative value!\n");

        }while(N2 < 0);

        if(N1 == N2) printf("They are the same numbers!\n");

   }while(N1 == N2);
   

   /* Swapping N1 and N2 since N1>N2 */ 
   if(N1>N2) {
       printf("Warning! Number1 > Number2 ! therefore they are swapping...\n");
       temp = N1;
       N1 = N2;
       N2 = temp;
   }


   /* Doing addition and multiplication */ 
   switch(is_sum_or_multi) {
       case 0:
            result_of_sum = sum(N1, N2, is_even_or_odd); /* Doing addition and getting result */
            how_many++;                                /* The number of numbers that has been written to results.txt file so far is increased by 1 */
            write_file(result_of_sum);                 /* Writing results to results.txt file */
            printf("The result is written to the results.txt file.\n");
            break;

       case 1:
            result_of_multi = multi(N1, N2, is_even_or_odd);  /* Doing multiplication and getting result */
            how_many++;                                     /* The number of numbers that has been written to results.txt file so far is increased by 1 */
            write_file(result_of_multi);                    /* Writing results to results.txt file */
            printf("The result is written to the results.txt file.\n");
            break;
   }


    /* Keeping total number of numbers written in results.txt file. */
    z = keep_how_many(how_many,0);  /*flag "0" means that we want to keep the variable "how_many" in another function, z aren't used for flag "0". */
}


/* Doing addition */
int sum (int n1, int n2, int flag) {
    int i, sum=0;

    printf("Result\n");
    switch(flag) {
        /* 0 indicates working on even numbers. */
        case 0:
            for(i = n1 + 1; i < n2; i++) {
                if(i % 2 == 0) {
                    printf("%d + ", i);
                    sum = sum + i;
                }
            }
        break;
        
        /* 1 indicates working on odd numbers. */
        case 1:
            for(i = n1 + 1; i < n2; i++) {
                if(i % 2 == 1) {
                    printf("%d + ", i);
                    sum = sum + i;
                }
            }
        break; 
    }

    /* Delete the last blank and plus sign */
    printf("\b\b= %d\n",sum);
    return sum;
}


/* Doing multiplication */
int multi (int n1, int n2, int flag) {
    int multi=0, i, flagy=0;


    printf("Result\n");
    switch(flag) {
        /* 0 indicates working on even numbers. */
        case 0:
            for(i = n1 + 1; i < n2; i++) {
                if(i % 2 == 0) {

                    /* Making sure that as long as there is no number n1<Number<n2, result is zero. */
                    if(flag == 0) {
                        flagy = 1;
                        multi = 1;
                    }

                    printf("%d * ", i);
                    multi = multi * i;
                }
            }
        break;
        
        /* 1 indicates working on odd numbers. */
        case 1:
            for(i = n1 + 1; i < n2; i++) {
                if(i % 2 == 1) {

                    /* Making sure that as long as there is no number n1<Number<n2, result is zero. */
                    if(flagy == 0) {
                        flagy = 1;
                        multi = 1;
                    }

                    printf("%d * ",i);
                    multi = multi * i;
                }
            }
        break; 
    }

    /* Delete the last blank and cross sign */
    printf("\b\b= %d\n", multi);
    return multi;
}


/* Writing results to results.txt file */
void write_file(int number) { 
    FILE *ptr ;

    /* Opening the file */
    ptr = fopen("results.txt","a+");

    /* Error condition */
    if(ptr == NULL) {
        give_file_error();
    }

    /* Writing to results.txt file */
    fprintf(ptr,"%d ", number);  

    fclose(ptr);
}


/* Doing operation 2 */
int operation_two(int num) {
    int result;
    result = isprime(num);  /* Summoning the function and getting result */
    return result;         
}


/* Checking whether respective number is prime or not. */
int isprime(int a) {
    int i;
    for(i = 2; i < a && i <= sqrt(a); i++) {
        if(a % i == 0) {
            return i;  /* Respective number is not prime therefore returning the first divider */
        }
    }

    return (0);  /* Respective number is prime */
}


/* Getting N as an input */
int Take_N() {
    int N;

    do{
        printf("Please enter an integer: ");
        scanf("%d", &N);
        if(N < 0) printf("Don't enter negative value!\n");

    }while(N < 0);

    return N;
}


/* Doing operation 3 */
void operation_three() {
    creating_results_file();  /* Preventing some file errors */
    print_file();             /* Printing results.txt file */
}


/* Printing results.txt file */
void print_file() {
    FILE *ptr;
    int num,temp=0;

    temp = keep_how_many(5,1); /* flag "1" indicates finding how many numbers are stored in results.txt file so far and keeping it in "temp", 5 is not used for flag "1" */

    /* Opening file */
    ptr = fopen("results.txt","r+");

    /* Error condition */
    if(ptr == NULL) {
        give_file_error();
    }


    printf("\nResult :\n");
    while(temp > 0) {

        /* Reading from file */
        fscanf(ptr,"%d ", &num);

        printf("%d ", num);
        temp--;
    }
    
    printf("\n");
    fclose(ptr);
}


/* Doing operation 4 */
void operation_four() {
    creating_temporary_file();  /* Preventing some file errors */
    sort_file();                /* Sorting temporary.txt */
}


/* Writing numbers to temporary.txt file */
void write_to_temporary_file(int min1, int how_many1, int min2, int how_many2, int min3, int how_many3, int temp) {
    FILE *ptr;
    static int count=0; /* "count" keeps how many numbers has been written so far to temporary.txt file so far */

    /* "how_many1" indicates the number of numbers that is equal to min1. */
    /* "how_many2" indicates the number of numbers that is equal to min2.*/
    /* "how_many3" indicates the number of numbers that is equal to min3.*/
    /* "temp" indicates the total number of numbers that is in results.txt file. */

    /* Opening the file */
    ptr = fopen("temporary.txt","a");

    /* Error condition */
    if(ptr == NULL) {
        give_file_error();
    }


    /* Printing min1, min2 and min3 in ascending order in temporary.txt */
    /* "count < temp" means that the number of numbers that are going to be written to temporary.txt should not exceed total number of numbers in results.txt, which is kept in "temp" */
    while(how_many1 > 0 && count < temp) {
        if(count < temp) {
            fprintf(ptr,"%d ", min1);
            count++;    /* The number of numbers that has been written to temporary.txt so far has been increased by 1. */
            how_many1--;
        }
    }

    while(how_many2 > 0 && count < temp) {  /* count < temp is used instead of count <= temp because as soon as while loop starts it is certain that at least one number is going to be written to temporary.txt */
        if(count < temp) {
            fprintf(ptr,"%d ", min2);
            count++;    /* The number of numbers that has been written to temporary.txt so far has been increased by 1. */
            how_many2--;
        }
    }

    while(how_many3 > 0 && count < temp) {
        if(count < temp) {
            fprintf(ptr,"%d ", min3);
            count++;    /* The number of numbers that has been written to temporary.txt so far has been increased by 1. */
            how_many3--;
        }
    }

    fclose(ptr);
}


/* Sorting temporary.txt */
void sort_file() { 
    int min1, min2, min3;
    int count1, count2, count3;
    int kalan, temp, again, a;
    int low_limit;

    /* "temp" keeps the total number of numbers that has been written to results.txt file so far */
    temp = keep_how_many(5,1); /* flag "1" indicates finding how many numbers are stored in results.txt file so far and keeping it in "temp", 5 is not used for flag "1" */
    kalan = (temp % 3);
    

    /* If total number of numbers greater or equal to 3 */
    if(temp >= 3) {
        again = (temp/3);     /* Total number of steps */
        a = 0;                /* Indicating low_limit that is going to be used while finding min1,min2 and min3 */
        low_limit = sorting_help(again, temp, a);  /* Going through all steps and returning last low_limit which is going to be used below*/


        /* If remainder is equal to 1 */
        if(kalan == 1) {
            /* There are just one number to be evaluated */
            min1 = find_the_min(low_limit, temp);  /* Finding the smallest number using low_limit */
            count1 = find_how_many(min1, temp);    /* Finding how many times the number repeats in results.txt */
            write_to_temporary_file(min1, count1, 0, 0, 0, 0, temp);  /* Writing number to temporary.txt */
        }


        /* If remainder is equal to 2 */
        else if(kalan == 2) {
            /* There are two numbers to be evaluated */
            min1 = find_the_min(low_limit, temp);  /* Finding the smallest number using low_limit */
            count1 = find_how_many(min1, temp);    /* Finding how many times the number repeats in results.txt */
            min2 = find_the_min(min1+1, temp);     /* Finding the second smallest number using low_limit */  
            count2= find_how_many(min2, temp);     /* Finding how many times the number repeats in results.txt */
            write_to_temporary_file(min1, count1, min2, count2, 0, 0, temp); /* Writing numbers to temporary.txt */
        }
    }


    /* If total number of numbers smaller than 3 */
    else if(temp < 3) {
        /* There are just one number to be evaluated */
        if(temp == 1) {
            low_limit = 0;                         /* Arranging low_limit such that the smallest number in results.txt is going to be found. */
            min1 = find_the_min(low_limit, temp);   /* Finding the smallest number using low_limit */
            count1 = find_how_many(min1, temp);     /* Finding how many times the number repeats in results.txt */
            write_to_temporary_file(min1, count1, 0, 0, 0, 0, temp);  /* Writing number to temporary.txt, 0 indicates that there are no any number to be written to temporary.txt file */
        }


        else if(temp == 2) {
            /* There are two numbers to be evaluated */
            low_limit = 0;                        /* Arranging low_limit such that the smallest number in results.txt is going to be found. */
            min1 = find_the_min(low_limit, temp);  /* Finding the smallest number using low_limit */
            count1 = find_how_many(min1, temp);    /* Finding how many times the number repeats in results.txt */
            min2 = find_the_min(min1+1, temp);     /* Finding the second smallest number using low_limit */  
            count2 = find_how_many(min2, temp);    /* Finding how many times the number repeats in results.txt */
            write_to_temporary_file(min1, count1, min2, count2, 0, 0, temp);  /* Writing number to temporary.txt, 0 indicates that there are no any number to be written to temporary.txt file */
        }
    }
    copy_temporary_to_result(temp); /* Copying sorted temporary.txt to results.txt */

}    


/* Finding min1,min2 and min3 in each step */
int sorting_help(int again, int temp, int a) { 
    int min1, min2, min3;
    int count1, count2, count3;

    while(again>0) {   /* There are "again" times step */
        min1 = find_the_min(a, temp);       /* Finding min1 */
        min2 = find_the_min(min1+1, temp);  /* Finding min2 */
        min3 = find_the_min(min2+1, temp);  /* Finding min3 */

        count1 = find_how_many(min1, temp);  /* Finding how many times min1 repeats in results.txt */
        count2 = find_how_many(min2, temp);  /* Finding how many times min2 repeats in results.txt */
        count3 = find_how_many(min3, temp);  /* Finding how many times min3 repeats in results.txt */

        write_to_temporary_file(min1, count1, min2, count2, min3, count3, temp);  /* Writing min1, min2 and min3 to temporary.txt */
        a = min3 + 1;  /* Arranging low_limit of min1 */
        again--;     /* Going through while loop "again" times */
    } 
    return a;  /* Returning low_limit, which is going to be used for other numbers's sorting operations, if any. */
}


/* Finding the smallest number using and changing low_limit */
int find_the_min(int low_limit, int temp) { 
    FILE *ptr;
    int num;
    int min=2147483647;  /* Arranging min value 2147483647 for sorting purposes, which is maximum integer value. */

    /* Opening results.txt */
    ptr = fopen("results.txt","r");

    /* Error condition */
    if(ptr == NULL) {
        give_file_error();
    }

    /* Finding smallest number */
    while(temp>0) {
        fscanf(ptr,"%d ",&num);
            if(num < min && num >= low_limit) {
                min = num;
            }
        temp--;
    }

    /* Closing file */
    fclose(ptr);

    /* Returning smallest number */
    return min; 
}


/* Finding how many times a number repeats in results.txt */
int find_how_many(int num, int temp) { 
    FILE *ptr;
    int count=0, a;

    /* Opening results.txt */
    ptr = fopen("results.txt","r");

    /* Error condition */
    if(ptr == NULL) {
        give_file_error();
    }

    /* Finding how many times a number repeats in results.txt */
    while(temp>0) {
        fscanf(ptr,"%d ", &a);
            if(a == num) {
                count++;
            }
        temp--;
    }

    /* Closing file */
    fclose(ptr); 

    /* Returning the number of repetition */
    return count;
}


/* Copying temporary.txt's content to results.txt */
void copy_temporary_to_result(int temp) {
    FILE *ptr, *p;
    int num;

    /* Opening results.txt */
    ptr = fopen("results.txt","w");

    /* Error condition */
    if(ptr == NULL) {
        give_file_error();
    }

    /* Opening temporary.txt */
    p = fopen("temporary.txt","r");

    /* Error condition */
    if(p == NULL) {
        give_file_error();
    }

    printf("Sorting is complete.\n");
    printf("Result :\n");

    /* Copying temporary.txt's content to results.txt */
    while(temp > 0) {
        fscanf(p, "%d ", &num);
        fprintf(ptr, "%d ", num);
        printf("%d ", num);
        temp--;
    }

    fclose(ptr);
    fclose(p);
}


/* Giving error about error that has been occurred regarding file operations and ending the program returning NULL */
void give_file_error() {
    printf("\nError has occurred regarding file operations\n");
    printf("Quit please...");
    while(1);
}


/* Keeping the number of numbers that are in results.txt */
int keep_how_many(int a,int flag) {
    static int y=0; /* Keeps the current number of numbers in results.txt file */
    int b;          /* It keeps the value of y when caller wants to know the number of numbers */

    if(flag == 0) {   /* flag "0" means changing the value of the current number of numbers */
        y = y + a;
    }

    else if(flag == 1) {  /* flag "1" means the function that has called "keep_how_many" function, wants to know the number of numbers,which has been recorded so far, in results.txt file  */
        b = y;
    }

    return b;  /* Returning the number of numbers in results.txt file */
}


void creating_temporary_file() {
    FILE *ptr;
    ptr = fopen("temporary.txt","a");
    fclose(ptr);
}


void creating_results_file() {
    FILE *ptr;
    ptr = fopen("results.txt","a");
    fclose(ptr);
}
