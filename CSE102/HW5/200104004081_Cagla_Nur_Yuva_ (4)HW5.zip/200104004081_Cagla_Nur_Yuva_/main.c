#include <stdio.h>
#include <math.h>
#define PI 3.14  /* Defining PI number */

/* Function Prototypes */
int select_shape();          /* Asking which shape the user wants to use */
int select_calc();           /* Asking which calculation the user wants to do */
int calculate(int (*decide_shape) (), int (*decide_calculation) ());   /* Calling select_shape and select_calc functions repeatedly */
int calc_triangle(int);      /* Doing calculations related to triangle */
int calc_quadrilateral(int); /* Doing calculations related to quadrilateral */
int calc_circle(int);        /* Doing calculations related to circle */
int calc_pyramid(int);       /* Doing calculations related to pyramid */
int calc_cylinder(int);      /* Doing calculations related to cylinder */


/* Enum Declarations */
enum Shapes {
    Triangle=1,
    Quadrilateral,
    Circle,
    Pyramid,
    Cylinder
};

enum Calculators {
    Area=1,
    Perimeter,
    Volume
};


int main() {
    int command;

    printf("Welcome to the geometric calculator!\n");
    do {
        /* Calling calculate function until the user enters 0 */
        command = calculate(select_shape,select_calc);

        /* Quitting condition */
        if(command == 0) printf("Quitting...\n");

        /* Giving warning in the case of an unsuccessful operation */
        else if(command == -1) printf("Something has gone wrong...\n");

    }while(command != 0);

    return (0);

}  /* End of main function */


/* Calling select_shape and select_calc functions repeatedly */
int calculate(int (*decide_shape)(), int (*decide_calculation)()) {
    int result, flag=0;
    enum Shapes shape;             /* Creating shape variable of enum Shapes type */
    enum Calculators calculation;  /* Creating calculation variable of enum Calculators type */

    do{

        /* Asking which shape you want to use*/
        shape = decide_shape();

        /* Quitting condition in asking shape menu */
        if(shape == 0) return (0);

        /* Asking which calculation you want to do*/
        calculation = decide_calculation();

        /* Quitting condition in asking calculation menu */
        if(calculation == 0) return (0);

        /* Checking whether both selections are valid or not */
        flag = 1;


        /* Unvalid selections */
        if(shape == Triangle && calculation == Volume) {
            printf("\nERROR ! You cannot calculate the volume of a triangle. Please try again.\n");
            flag = 0;  /* Repeating selections */
        }

        else if(shape == Quadrilateral && calculation == Volume) {
            printf("\nERROR ! You cannot calculate the volume of a quadrilateral. Please try again.\n");
            flag = 0;  /* Repeating selections */
        }

        else if(shape == Circle && calculation == Volume) {
            printf("\nERROR ! You cannot calculate the volume of a Circle. Please try again.\n");
            flag = 0;   /* Repeating selections */
        }

    }while(flag == 0);  /* Repeating selections until both selections are valid. */


        /* Calling appropriate function that is compatible with the user's choice  */
        switch(shape) {
            case Triangle:
                result = calc_triangle(calculation);       /* Calling function to do the certain calculation for triangle */
                break;

            case Quadrilateral:
                result = calc_quadrilateral(calculation);  /* Calling function to do the certain calculation for quadrilateral */
                break;

            case Circle:
                result = calc_circle(calculation);         /* Calling function to do the certain calculation for circle */
                break;  

            case Pyramid:
                result = calc_pyramid(calculation);        /* Calling function to do the certain calculation for pyramid */
                break;  

            case Cylinder:
                result = calc_cylinder(calculation);       /* Calling function to do the certain calculation for cylinder */
                break;
        }

        return result;  /* Returning result to main function */

}  /* End of calculate function */


/* Asking which shape the user wants to use */
int select_shape() {
    int choice;
    int flag=0;
    int i;

    /* MENU */
    printf("\nSelect a shape to calculate:\n");
    printf("------------------------------\n");
    printf("1. Triangle\n");
    printf("2. Quadrilateral\n");
    printf("3. Circle\n");
    printf("4. Pyramid\n");
    printf("5. Cylinder\n");
    printf("0. Exit\n");
    printf("------------------------------\n");


    /* Getting choice of the user as an input */
    printf("Input : ");
    do{
        i=1;
        i = scanf("%d", &choice);
        flag = 1;       /* Checking unvalid inputs */
       

       /* Checking whether scanf function has taken the value or not */
       if(i == 0) {
           flag = 0;
       }

       /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;   /* Indicating unvalid input */
        }


        /* Checking valid gaps of selection */
        if(!((choice >= Triangle && choice <= Cylinder) || (choice == 0))) {
            flag = 0;   /* Indicating unvalid input */
        }


        /* Printing error message if necessary */
        if(flag == 0) {
            printf("ERROR ! Please enter a valid entry\n\n"); 
        }
        
    }while(flag == 0);  /* Repeating getting input until it is valid. */

    return choice;

} /* End of select_shape function */


/* Asking which calculation the user wants to do */
int select_calc() {
    int choice;
    int flag=0;
    int i;

    /* MENU */
    printf("\nSelect calculator:\n");
    printf("------------------------------\n");
    printf("1. Area\n");
    printf("2. Perimeter\n");
    printf("3. Volume\n");
    printf("0. Exit\n");
    printf("------------------------------\n");


    /* Getting choice of the user as an input */
    printf("Input : ");
    do{
        i=1;
        i = scanf("%d", &choice);
        flag = 1;      /* Checking unvalid inputs */


        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;  /* Indicating unvalid input */
        }


        /* Checking valid gaps of selection */
        if(!((choice >= Area && choice <= Volume) || (choice == 0))) {
            flag = 0;  /* Indicating unvalid input */
        }


        /* Printing error message if necessary */
        if(flag == 0) {
            printf("ERROR ! Please enter a valid entry\n\n"); 
        }
        
    }while(flag == 0);  /* Repeating getting input until it is valid. */

    return choice;

} /* End of select_calc function */


/* Doing calculations related to triangle */
int calc_triangle(int selection) {
    float side1, side2, side3, semi_perimeter;
    float area, perimeter;
    int flag = 1;
    int i;

    /* Getting sides of triangle from the user as an input */
    printf("\nPlease enter three sides of Triangle :\n");
    do{
        i=1;
        i = scanf("%f", &side1);
        flag = 1;       /* Checking unvalid inputs */


        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;   /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        i=1;
        i = scanf("%f", &side2);

        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;   /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        i=1;
        i = scanf("%f", &side3);

        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;   /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        if(side1 <= 0 || side2 <= 0 || side3 <= 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        semi_perimeter = (side1 + side2 + side3)/2;   /* Calculating semi perimeter */


        /* Checking whether the triangle is valid or not */
        if(semi_perimeter <= side1 || semi_perimeter <= side2 || semi_perimeter <= side3) {
            printf("\nERROR ! Please enter a valid triangle.\n\n");
            flag = 0; /* Indicating unvalid input */
            continue;
        }

    }while(flag == 0 || side1 <= 0 || side2 <= 0 || side3 <= 0);  /* Repeating getting input until it is valid. */
    

    /* Doing the calculation that is compatible with the user's choice */
    switch(selection) {
        case Area:
            area = sqrt(semi_perimeter*(semi_perimeter-side1)*(semi_perimeter-side2)*(semi_perimeter-side3));
            printf("\nArea of TRIANGLE : %.2f\n",area);
            return (1);

        case Perimeter:
            perimeter = (semi_perimeter*2);
            printf("\nPerimeter of TRIANGLE : %.2f\n",perimeter);
            return (1);
    }

    return (-1);

} /* End of calc_triangle function */


/* Doing calculations related to quadrilateral */
int calc_quadrilateral(int selection) {
    float side1, side2, side3, side4, area, semi_perimeter, perimeter ;
    int flag = 1;
    int i;

    /* Getting sides of quadrilateral from the user as an input */
    printf("\nPlease enter four sides of Quadrilateral\n");
    do{
        i=1;
        i = scanf("%f", &side1);
        flag = 1;      /* Checking unvalid inputs */

        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;  /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        i=1;
        i = scanf("%f", &side2);

        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;  /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        i=1;
        i = scanf("%f", &side3);

        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;  /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        i=1;
        i = scanf("%f", &side4);

        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;   /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        if(side1 <= 0 || side2 <= 0 || side3 <= 0 || side4 <= 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

    }while(flag == 0 || side1 <= 0 || side2 <= 0 || side3 <= 0 || side4 <= 0);  /* Repeating getting input until it is valid. */

    semi_perimeter = (side1 + side2 + side3 + side4)/2 ;  /* Calculating semi perimeter */


    /* Doing the calculation that is compatible with the user's choice */
    switch(selection) {
        case Area:
            area = sqrt((semi_perimeter-side1)*(semi_perimeter-side2)*(semi_perimeter-side3)*(semi_perimeter-side4));
            printf("\nArea of QUADRILATERAL : %.2f\n",area);
            return (1);

        case Perimeter:
            perimeter = (semi_perimeter*2) ;
            printf("Perimeter of QUADRILATERAL : %.2f\n",perimeter);
            return (1);
    }
    
    return (-1);

}  /* End of calc_quadrilateral function */


/* Doing calculations related to circle */
int calc_circle(int selection) {
    float radius, area, perimeter;
    int flag=1;
    int i;

    /* Getting radius from the user as an input */
    printf("\nPlease enter the radius of Circle :\n");
    do{
        i=1;
        i = scanf("%f", &radius);
        flag = 1;      /* Checking unvalid inputs */

        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;  /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0 || radius <= 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

    }while(flag == 0 || radius <= 0);  /* Repeating getting input until it is valid. */


    /* Doing the calculation that is compatible with the user's choice */
    switch(selection) {
        case Area:
            area = PI*radius*radius ;
            printf("\nArea of CIRCLE : %.2f\n",area);
            return (1);

        case Perimeter:    
            perimeter = 2*PI*radius ;
            printf("\nPerimeter of CIRCLE : %.2f\n",perimeter);
            return (1);
    }

    return (-1);

} /* End of calc_circle function */


/* Doing calculations related to pyramid */
int calc_pyramid(int selection) {
    float base_side, height ;
    float B_S_Area, L_S_Area, S_A_Area, perimeter, volume ;
    int flag=1;
    int i;

    /* Getting base side and height of a pyramid from the user as an input */
    printf("\nPlease enter the base side and height of a Pyramid :\n");
    do{
        i=1;
        i = scanf("%f", &base_side);
        flag = 1;      /* Checking unvalid inputs */

        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;  /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        i=1;
        i = scanf("%f", &height);

        /* Checking whether scanf function has taken the value or not */
         if(i == 0) {
            flag = 0;
        }


        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;  /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        if(base_side <= 0 || height <= 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

    }while(flag == 0 || base_side <= 0 || height <= 0);  /* Repeating getting input until it is valid. */


    /* Doing the calculation that is compatible with the user's choice */
    switch(selection) {
        case Area:
            B_S_Area = base_side*base_side ;
            L_S_Area = base_side*height*2 ;
            S_A_Area = B_S_Area + L_S_Area ;
            printf("\nBase Surface Area of a PYRAMID : %.2f\n\n",B_S_Area);
            printf("Lateral Surface Area of a PYRAMID : %.2f\n\n",L_S_Area);
            printf("Surface Area of a PYRAMID : %.2f\n\n",S_A_Area);
            return (1);

        case Perimeter:
            perimeter = 4*base_side ;
            printf("\nPerimeter of a PYRAMID : %.2f\n",perimeter);
            return (1);

        case Volume:
            volume = (1/3.0)*base_side*base_side*height;
            printf("\nVolume of a PYRAMID : %.2f\n",volume);
            return (1);
    }
    return (-1);

} /* End of calc_pyramid function */


/* Doing calculations related to cylinder */
int calc_cylinder(int selection) {
    float radius, height, B_S_Area, L_S_Area, S_A_Area, perimeter, volume  ;
    int flag=1;
    int i;

    /* Getting radius and height of a cylinder from the user as an input */
    printf("\nPlease enter the radius and height of a Cylinder :\n");
    do{
        i=1;
        i = scanf("%f", &radius);
        flag = 1;       /* Checking unvalid inputs */

        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;   /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        i=1;
        scanf("%f", &height);

        /* Checking whether scanf function has taken the value or not */
        if(i == 0) {
            flag = 0;
        }

        /* Making buffer clean and letting scanf operate without error */
        while ((getchar()) != '\n') {
            flag = 0;   /* Indicating unvalid input */
        }


        /* Checking both buffer condition and negative values */
        if(flag == 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

        if(radius <= 0 || height <= 0) {
            printf("\nERROR ! Please enter a valid entry.\n\n");
            continue;
        }

    }while(flag == 0 || radius <= 0 || height <= 0);  /* Repeating getting input until it is valid. */


    /* Doing the calculation that is compatible with the user's choice */
    switch(selection) {
        case Area:
            B_S_Area =  PI*radius*radius ;
            L_S_Area =  2*PI*radius*height;
            S_A_Area =  2*PI*radius*(radius+height);
            printf("\nBase Surface Area of a CYLINDER : %.2f\n\n",B_S_Area);
            printf("Lateral Surface Area of a CYLINDER : %.2f\n\n",L_S_Area);
            printf("Surface Area of a CYLINDER : %.2f\n\n",S_A_Area);
            return (1);

        case Perimeter:
            perimeter = 2*PI*radius;
            printf("\nBase Surface Perimeter of a CYLINDER : %.2f\n",perimeter);
            return (1);

        case Volume:
            volume = PI*radius*radius*height;
            printf("\nVolume of a CYLINDER : %.2f\n",volume);
            return (1);
    }

    return (-1);

}  /* End of calc_cylinder function */
