#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct table {
    char **field;
    char **type;
    char name[40];
    int *isNull;
    char **isKey;
}table;

typedef struct tables {
    struct tables *next;
    table *t;
}tables;

typedef struct database {
    tables *tList;
    int n;
    char *database_name;
}database;

void get_database_name(char *database_name);
void create_database(char *name, database *d);
void insert_table(database *d,table *t);
void show_tables(database *d);
void desc_table(database *d);
void remove_table(database *d, char *name);
void insert_key(database *d, char key_value[40]);

tables *head = NULL;

int main() {
    int choice,i;
    char *database_name = (char*)malloc(sizeof(char)*20);
    char deleted_name[40];
    char key[40];
    database *new_database = (database*)malloc(sizeof(database));
    table *new_table = (table*)malloc(sizeof(table));

    new_database->database_name = (char*)malloc(sizeof(char)*40);
    new_database->tList = (tables*)malloc(sizeof(tables));
    new_table->field = (char**)malloc(sizeof(char*)*3);
    new_table->type = (char**)malloc(sizeof(char*)*3);
    new_table->isNull = (int*)malloc(sizeof(int)*3);
    new_table->isKey = (char**)malloc(sizeof(char*)*3);
    
    head = (tables*)malloc(sizeof(tables));
    head = NULL;
 
   
    do{
        printf("\n1. Create a new database\n");
        printf("2. Show tables in a database\n");
        printf("3. Describe a table\n");
        printf("4. Create a new table in a database\n");
        printf("5. Delete a table from a database\n");
        printf("6. Insert a key on a table\n");
        printf("7. Exit\n\n");
        printf("Enter your choice: ");
        scanf("%d",&choice);

        switch(choice){
            case 1:
                get_database_name(database_name);
                create_database(database_name,new_database);
                break;

            case 4:
                insert_table(new_database,new_table);    
                break;

            case 2:
                show_tables(new_database);
                break;    

            case 3:
                desc_table(new_database);
                break;    

            case 5:
                printf("enter the table's name that you want to delete: ");
                scanf("%s",deleted_name);
                remove_table(new_database,deleted_name);
                break;       

            case 6:
                
                printf("Enter key value: ");
                scanf("%s",&key);
                insert_key(new_database, key);
                break;

            case 7:
                printf("\nExiting...\n");
                break;    

         
        }

     
        
    }while(choice != 7);
}

void show_tables(database *d) {
    int index=0;
    d->tList = head;

    while(d->tList != NULL){
        printf("\n\nTable Name: %s\n",d->tList->t->name);
        printf("%-10s%-10s%-10s%-10s\n","Field","Type","Null","Key");

        index=0;
        while(d->tList->t->field[index][0] != '-') {
            printf("%-10s%-10s%d%10s\n",d->tList->t->field[index], d->tList->t->type[index], d->tList->t->isNull[index],d->tList->t->isKey[index]);
            index++;
        }
        (d->tList) = (d->tList->next);
    }
    
}

void insert_table(database *d, table *t) {
    tables *iter = head;
    tables *node = (tables*)malloc(sizeof(tables));
    int row=0, index;
    int choice, i;
    char c;

    printf("Enter table name: ");
    scanf("%s",t->name);

    do{
        
        t->isNull = (int*)realloc(t->isNull,sizeof(int)*(row+2));
        t->field = (char**)realloc(t->field,sizeof(char*)*(row+2));
        t->type = (char**)realloc(t->type,sizeof(char*)*(row+2));
        t->isKey = (char**)realloc(t->isKey, sizeof(char*)*(row+2));

        t->field[row] = (char*)malloc(sizeof(char)*3);
        t->type[row] = (char*)malloc(sizeof(char)*3);
        t->isKey[row] = (char*)malloc(sizeof(char)*3);

        strcpy(t->isKey[row],"-");
        
        index=0;
        printf("For %d.row:\n",row+1);
        printf("Enter field: ");
        getchar();
        while((c=getchar()) != '\n' && c != EOF){
            t->field[row] = (char*)realloc(t->field[row],sizeof(char)*(index+3));
            t->field[row][index] = c;
            index++;
        }
        t->field[row][index] = '\0';
      
        printf("Enter type: ");
        index=0;
        while((c=getchar()) != '\n' && c != EOF){
            t->type[row] = (char*)realloc(t->type[row],sizeof(char)*(index+3));
            t->type[row][index] = c;
            index++;
        }
        t->type[row][index] = '\0';

        
        printf("Enter isNull(1-0): ");
        scanf("%d",&t->isNull[row]);

        row++;
        

        printf("Enter 1 to keep creating rows, enter 0 to quit: ");
        scanf("%d",&choice);

        if(choice == 0)break;
        
    }while(1);

    t->field[row] = (char*)malloc(sizeof(char)*3);
    t->field[row][0] = '-';
      
    node->t = t;
    node->next = NULL;

    if(head == NULL){
        
        head = node;
        head->next = NULL;
    }

    else if(head->next == NULL){
        head->next = node;
    }
 
    else {

        while((iter->next) != NULL){
            iter = iter->next;
        }
            
        iter->next = node;

    }


}

void get_database_name(char *database_name) {
    char c;
    int index=0;
   
    printf("\nEnter database name: ");
    getchar();

    while((c=getchar()) != EOF && c != '\n'){
        
        if(index >= 19){
            database_name = (char*)realloc(database_name,sizeof(char)*(index+3));

        }

        database_name[index] = c;
        index++;

    }
    database_name[index] = '\0';

}

void create_database(char *name, database *d) {
    
    strcpy(d->database_name,name);
    d->n = 0;
    
}

void desc_table(database *d) {
    char name[40];
    int flag=0, index=0;
    tables *iter = head;
     
    printf("Enter the table's name that you want to see: ");
    scanf("%s",name);

    do{
		if(strcmp(iter->t->name,name)==0){
			flag = 1;
			break;
		}	
		iter = iter->next;	
	}while(iter!=NULL);
   
    d->tList = iter;
    
    if(flag == 1){
        printf("\n\nTable Name: %s\n",d->tList->t->name);
        printf("%10s%10s%5s%5s\n","Field","Type","Null","Key");
        while((sizeof(d->tList->t->field[index])) != (sizeof(char))) {
            printf("%10s%10s%5d%5d\n",d->tList->t->field[index], d->tList->t->type[index], d->tList->t->isNull[index], d->tList->t->isKey);
            index++;
        }            
    }

    else if(flag == 0){
        printf("There is no table named '%s'\n",name);
    }

}

void remove_table(database *d, char *name) {//field, type'i falan silmedin daha
    
  if(head == NULL){ //if there is no element
    	printf("There is no element in the list.\n\n");
	}

    else if (strcmp(head->t->name,name)==0){ //if the first element is what we are looking for
		tables *temp = head->next;
		free(head);
		printf("%s has been deleted.\n\n",name);
	}

    else {
        tables *iter = head;
        tables *previous;
        int flag=0;

        do{
			if(strcmp(iter->t->name,name)==0){
				flag = 1;
				break;
			}
			previous = iter;	
			iter = iter->next;	
		}while(iter!=NULL);

        if(flag==1){
			previous ->next = iter->next;
			free(iter);
			printf("%s has been deleted.\n\n",name);
		}
		
		// if we couldn't find the element, return
		else{
			printf("%s is not in the list.\n\n", name);
		}

    }

}

void insert_key(database *d, char key_value[40]) {
    char name[40];
    int col,row;
    int flag=0, index=0;
    tables *iter = head;
     
    printf("Enter the table's name that you want to add a primary key: ");
    scanf("%s",name);

    do{
		if(strcmp(iter->t->name,name)==0){
			flag = 1;
			break;
		}	
		iter = iter->next;	
	}while(iter!=NULL);

    d->tList = iter;

    if(flag == 1){
        printf("Enter the row in which you want to add a primary key: ");
        scanf("%d",&row);
        strcpy(d->tList->t->isKey[row-1],key_value);
    }
}



